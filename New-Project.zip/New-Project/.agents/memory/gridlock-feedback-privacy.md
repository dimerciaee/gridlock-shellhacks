---
name: GridLock feedback privacy
description: Durable privacy constraints for feedback submitted through GridLock.
---

Keep feedback anonymous by default. Collect only a category and message, warn users not to include personal information or confidential utility data, and do not expose submissions through a public listing endpoint.

**Why:** GridLock is a public utility-planning demo, and a feedback box can unintentionally collect personally identifying or CEII-related material.

**How to apply:** Keep input minimal and length-limited. Review submissions through the project-controlled database or a future authenticated admin surface; do not add identity fields or public read access without an explicit product and access-control decision.