---
name: Public infrastructure coverage
description: Why public feature-service search results may fail to cover the utility demo area
---

Check service metadata extent and query a known area before promising a national infrastructure layer. A service named after a national HIFLD dataset may only contain a small regional extract.

**Why:** Several public substation FeatureServer results were accessible and correctly returned GeoJSON, but their extents were limited to unrelated regions, so valid queries near the demo utilities returned no stations. This is not proof that the area has no substations.

**How to apply:** Verify service coverage separately from network availability. Prefer a source with demonstrable local coverage; if coverage is unknown, say so and never infer a project tie from an existing asset on the map.