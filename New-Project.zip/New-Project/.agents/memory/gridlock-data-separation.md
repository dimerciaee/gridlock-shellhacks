---
name: GridLock data separation
description: How to treat source-derived utility projects that are not yet geolocated.
---

Keep source-derived but unlocated utility project records distinct from demonstration coordinates and overlap claims. If both appear in the product, visibly separate the demo from the source inventory and make unlocated records ineligible for proximity matching.

**Why:** A public project listing can supply names and planned dates without verified coordinates, while another utility's excerpt may not contain its project list at all. Combining those records with two geocoded sample points in one undifferentiated comparison would make the sample overlap look sourced.

**How to apply:** Preserve source and location confidence for each imported project; wait for named location evidence before promoting it into a real overlap calculation. Keep the demo clearly labeled until both utility lists and location evidence are usable.

For a long line or multi-site project, a pair of independently identified single endpoints supports a **point-proximity observation**, not a verified full-route intersection. Do not combine a named map endpoint with an unverified coordinate from a submitted workbook to imply the full project center is known. Cite the specific map features and filing pages, and keep the unverified workbook distances separate.

**Why:** One public map feature may corroborate a named substation while the other endpoint or route is not independently locatable; a computed distance is reproducible but its geographic coverage is narrow.

**How to apply:** Calculate distances using only independently located points. Label single-endpoint pair rows and map lines as endpoint proximity, not confirmed construction overlap; preserve unresolved dates when the underlying filing dates are absent or phased.

Lead with source-backed coordination opportunities. For eligible sourced pairs, distance-tier savings ranges may use a Dominion filing snapshot and a Georgia Power transmission benchmark range; label the result as an illustrative scenario, never as verified or guaranteed project savings. Keep exact Georgia Power costs hidden and keep verified combined baselines “Not estimated” until comparable current budgets and confirmed shared scope are available. Keep illustrative source-example amounts separate from percentage-tier results.

**Why:** Independently located endpoints and planned in-service dates do not establish overlapping work scope, project cost baselines, or compatible construction windows. The user asked to restore visible scenario ranges, but they remain assumptions rather than verified evidence.

**How to apply:** Keep scenario ranges visually separate from filing snapshots and verified baselines; disclose the distance-tier formula and generic schedule assumption in Technical Notes. Do not show scenarios for demo-only candidates or report scenario outputs as actual savings. Source-example amounts illustrate possible cost categories and do not define or add to the calculated percentage scenarios.

The storm corridor and facility ranking are deterministic what-if planning aids, not live hazard, outage, or dispatch priorities.

**Why:** Demo facility locations and project centers, even when combined with a moving corridor, lack forecast uncertainty, network dependencies, backup-power status, and operational field validation.

**How to apply:** Show the category, simulated exposure, and demo-project proximity factors beside each ranking; keep actual weather alerts separate. Do not present a simulated high score as a directive to send crews or as a measured grid-load condition.

Resilience rankings add only assessed factors; an unknown cost, network link, critical-site inventory, or measured hazard is not a zero-point finding. Historical budget totals supplied in pasted utility plans must be attributed to that snapshot even when a newer filing updates dates.

**Why:** A partial inventory can establish one utility's budget without establishing the partner's budget or present-day scope. A broad coastal-area proxy is not a measured flood, surge, wind, or hurricane-frequency risk.

**How to apply:** Display known points and the possible maximum separately, label missing factors, cite the budget snapshot, and reserve real weather-risk claims for geographically linked authoritative hazard data.

For coordination potential, normalize the points over the maximum weight of drivers with available inputs. Unknown drivers are omitted from both the point total and denominator; show the available-point fraction beside the normalized /100 score and grade.

**Why:** The user wants a useful headline score without treating unknown factors as zero. A visible available-point fraction makes clear how much evidence the normalized grade uses.

**How to apply:** Include assessed drivers in the denominator only when they have values. Show both the raw available points (for example, 43/50) and normalized score (86/100); list omitted drivers under Technical Notes. Do not describe the grade as overlap probability or construction readiness.