---
name: Video scene text anchoring
description: Prevent motion transforms from shifting percentage-positioned scene copy.
---

For code-driven video scenes, avoid wrapping absolutely positioned copy in an auto-sized node whose Motion animation applies `x`, `y`, or `scale`. A transform creates a containing block for descendants; percentage positioning can resolve against that wrapper and jump when the transform settles. Put Motion props on the positioned text node itself, or give the wrapper stable positioned dimensions.

**Why:** In GridLock's closing scene, the sentence briefly appeared above its intended location before moving below the wordmark because it was inside a transformed, auto-height wrapper.

**How to apply:** When scene copy uses `position: absolute` and percentage-based `top` or `left`, animate that element itself. Check both its entrance frame and settled frame.