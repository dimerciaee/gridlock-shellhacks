---
name: Utility coordination identity
description: Boundary between judge-facing collaboration prototypes and real inter-utility messaging
---

Treat attributed utility messages as fictional examples until actual representatives can be verified. Local planning notes are not communication with another company.

**Why:** Public project documents and proximity data provide no evidence that Dominion or Georgia Power personnel agreed to coordinate, or that the app can authenticate their representatives. A judge-facing prototype must not imply an agreement or delivered message.

**How to apply:** For future messaging work, establish verified company identity, access controls, shared persistence, and delivery status before showing utility-attributed user-generated comments as real. Keep scenario examples visibly marked as fictional.