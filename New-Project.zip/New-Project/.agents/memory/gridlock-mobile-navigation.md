---
name: GridLock mobile navigation
description: The user's preferred mobile information hierarchy and navigation pattern for GridLock.
---

On phones, keep the header compact, show the map first, and use a concise list of links to project opportunities and facility priority instead of category tabs or hidden views. On desktop, keep the sidebar resizable with pointer and keyboard controls. Keep the anonymous feedback action in the global footer rather than the sidebar, while preserving its existing dialog and submission flow.

**Why:** The user explicitly requested a phone-first map, a resizable desktop sidebar, and removal of feedback from the sidebar without losing access to the feedback form.

**How to apply:** Keep the map as the first content below the compact header, followed by straightforward project and facility anchor links. Make the desktop resize control usable by mouse and keyboard, and place feedback outside the sidebar.