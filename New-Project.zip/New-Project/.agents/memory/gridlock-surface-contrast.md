---
name: GridLock surface contrast
description: Preserve dark coordination surfaces while keeping their text readable.
---

Keep the Coordination Opportunities action center, opportunity cards, and score details in their dark palette. Use sufficiently bright text for headings, muted copy, labels, links, and controls instead of turning those surfaces white for readability. Keep white backgrounds scoped to report and cost-comparison areas where requested.

**Why:** The user corrected a global white-surface treatment and clarified that dark backgrounds should remain dark with readable text.

**How to apply:** Scope theme overrides to the intended view. When changing coordination styling, inspect the dark opportunity card and expanded score details for text contrast.