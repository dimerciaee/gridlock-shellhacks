---
name: GridLock footer spacing
description: Why bottom overlays need coordinated layout across desktop and phone widths.
---

Treat bottom-of-screen UI as one layout: the mission footer, slogan, event tag, AI badge, map attribution, and sidebar controls must remain readable without covering each other.

**Why:** Positioning each item independently caused a new footer to obscure overlap actions and map attribution; on a phone-sized view, the overlays also collided with the sidebar.

**How to apply:** When changing footer height or adding overlays, preserve room for the map and sidebar, keep map attribution visible, and let these elements enter normal page flow on narrow screens. Check both desktop and phone previews before delivering.