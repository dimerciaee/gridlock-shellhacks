---
name: Utility planning dates
description: How to handle malformed or multi-phase planned in-service dates in public utility filings.
---

Treat planned in-service fields as source text until they validate as one real calendar date. Preserve the printed value and leave the normalized date unavailable when it is impossible or names multiple phases.

**Why:** A publicly posted transmission planning PDF contains impossible day/month combinations, and an older listing gives separate dates for two phases of one project. JavaScript date rollover or picking one phase would fabricate exact date gaps.

**How to apply:** Keep the printed field beside a nullable ISO date, validate with a UTC year/month/day roundtrip, record the source version/page, and calculate a pairwise day gap only when both projects have valid single dates.