---
name: AI provider access
description: Replit-managed AI access may be plan-gated; direct provider keys must remain server-side and quota failures should be user-visible.
---

Managed AI integrations can be unavailable on the current plan, requiring a provider key stored as a Replit secret. Even with a valid secret, the provider may reject requests when its credit balance is exhausted.

When changing an OpenAI model, verify the exact ID against the official catalog or a provider response. The requested `gpt-4o-mini-1` ID returned `model_not_found` in this project's API call.

For GridLock overlap explanations, keep the local rules-based demo active unless the user explicitly asks to enable an external provider. Do not use the undocumented Replit browser endpoint.

The user authorized server-side Google Gemini for joint action plans, coordination recommendations, storm coordination plans, and executive summaries. Do not use AI to generate cost or savings estimates.

**Why:** The user initially kept overlap explanations local for demo predictability, then explicitly requested the five structured planning tasks. Do not generalize that authorization to unrelated AI features.

**How to apply:** Keep provider credentials in the server environment, never in browser code or chat; verify model IDs and return clear messages for quota or model errors. Keep costs and savings unestimated; keep unsupported routes, schedules, and operational claims out of generated planning responses.