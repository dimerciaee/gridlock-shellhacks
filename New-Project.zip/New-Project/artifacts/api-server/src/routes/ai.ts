import { Router, type IRouter } from "express";
import {
  GenerateCoordinationAnalysisBody,
  GenerateCoordinationAnalysisResponse,
  ExplainOverlapBody,
  ExplainOverlapResponse,
} from "@workspace/api-zod";
import {
  generateCoordinationTask,
  GeminiPlanningError,
  type CoordinationTask,
} from "../lib/gemini-planning";

const router: IRouter = Router();

router.post("/ai/coordination", async (req, res): Promise<void> => {
  const parsed = GenerateCoordinationAnalysisBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "A valid coordination analysis request is required." });
    return;
  }

  try {
    const result = await generateCoordinationTask(
      parsed.data.task as CoordinationTask,
      parsed.data.context as Record<string, unknown>,
    );
    res.json(GenerateCoordinationAnalysisResponse.parse(result));
  } catch (error) {
    const statusCode = error instanceof GeminiPlanningError ? error.statusCode : 502;
    req.log.error({
      statusCode,
      providerDiagnostic: error instanceof GeminiPlanningError ? error.providerDiagnostic : undefined,
      err: error,
    }, "Gemini coordination analysis failed");
    res.status(statusCode).json({
      error: error instanceof GeminiPlanningError
        ? error.message
        : "Unable to generate a coordination analysis.",
    });
  }
});

type OpenAIResponse = {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
  error?: {
    code?: string;
    message?: string;
    type?: string;
  };
};

router.post("/ai/explain-overlap", async (req, res) => {
  const parsed = ExplainOverlapBody.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({ error: "A valid prompt is required." });
  }

  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    req.log.error("OPENAI_API_KEY is not configured");
    return res.status(500).json({ error: "AI service is not configured." });
  }

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: parsed.data.prompt }],
        max_tokens: 300,
      }),
    });

    const payload = (await response.json()) as OpenAIResponse;

    if (!response.ok) {
      req.log.error(
        {
          status: response.status,
          providerCode: payload.error?.code,
          providerType: payload.error?.type,
        },
        "OpenAI request failed",
      );

      if (response.status === 429) {
        return res
          .status(429)
          .json({ error: "OpenAI is rate-limited or the key has no available quota." });
      }

      return res.status(502).json({ error: "AI provider request failed." });
    }

    const explanation = payload.choices?.[0]?.message?.content?.trim();

    if (!explanation) {
      req.log.error("OpenAI returned an empty explanation");
      return res.status(502).json({ error: "AI provider returned no explanation." });
    }

    return res.json(ExplainOverlapResponse.parse({ explanation }));
  } catch (error) {
    req.log.error({ err: error }, "AI explanation request failed");
    return res.status(502).json({ error: "Unable to generate an explanation." });
  }
});

export default router;