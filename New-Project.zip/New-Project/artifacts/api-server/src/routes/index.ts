import { Router, type IRouter } from "express";
import aiRouter from "./ai";
import feedbackRouter from "./feedback";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(aiRouter);
router.use(feedbackRouter);

export default router;
