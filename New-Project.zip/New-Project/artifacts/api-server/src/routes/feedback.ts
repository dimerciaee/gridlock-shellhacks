import { Router, type IRouter } from "express";
import { db, feedbackTable } from "@workspace/db";
import { SubmitFeedbackBody, SubmitFeedbackResponse } from "@workspace/api-zod";

const router: IRouter = Router();
const SAVED_MESSAGE = "Thank you. Your feedback has been saved for the GridLock team.";
const RATE_WINDOW_MS = 15 * 60 * 1000;
const RATE_LIMIT = 5;
const submissionsByIp = new Map<string, { windowStart: number; count: number }>();

function isRateLimited(ip: string, now = Date.now()): boolean {
  const current = submissionsByIp.get(ip);
  if (!current || now - current.windowStart >= RATE_WINDOW_MS) {
    submissionsByIp.set(ip, { windowStart: now, count: 1 });
    return false;
  }

  if (current.count >= RATE_LIMIT) return true;
  current.count += 1;
  return false;
}

router.post("/feedback", async (req, res): Promise<void> => {
  const origin = req.get("origin");
  const host = req.get("host")?.toLowerCase();
  if (origin) {
    let originHost: string;
    try {
      originHost = new URL(origin).host.toLowerCase();
    } catch {
      res.status(403).json({ error: "Feedback must be submitted from GridLock." });
      return;
    }

    if (!host || originHost !== host) {
      res.status(403).json({ error: "Feedback must be submitted from GridLock." });
      return;
    }
  }

  const parsed = SubmitFeedbackBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a feedback type and enter a message under 2,000 characters." });
    return;
  }

  const ip = req.ip || "unknown";
  if (isRateLimited(ip)) {
    res.status(429).json({ error: "Please wait before submitting more feedback." });
    return;
  }

  // Return the same receipt for the hidden honeypot, without saving its content.
  if (parsed.data.website?.trim()) {
    res.status(201).json(SubmitFeedbackResponse.parse({ message: SAVED_MESSAGE }));
    return;
  }

  const message = parsed.data.message.trim();
  if (!message) {
    res.status(400).json({ error: "Please enter a feedback message." });
    return;
  }

  try {
    const [saved] = await db
      .insert(feedbackTable)
      .values({ category: parsed.data.category, message })
      .returning({ id: feedbackTable.id });

    req.log.info({ feedbackId: saved.id, category: parsed.data.category }, "GridLock feedback saved");
    res.status(201).json(SubmitFeedbackResponse.parse({ message: SAVED_MESSAGE }));
  } catch (error) {
    req.log.error({ err: error }, "Unable to save GridLock feedback");
    res.status(500).json({ error: "Feedback could not be saved. Please try again later." });
  }
});

export default router;