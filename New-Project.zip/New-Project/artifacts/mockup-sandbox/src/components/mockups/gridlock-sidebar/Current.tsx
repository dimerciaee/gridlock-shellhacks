import './_group.css';

const metrics = [
  ['Point distance', '3.02 mi', 'Straight-line distance between independently located endpoints; not either project’s full route.'],
  ['Planning dates', 'Dec 1, 2026 / Jun 1, 2026', '183 days apart. Published dates are planning values, not a confirmed joint schedule.'],
  ['Suggested future window', 'Within 30 days, ahead of Dec 1, 2026', 'Suggested by the caller; not a scheduled meeting.'],
  ['Potential savings', '$1.2M – $2.0M', 'Distance-tier illustration only—not a project estimate.'],
  ['Potential schedule reduction', '30–90 days · illustrative only', 'Scenario placeholder; not calculated from project schedules.'],
  ['Implementation difficulty', 'Medium · concept-level', 'Verify route, scope, permits, and access.'],
];

export function Current() {
  return (
    <div className="gridlock-sidebar-preview">
      <header className="app-header">
        <div className="brand-line">
          <span className="brand-mark" aria-hidden="true"><span /><span /><span /><span /></span>
          <div>
            <div className="eyebrow">UTILITY PLANNING / FIELD VIEW</div>
            <h1>GridLock<span className="brand-period">.</span></h1>
          </div>
        </div>
        <div className="scenario-bar">
          <span className="scenario-label"><span className="scenario-dot" /> TWO PLANNING LENSES</span>
          <label className="storm-toggle"><input type="checkbox" /> Resilience Operations View</label>
        </div>
        <div className="mode-intro">
          <h2>Project Coordination</h2>
          <p>Compare utility projects, review nearby candidates, and trace the evidence behind each match.</p>
        </div>
        <p className="evidence-alert">Plan project coordination and scenario-based facility readiness in one view.</p>
        <button className="feedback-trigger" type="button">Send feedback</button>
      </header>

      <section className="action-center">
        <div className="action-center-heading">
          <div className="section-kicker"><span>01 / COORDINATION</span><span>PLANNING WORKFLOW</span></div>
          <h2>Coordination Action Center</h2>
          <p>Turn nearby project points into a practical discussion plan.</p>
        </div>
        <p className="local-planning-note">Status and selected actions are saved in this browser only. No contact is sent and no utility agreement is implied.</p>
        <article className="coordination-action-card">
          <header className="coordination-card-header">
            <div className="coordination-card-eyebrow">COORDINATION OPPORTUNITY</div>
            <span className="coordination-participating-label">Participating utilities</span>
            <div className="coordination-participating-utilities">Dominion Energy South Carolina ↔ Georgia Power</div>
            <p className="coordination-card-projects">Jasper – Okatie 230 kV #2 ↔ SAV: McIntosh–Purrysburg 230 kV reactors</p>
            <span className="coordination-source-badge">Public-source point proximity</span>
          </header>
          <section className="coordination-impact">
            <div className="coordination-subhead">Estimated impact &amp; planning context</div>
            <p className="coordination-muted">Illustrative scenarios only—not verified estimates or commitments.</p>
            <div className="coordination-meta-grid">
              {metrics.map(([label, value, explanation]) => (
                <div className="coordination-value-row" key={label}>
                  <div className="coordination-value-heading">
                    <span className="coordination-value-label">{label}</span>
                    <strong className="coordination-value">{value}</strong>
                  </div>
                  <p className="coordination-value-explanation">{explanation}</p>
                </div>
              ))}
            </div>
          </section>
          <p className="coordination-caveat">Located endpoints show point proximity only. This does not establish a full route or shared construction.</p>
          <div className="coordination-card-body">
            <strong>Suggested next step</strong>
            <span>Confirm project locations and schedules with both utilities.</span>
            <strong>Plan actions</strong>
            <span>Choose a status, review actions, and prepare a discussion plan.</span>
          </div>
          <footer className="coordination-card-footer">Open coordination workspace · Browser-local selection · no contacts sent</footer>
        </article>
      </section>

      <section className="priority-panel">
        <div className="section-kicker"><span>02 / FACILITY TRIAGE</span><span>DEMO RANKING</span></div>
        <strong>Priority sites: 3 facilities</strong>
      </section>
      <details className="control-fold"><summary>Opportunity filters <span className="fold-hint">Utility filters</span></summary></details>
      <details className="control-fold"><summary>Map layers &amp; conditions <span className="fold-hint">6 layers</span></summary></details>
      <details className="control-fold"><summary>Coordination evidence <span className="fold-hint">Sources &amp; candidates</span></summary></details>
      <details className="control-fold"><summary>Technical Validation <span className="fold-hint">Methodology</span></summary></details>
    </div>
  );
}