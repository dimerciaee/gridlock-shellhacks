import './_group.css';

export function ClearerOrder() {
  return (
    <div className="gridlock-sidebar-preview">
      <header className="app-header">
        <div className="brand-line">
          <span className="brand-mark" aria-hidden="true"><span /><span /><span /><span /></span>
          <div>
            <div className="eyebrow">UTILITY PROJECT PLANNING</div>
            <h1>GridLock<span className="brand-period">.</span></h1>
          </div>
        </div>
        <div className="scenario-bar">
          <span className="scenario-label"><span className="scenario-dot" /> PROJECT VIEW</span>
          <label className="storm-toggle"><input type="checkbox" /> Storm view</label>
        </div>
        <div className="mode-intro">
          <h2>Project coordination</h2>
          <p>Find nearby work and plan a next step.</p>
        </div>
      </header>

      <section className="action-center">
        <div className="action-center-heading">
          <div className="section-kicker"><span>COORDINATION</span></div>
          <h2>Nearby opportunities</h2>
        </div>
        <p className="local-planning-note">Your plan stays in this browser. Nothing is sent.</p>
        <article className="coordination-action-card">
          <header className="coordination-card-header">
            <div className="coordination-card-eyebrow">PUBLIC-SOURCE POINT PROXIMITY</div>
            <div className="coordination-participating-utilities">Dominion Energy South Carolina ↔ Georgia Power</div>
            <p className="coordination-card-projects">Jasper–Okatie ↔ McIntosh–Purrysburg</p>
            <p className="coordination-card-projects"><strong>3.02 mi apart</strong> · Planned dates 183 days apart</p>
          </header>
          <p className="coordination-caveat">Located points show proximity only—not a full route or confirmed shared construction.</p>
          <div className="coordination-card-body">
            <strong>Suggested next step</strong>
            <span>Confirm locations and schedules with both utilities.</span>
          </div>
          <details className="control-fold">
            <summary>Dates, estimates &amp; sources <span className="fold-hint">Details</span></summary>
          </details>
          <details className="control-fold">
            <summary>Plan this opportunity <span className="fold-hint">Actions</span></summary>
          </details>
        </article>
      </section>

      <section className="priority-panel">
        <div className="section-kicker"><span>FACILITY PRIORITY</span><span>DEMO</span></div>
        <strong>Top facilities</strong>
      </section>
      <details className="control-fold"><summary>Project filters <span className="fold-hint">2 utilities</span></summary></details>
      <details className="control-fold"><summary>Map layers <span className="fold-hint">6 layers</span></summary></details>
      <details className="control-fold"><summary>Sources &amp; project data <span className="fold-hint">Evidence</span></summary></details>
      <details className="control-fold"><summary>How it works <span className="fold-hint">Method</span></summary></details>

      <footer className="sidebar-feedback-footer">
        <p>Questions or suggestions?</p>
        <button className="feedback-trigger" type="button">Send feedback</button>
      </footer>
    </div>
  );
}