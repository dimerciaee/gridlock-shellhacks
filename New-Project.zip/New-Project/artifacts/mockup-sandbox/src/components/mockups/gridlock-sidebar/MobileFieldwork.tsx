import { useEffect, useRef, useState, type FormEvent } from "react";
import "./MobileFieldwork.css";

type View = "projects" | "facilities" | "map";
type Stage =
  | "opportunity-identified"
  | "contact-initiated"
  | "joint-review"
  | "resource-sharing-plan"
  | "construction-coordination"
  | "complete";

const stages: { value: Stage; label: string }[] = [
  { value: "opportunity-identified", label: "Opportunity identified" },
  { value: "contact-initiated", label: "Contact initiated" },
  { value: "joint-review", label: "Joint review" },
  { value: "resource-sharing-plan", label: "Resource-sharing plan" },
  { value: "construction-coordination", label: "Construction coordination" },
  { value: "complete", label: "Complete" },
];

const actionOptions = [
  "Survey contractor",
  "Permitting schedule",
  "Staging yard",
  "Environmental review",
  "Shared right-of-way access",
];

const outlineSteps = [
  "Schedule planning review.",
  "Compare contractor schedules.",
  "Evaluate shared staging locations.",
  "Coordinate permitting activities.",
  "Review resilience and storm preparedness impacts.",
];

const stageCopy: Record<Stage, string> = {
  "opportunity-identified": "Opportunity identified — a local planning marker only.",
  "contact-initiated": "Contact initiated — not an external contact log.",
  "joint-review": "Joint review — no meeting has been scheduled.",
  "resource-sharing-plan": "Resource-sharing plan — availability is unverified.",
  "construction-coordination": "Construction coordination — no commitment is implied.",
  complete: "Complete — local status only; no utility work is verified.",
};

function BrandMark() {
  return (
    <span className="mf-mark" aria-hidden="true">
      <span />
      <span />
      <span />
      <span />
    </span>
  );
}

function MapSketch() {
  return (
    <div className="mf-map-wrap">
      <div
        className="mf-map-graphic"
        role="img"
        aria-label="Schematic point proximity view linking two independently located endpoints; not a project route"
      >
        <span className="mf-map-river" aria-hidden="true" />
        <span className="mf-map-label mf-map-label-one">Jasper</span>
        <span className="mf-map-label mf-map-label-two">McIntosh</span>
        <span className="mf-map-pair" aria-hidden="true" />
        <span className="mf-map-marker mf-map-marker-a" aria-hidden="true" />
        <span className="mf-map-marker mf-map-marker-b" aria-hidden="true" />
        <span className="mf-map-distance">3.02 mi</span>
      </div>
      <div className="mf-map-caption">
        <span><strong>Point proximity</strong><br />Independently located endpoints</span>
        <span>Not a route<br />or overlap finding</span>
      </div>
      <div className="mf-map-legend" aria-label="Point proximity map key">
        <span className="mf-legend-entry"><i className="mf-legend-dot" /> Jasper endpoint</span>
        <span className="mf-legend-entry"><i className="mf-legend-dot is-coral" /> McIntosh endpoint</span>
        <span className="mf-legend-entry"><i className="mf-legend-dash" /> Straight-line point distance</span>
      </div>
    </div>
  );
}

function Metric({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="mf-metric">
      <dt>{label}</dt>
      <dd>{value}</dd>
      <p>{note}</p>
    </div>
  );
}

export function MobileFieldwork() {
  const [view, setView] = useState<View>(() =>
    typeof window !== "undefined" && window.matchMedia("(max-width: 760px)").matches
      ? "map"
      : "projects",
  );
  const [stormView, setStormView] = useState(false);
  const [stage, setStage] = useState<Stage>("opportunity-identified");
  const [selectedActions, setSelectedActions] = useState<string[]>([]);
  const [inFieldPlan, setInFieldPlan] = useState(false);
  const [outlineOpen, setOutlineOpen] = useState(false);
  const [note, setNote] = useState("");
  const [savedNote, setSavedNote] = useState("");
  const [utilityA, setUtilityA] = useState("Dominion Energy South Carolina");
  const [utilityB, setUtilityB] = useState("Georgia Power");
  const [layers, setLayers] = useState<string[]>(["Nearby project points"]);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedbackType, setFeedbackType] = useState("Suggestion");
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackStatus, setFeedbackStatus] = useState("");
  const feedbackTriggerRef = useRef<HTMLButtonElement>(null);
  const feedbackCloseRef = useRef<HTMLButtonElement>(null);
  const wasFeedbackOpen = useRef(false);
  const pairUtilities = ["Dominion Energy South Carolina", "Georgia Power"];
  const selectedFilters = [utilityA, utilityB].filter((utility) => utility !== "All utilities");
  const showSourcedPair =
    selectedFilters.every((utility) => pairUtilities.includes(utility)) &&
    !(utilityA === utilityB && utilityA !== "All utilities");

  const selectView = (nextView: View) => {
    setView(nextView);
    if (window.matchMedia("(max-width: 760px)").matches) {
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
    }
  };

  useEffect(() => {
    if (feedbackOpen) {
      wasFeedbackOpen.current = true;
      feedbackCloseRef.current?.focus();
    } else if (wasFeedbackOpen.current) {
      wasFeedbackOpen.current = false;
      feedbackTriggerRef.current?.focus();
    }
  }, [feedbackOpen]);

  useEffect(() => {
    if (!feedbackOpen) return;
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setFeedbackOpen(false);
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [feedbackOpen]);

  const toggleAction = (action: string) => {
    setSelectedActions((current) =>
      current.includes(action)
        ? current.filter((item) => item !== action)
        : [...current, action],
    );
  };

  const toggleLayer = (layer: string) => {
    setLayers((current) =>
      current.includes(layer)
        ? current.filter((item) => item !== layer)
        : [...current, layer],
    );
  };

  const saveNote = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = note.trim();
    if (trimmed) {
      setSavedNote(trimmed);
      setNote("");
    }
  };

  const submitFeedback = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!feedbackText.trim()) return;
    setFeedbackStatus(`Preview only: this anonymous ${feedbackType.toLowerCase()} was not sent or stored.`);
  };

  return (
    <div className="mf-shell" data-view={view}>
      <header className="mf-topbar">
        <a className="mf-brand" href="#gridlock-workspace" aria-label="GridLock fieldwork overview">
          <BrandMark />
          <span>
            <span className="mf-wordmark-kicker">UTILITY PROJECT PLANNING</span>
            <span className="mf-wordmark">GridLock<span>.</span></span>
          </span>
        </a>
        <div className="mf-top-actions">
          <span className="mf-view-tag">PROJECT VIEW</span>
          <label className="mf-storm-switch">
            <input
              type="checkbox"
              checked={stormView}
              onChange={(event) => setStormView(event.target.checked)}
              aria-label="Show simulated storm scenario"
            />
            Storm view
          </label>
        </div>
      </header>

      <div className="mf-topline">
        <section className="mf-intro" aria-labelledby="mf-title">
          <div className="mf-intro-copy">
            <div className="mf-kicker">Southeast utility corridor / field view</div>
            <h2 id="mf-title">{stormView ? "Storm readiness" : "Project coordination"}</h2>
            <p>
              {stormView
                ? "Review demo facilities near a simulated corridor. This is a planning scenario, not an operational forecast."
                : "Compare nearby public-source points, review demo candidates, and prepare a careful planning discussion."}
            </p>
          </div>
          <div className="mf-privacy-chip">Browser-local planning · nothing is sent</div>
        </section>
      </div>

      <nav className="mf-tabs" aria-label="Planning views">
        {([
          ["projects", "Nearby projects"],
          ["facilities", "Facility priority"],
          ["map", "Point map"],
        ] as [View, string][]).map(([value, label]) => (
          <button
            className="mf-tab"
            type="button"
            key={value}
            aria-current={view === value ? "page" : undefined}
            onClick={() => selectView(value)}
          >
            {label}
          </button>
        ))}
      </nav>

      <main className="mf-workspace" id="gridlock-workspace">
        <section className="mf-main-column" aria-label="Planning workspace">
          {view === "projects" && (
            <>
              <div className="mf-section-heading">
                <div>
                  <div className="mf-kicker">Coordination / 01</div>
                  <h3>Nearby opportunities</h3>
                </div>
                <p>One sourced point pair<br />plus demo candidates</p>
              </div>

              {showSourcedPair ? (
              <article className="mf-card" aria-labelledby="mf-pair-title">
                <header className="mf-card-head">
                  <div className="mf-card-overline">
                    <span>Coordination opportunity</span>
                    <span className="mf-source-pill">Public-source point proximity</span>
                  </div>
                  <span className="mf-utility-label">Participating utilities</span>
                  <p className="mf-utilities" id="mf-pair-title">
                    Dominion Energy South Carolina <span aria-hidden="true">↔</span> Georgia Power
                  </p>
                  <p className="mf-project-pair">
                    Jasper–Okatie 230 kV #2 <span aria-hidden="true">↔</span> SAV: McIntosh–Purrysburg 230 kV reactors
                  </p>
                  <p className="mf-key-facts">
                    <strong>3.02 mi</strong>
                    <span>between located endpoints</span>
                    <span aria-hidden="true">·</span>
                    <span>Planned dates 183 days apart</span>
                  </p>
                </header>

                <p className="mf-caveat">
                  Located endpoints show point proximity only—not a full project route, confirmed overlap, joint construction, or utility commitment.
                </p>

                <details className="mf-disclosure">
                  <summary>Dates, estimates &amp; source context</summary>
                  <div className="mf-detail-content">
                    <p className="mf-detail-lead">Illustrative planning context only—not utility estimates or commitments.</p>
                    <dl className="mf-metric-list">
                      <Metric
                        label="Point distance"
                        value="3.02 mi"
                        note="Straight-line distance between independently located endpoints; not either project’s full route."
                      />
                      <Metric
                        label="Planned in-service dates"
                        value="Dec 1, 2026 / Jun 1, 2026"
                        note="183 days apart. Published planning values, not a confirmed joint schedule."
                      />
                      <Metric
                        label="Suggested future window"
                        value="Within 30 days, ahead of Dec 1, 2026"
                        note="Suggested by the demo; not a scheduled meeting."
                      />
                      <Metric
                        label="Potential savings"
                        value="$1.2M–$2.0M · illustrative"
                        note="Distance-tier illustration only—not a project estimate."
                      />
                      <Metric
                        label="Potential schedule reduction"
                        value="30–90 days · illustrative"
                        note="Scenario placeholder; not calculated from project schedules."
                      />
                      <Metric
                        label="Implementation difficulty"
                        value="Medium · concept-level"
                        note="Verify route, scope, permits, and access."
                      />
                    </dl>
                    <p className="mf-detail-lead">
                      Evidence is tied to named endpoints and cited filings. Sample project locations and dates elsewhere in the demo need filing verification.
                    </p>
                  </div>
                </details>

                <div className="mf-card-body">
                  <div className="mf-next-step">
                    <span className="mf-step-index">01</span>
                    <div>
                      <h4>Suggested next step</h4>
                      <p>Confirm project locations and schedules with both utilities.</p>
                    </div>
                  </div>

                  <section className="mf-plan-control" aria-labelledby="mf-stage-title">
                    <p className="mf-subheading" id="mf-stage-title">Local collaboration progress</p>
                    <p className="mf-control-note">Choose a planning stage. This is not an external contact log.</p>
                    <div className="mf-timeline" role="group" aria-label="Six-stage local coordination status">
                      {stages.map((item, index) => (
                        <button
                          className="mf-stage"
                          type="button"
                          key={item.value}
                          aria-pressed={stage === item.value}
                          aria-label={`Set local planning stage: ${item.label}`}
                          onClick={() => setStage(item.value)}
                        >
                          <span className="mf-stage-number">{String(index + 1).padStart(2, "0")}</span>
                          <span className="mf-stage-name">{item.label}</span>
                        </button>
                      ))}
                    </div>
                    <p className="mf-status-caption" aria-live="polite">{stageCopy[stage]}</p>
                  </section>

                  <section className="mf-plan-control" aria-labelledby="mf-actions-title">
                    <p className="mf-subheading" id="mf-actions-title">Suggested coordination actions</p>
                    <p className="mf-control-note">Select prompts for a local planning draft. Selection does not mark work complete.</p>
                    <div className="mf-action-list">
                      {actionOptions.map((action) => (
                        <label className="mf-action" key={action}>
                          <input
                            type="checkbox"
                            checked={selectedActions.includes(action)}
                            onChange={() => toggleAction(action)}
                          />
                          <span>{action}</span>
                        </label>
                      ))}
                    </div>
                    <p className="mf-selected-count" aria-live="polite">
                      {selectedActions.length
                        ? `${selectedActions.length} prompt${selectedActions.length === 1 ? "" : "s"} selected for this preview`
                        : "No discussion prompts selected"}
                    </p>
                  </section>

                  <section className="mf-plan-control">
                    <p className="mf-subheading">Recommended shared resources</p>
                    <p className="mf-control-note">Discussion candidates only; availability and authorization are unverified.</p>
                    <p className="mf-control-note">Construction crews · Crane equipment · Environmental studies · Staging yard · Permitting reviews</p>
                  </section>

                  <section className="mf-plan-control">
                    <p className="mf-subheading">Local planning template</p>
                    <p className="mf-control-note">A discussion aid only. No AI service is called and no meeting is scheduled.</p>
                    <button
                      className="mf-secondary-button"
                      type="button"
                      aria-expanded={outlineOpen}
                      onClick={() => setOutlineOpen((open) => !open)}
                    >
                      {outlineOpen ? "Hide planning outline" : "Prepare local planning outline"}
                    </button>
                    {outlineOpen && (
                      <div className="mf-outline-result" aria-live="polite">
                        <strong>Local template · not an approved plan</strong>
                        <ol>{outlineSteps.map((step) => <li key={step}>{step}</li>)}</ol>
                      </div>
                    )}
                  </section>
                </div>

                <footer className="mf-card-footer">
                  <span>Status &amp; selections stay in this preview</span>
                  <button
                    className="mf-add-button"
                    type="button"
                    aria-pressed={inFieldPlan}
                    onClick={() => setInFieldPlan((selected) => !selected)}
                  >
                    {inFieldPlan ? "Added to field plan" : "Add to field plan"}
                  </button>
                </footer>
              </article>
              ) : (
                <section className="mf-panel mf-empty-filter" aria-live="polite">
                  <span className="mf-kicker">No matching opportunities</span>
                  <h3>Try a different utility pair</h3>
                  <p>The preview’s sourced point-pair record includes Dominion Energy South Carolina and Georgia Power.</p>
                  <button
                    className="mf-secondary-button"
                    type="button"
                    onClick={() => {
                      setUtilityA("Dominion Energy South Carolina");
                      setUtilityB("Georgia Power");
                    }}
                  >
                    Reset utility filters
                  </button>
                </section>
              )}

              <details className="mf-panel">
                <summary className="mf-disclosure">
                  <span>Draft a coordination request</span>
                </summary>
                <div className="mf-detail-content mf-request-form">
                  <p className="mf-detail-lead">Browser-local draft only. Nothing is sent, approved, or shared with another utility.</p>
                  <label>
                    Request type
                    <select aria-label="Request type">
                      <option>Equipment sharing</option>
                      <option>Crew sharing</option>
                      <option>Permit coordination</option>
                      <option>Emergency planning</option>
                      <option>Environmental review</option>
                    </select>
                  </label>
                  <p className="mf-detail-lead">Projects are 3.02 mi apart by straight-line point distance; that does not establish full-route overlap.</p>
                </div>
              </details>
            </>
          )}

          {view === "facilities" && (
            <>
              <div className="mf-section-heading">
                <div>
                  <div className="mf-kicker">Facility triage / 02</div>
                  <h3>Demo facility priority</h3>
                </div>
                <span className="mf-demo-label">DEMO</span>
              </div>
              <section className="mf-panel" aria-labelledby="mf-priority-title">
                <div className="mf-panel-head">
                  <div>
                    <h3 id="mf-priority-title">Priority categories</h3>
                    <p>Demo facility ranking labels from the scenario map. Facility-specific impacts are not assessed here.</p>
                  </div>
                </div>
                <div className="mf-facility-list">
                  <div className="mf-priority-row">
                    <span className="mf-priority-rank">H</span>
                    <div><strong>High priority</strong><p>Scenario ranking category only; not a dispatch or restoration priority.</p></div>
                  </div>
                  <div className="mf-priority-row">
                    <span className="mf-priority-rank">R</span>
                    <div><strong>Review</strong><p>Demo category for planner review; no customer impact is assessed.</p></div>
                  </div>
                  <div className="mf-priority-row">
                    <span className="mf-priority-rank">M</span>
                    <div><strong>Monitor</strong><p>Demo category only; facility conditions are not verified.</p></div>
                  </div>
                </div>
                {stormView && (
                  <div className="mf-scenario">
                    <div className="mf-scenario-top"><span>STORM SCENARIO</span><span>SIMULATED</span></div>
                    <h4>Storm readiness</h4>
                    <p>Review staging options with utility planners. Not a dispatch recommendation.</p>
                    <div className="mf-scenario-facts">
                      <div><span>Shared response assets</span><strong>Not assessed</strong></div>
                      <div><span>Restoration impact</span><strong>Not estimated</strong></div>
                      <div><span>Customer / outage impact</span><strong>Not assessed</strong></div>
                      <div><span>Corridor status</span><strong>Simulated path only</strong></div>
                    </div>
                  </div>
                )}
              </section>
              <details className="mf-panel">
                <summary className="mf-disclosure"><span>Scenario status</span></summary>
                <div className="mf-detail-content">
                  <p className="mf-detail-lead">{stormView ? "Storm view on · scenario corridor simulated" : "Storm view off · scenario corridor off"}</p>
                  <p className="mf-detail-lead">Customer impact not assessed. Storm corridors are simulated; impacts are not evaluated.</p>
                </div>
              </details>
            </>
          )}

          {view === "map" && (
            <>
              <div className="mf-section-heading">
                <div>
                  <div className="mf-kicker">Evidence map / 03</div>
                  <h3>Located point pair</h3>
                </div>
                <p>Public-source<br />point proximity</p>
              </div>
              <section className="mf-panel" aria-label="Schematic endpoint proximity">
                <div className="mf-panel-head">
                  <div>
                    <h3>Jasper ↔ McIntosh</h3>
                    <p>Named endpoints associated with the sourced project pair.</p>
                  </div>
                  <span className="mf-source-pill">SOURCED POINTS</span>
                </div>
                <MapSketch />
              </section>
              <div className="mf-caveat">
                The dashed connector is a point-distance cue only. It is not a full route, confirmed project overlap, or evidence of joint construction.
              </div>
            </>
          )}

          <details className="mf-panel">
            <summary className="mf-disclosure"><span>Project filters</span></summary>
            <div className="mf-filter-content">
              <div className="mf-filter-grid">
                <label>
                  First utility
                  <select value={utilityA} onChange={(event) => setUtilityA(event.target.value)}>
                    <option>Dominion Energy South Carolina</option>
                    <option>Georgia Power</option>
                    <option>All utilities</option>
                  </select>
                </label>
                <label>
                  Second utility
                  <select value={utilityB} onChange={(event) => setUtilityB(event.target.value)}>
                    <option>Georgia Power</option>
                    <option>Dominion Energy South Carolina</option>
                    <option>All utilities</option>
                  </select>
                </label>
              </div>
              <p>Showing {showSourcedPair ? "the sourced point pair" : "no pair"} for this local filter. Map centers are not source verification.</p>
            </div>
          </details>

          <details className="mf-panel">
            <summary className="mf-disclosure"><span>Map layers</span></summary>
            <div className="mf-source-content">
              <p>Show on map</p>
              <div className="mf-layer-list">
                {["Dominion projects", "Georgia projects", "Overlaps and sourced proximity", "Existing transmission lines", "Existing substations", "NOAA weather and alerts near map center"].map((layer) => (
                  <label key={layer}>
                    <input
                      type="checkbox"
                      checked={layers.includes(layer)}
                      onChange={() => toggleLayer(layer)}
                    />
                    {layer}
                  </label>
                ))}
              </div>
              <p>{layers.length} map layer{layers.length === 1 ? "" : "s"} selected in this preview. Nearby assets do not establish a project connection. NOAA conditions are not loaded here.</p>
            </div>
          </details>

          <details className="mf-panel">
            <summary className="mf-disclosure"><span>Sources &amp; project data</span></summary>
            <div className="mf-source-content">
              <p><strong>Sourced point pair:</strong> independently located Jasper and McIntosh endpoints with cited filing project names and dates. Point proximity is not full-route overlap.</p>
              <p><strong>Demo candidates:</strong> project centers under 25 miles apart are candidates—not confirmed shared construction. Sample locations and dates need filing verification.</p>
              <p><strong>Workbook candidates:</strong> submitted distances and date gaps are not independently verified and are not counted as sourced pairs.</p>
              <p><strong>Public leads:</strong> selected research records are not a complete Georgia Power transmission plan and do not supply verified project centers by themselves.</p>
            </div>
          </details>

          <details className="mf-panel">
            <summary className="mf-disclosure"><span>How it works</span></summary>
            <div className="mf-method-content">
              <p><strong>Find:</strong> identify candidate project points from public records.</p>
              <p><strong>Verify:</strong> compare endpoint names and locations with utility planning documents. Unverified matches remain labeled.</p>
              <p><strong>Compare:</strong> show straight-line point distance and planned-date context when available.</p>
              <p>Do not import confidential transmission information or CEII. Customer impacts, outage impacts, hazards, shared work, and savings are not assessed.</p>
            </div>
          </details>
        </section>

        <aside className="mf-side-column" aria-label="Map and local planning">
          <section className="mf-panel mf-side-map" aria-labelledby="mf-map-heading">
            <div className="mf-panel-head">
              <div>
                <div className="mf-kicker">Scenario map</div>
                <h3 id="mf-map-heading">Southeast corridor</h3>
                <p>Map centers are not source verification.</p>
              </div>
              <span className="mf-demo-label">SCHEMATIC</span>
            </div>
            <MapSketch />
          </section>

          {stormView && (
            <section className="mf-scenario" aria-live="polite">
              <div className="mf-scenario-top"><span>STORM SCENARIO</span><span>SIMULATED</span></div>
              <h4>Storm readiness</h4>
              <p>See which demo projects and facilities are near a simulated corridor.</p>
              <div className="mf-scenario-facts">
                <div><span>Shared response assets</span><strong>Not assessed</strong></div>
                <div><span>Restoration impact</span><strong>Not estimated</strong></div>
              </div>
              <p style={{ marginTop: 9 }}>Storm corridor distance is not hazard, outage likelihood, or dispatch priority. Customer impacts are not assessed.</p>
            </section>
          )}

          <section className="mf-panel mf-notes-card" aria-labelledby="mf-note-title">
            <div className="mf-kicker">Field note / local only</div>
            <h3 id="mf-note-title">Keep a planning question</h3>
            <p>Notes stay in this browser preview and are not sent or persisted outside it.</p>
            <form className="mf-note-form" onSubmit={saveNote}>
              <label htmlFor="mf-local-note">Your local planning note</label>
              <textarea
                id="mf-local-note"
                value={note}
                maxLength={500}
                onChange={(event) => setNote(event.target.value)}
                placeholder="A question to raise during a planning discussion"
              />
              <button className="mf-plan-button" type="submit" disabled={!note.trim()}>
                Save note in preview
              </button>
            </form>
            {savedNote && <p className="mf-note-saved" role="status">Local note: {savedNote}</p>}
          </section>

          <section className="mf-panel mf-notes-card">
            <div className="mf-kicker">Discussion guardrails</div>
            <h3>Keep the record careful</h3>
            <p>Do not add personal, confidential utility, or CEII information. Feedback is anonymous in this preview and is not sent.</p>
            <button ref={feedbackTriggerRef} className="mf-secondary-button" type="button" onClick={() => { setFeedbackOpen(true); setFeedbackStatus(""); }}>
              Share anonymous feedback
            </button>
          </section>
        </aside>
      </main>

      <footer className="mf-footer">
        <span>GridLock / infrastructure coordination demo</span>
        <span>Illustrative planning context · not operational guidance</span>
      </footer>

      {feedbackOpen && (
        <div className="mf-feedback-scrim" onMouseDown={(event) => { if (event.target === event.currentTarget) setFeedbackOpen(false); }}>
          <section className="mf-feedback-dialog" role="dialog" aria-modal="true" aria-labelledby="mf-feedback-title">
            <button ref={feedbackCloseRef} className="mf-close" type="button" aria-label="Close feedback" onClick={() => setFeedbackOpen(false)}>Close</button>
            <div className="mf-kicker">Anonymous preview feedback</div>
            <h2 id="mf-feedback-title">Questions or suggestions?</h2>
            <p>Try a suggestion, bug report, or data issue. Nothing leaves this preview.</p>
            <form className="mf-feedback-form" onSubmit={submitFeedback}>
              <label>
                Feedback type
                <select value={feedbackType} onChange={(event) => setFeedbackType(event.target.value)}>
                  <option>Suggestion</option>
                  <option>Bug report</option>
                  <option>Data issue</option>
                  <option>Other</option>
                </select>
              </label>
              <label>
                Your feedback
                <textarea
                  value={feedbackText}
                  onChange={(event) => setFeedbackText(event.target.value)}
                  maxLength={1000}
                  required
                  placeholder="What should be clearer?"
                />
              </label>
              <div className="mf-feedback-privacy">
                Do not include personal information, confidential utility data, or CEII. Feedback is anonymous and not sent in this preview.
              </div>
              <p className="mf-feedback-status" role="status" aria-live="polite">{feedbackStatus}</p>
              {feedbackStatus
                ? <button className="mf-plan-button" type="button" onClick={() => setFeedbackOpen(false)}>Done</button>
                : <button className="mf-plan-button" type="submit">Review feedback locally</button>}
            </form>
          </section>
        </div>
      )}
    </div>
  );
}