import { useState } from 'react';
import './_group.css';

type Opportunity = {
  id: string;
  eyebrow: string;
  utilityPair: string;
  projectLine: string;
  reason: string;
  nextAction: string;
  sourceLabel: string;
  total: string;
  factors: string[];
  evidence: string[];
  caveat: string;
};

const opportunities: Opportunity[] = [
  {
    id: 'okatie',
    eyebrow: '01 · DATE + LOCATION ALIGNMENT',
    utilityPair: 'Dominion Energy South Carolina ↔ Georgia Power',
    projectLine: 'Okatie–Bluffton 115kV rebuild · nearby Georgia Power planned work',
    reason:
      'The named, source-linked project points are close, and their planned dates create a practical reason to compare timing.',
    nextAction:
      'Ask both planning teams to confirm current dates and whether a joint sequencing review would be useful.',
    sourceLabel: 'Mapped points · source-linked',
    total: '75 / 120',
    factors: [
      'Distance: +30',
      'Shared infrastructure: not assessed',
      'Date gap: +20',
      'Project budget: +25',
      'Listed critical site: not assessed',
      'Coastal-area proxy: not assessed',
    ],
    evidence: [
      'Named project endpoints and exact planned in-service dates are source-linked.',
      'The $40.66M Okatie–Bluffton rebuild budget is a user-pasted workbook line; verify it against the current filing.',
    ],
    caveat:
      'Point proximity is not confirmed route overlap. Construction schedule and the Georgia Power budget remain unverified; no shared infrastructure connection is established.',
  },
  {
    id: 'nearby-records',
    eyebrow: '02 · NEARBY SOURCE RECORDS',
    utilityPair: 'Dominion Energy South Carolina ↔ Georgia Power',
    projectLine: 'Two nearby planned-project records · project names not established here',
    reason:
      'The mapped project points are nearby, and their published timing gives planners a reason to compare schedules.',
    nextAction:
      'Confirm the two project names and current in-service dates with each utility before proposing a joint review.',
    sourceLabel: 'Mapped points · source-linked',
    total: '55 / 120',
    factors: [
      'Distance: +20',
      'Shared infrastructure: not assessed',
      'Date gap: +20',
      'Project budget: not assessed',
      'Listed critical site: +15',
      'Coastal-area proxy: not assessed',
    ],
    evidence: [
      'Two source records are represented by nearby mapped project points.',
      'No supported project budget is available for this pair.',
    ],
    caveat:
      'Point proximity is not confirmed route overlap. The points do not establish either full project route or a construction conflict.',
  },
];

const facilities = [
  {
    name: 'Savannah General Hospital',
    type: 'Hospital',
    priority: 'High',
    reason:
      'This demo hospital is near the simulated corridor, making it a useful site to include in a planner-led scenario discussion.',
    total: 92,
    base: 45,
    projectProximity: 15,
    pathExposure: 32,
  },
  {
    name: 'Chatham County Fire Station 7',
    type: 'Fire Station',
    priority: 'Monitor',
    reason:
      'This demo fire station is near the simulated corridor and is included as a discussion context, not a service-dependence finding.',
    total: 68,
    base: 35,
    projectProximity: 10,
    pathExposure: 23,
  },
  {
    name: 'Coastal Pines Nursing Home',
    type: 'Nursing Home',
    priority: 'Low',
    reason:
      'This demo nursing home is outside the nearer scenario band but remains visible for a broader planning conversation.',
    total: 44,
    base: 40,
    projectProximity: 4,
    pathExposure: 0,
  },
];

function ScoreDetails({ opportunity }: { opportunity: Opportunity }) {
  return (
    <details className="ef-disclosure">
      <summary>View Score Details</summary>
      <div className="ef-detail-content">
        <div className="ef-detail-total">
          <span>Utility-pair total</span>
          <strong>{opportunity.total}</strong>
          <small>Known points · 3 of 6 factors assessed</small>
        </div>
        <div className="ef-detail-block">
          <h4>Factor points</h4>
          <ul className="ef-factor-list">
            {opportunity.factors.map((factor) => <li key={factor}>{factor}</li>)}
          </ul>
        </div>
        <div className="ef-detail-block">
          <h4>Evidence and basis</h4>
          {opportunity.evidence.map((item) => <p key={item}>{item}</p>)}
        </div>
        <p className="ef-caveat">{opportunity.caveat}</p>
        <p className="ef-caveat">
          Not established: shared infrastructure, comprehensive critical-site coverage, FEMA flood zone,
          storm surge, hurricane frequency, or measured wind exposure. Any coastal-area proxy is broad
          scenario context, not a measured hazard.
        </p>
      </div>
    </details>
  );
}

function OpportunityCard({
  opportunity,
  onPrepare,
  isActive,
}: {
  opportunity: Opportunity;
  onPrepare: (opportunity: Opportunity) => void;
  isActive: boolean;
}) {
  return (
    <article className={`ef-opportunity ${opportunity.id === 'okatie' ? 'ef-featured' : ''}`}>
      <div className="ef-opportunity-topline">
        <span>{opportunity.eyebrow}</span>
        <span className="ef-source-badge"><i aria-hidden="true" />{opportunity.sourceLabel}</span>
      </div>
      <h3>{opportunity.utilityPair}</h3>
      <p className="ef-project-line">{opportunity.projectLine}</p>
      <div className="ef-why">
        <span className="ef-label">Why it merits review</span>
        <p>{opportunity.reason}</p>
      </div>
      <div className="ef-next">
        <span className="ef-next-mark" aria-hidden="true">→</span>
        <div>
          <span className="ef-label">Recommended next step</span>
          <p>{opportunity.nextAction}</p>
        </div>
      </div>
      <div className="ef-card-footer">
        <button
          className={`ef-primary-action ${isActive ? 'is-active' : ''}`}
          type="button"
          onClick={() => onPrepare(opportunity)}
          aria-pressed={isActive}
        >
          {isActive ? 'Briefing draft open' : 'Prepare discussion brief'}
          <span aria-hidden="true">↗</span>
        </button>
        <ScoreDetails opportunity={opportunity} />
      </div>
    </article>
  );
}

function FacilityCard({
  facility,
}: {
  facility: (typeof facilities)[number];
}) {
  return (
    <article className="ef-facility-card">
      <div className={`ef-priority ef-priority-${facility.priority.toLowerCase()}`}>
        <span>Priority Level</span>
        <strong>{facility.priority}</strong>
      </div>
      <h3>{facility.name}</h3>
      <span className="ef-facility-type">{facility.type}</span>
      <p>{facility.reason}</p>
      <details className="ef-disclosure ef-facility-disclosure">
        <summary>View Score Details</summary>
        <div className="ef-detail-content">
          <p className="ef-scenario-note">
            Illustrative demo breakdown only. These values are not a validated risk measure.
          </p>
          <div className="ef-facility-math">
            <span>Raw facility total <b>{facility.total}</b></span>
            <span>Facility base <b>{facility.base}</b></span>
            <span>Demo project-proximity <b>+{facility.projectProximity}</b></span>
            <span>Simulated weather/path exposure <b>+{facility.pathExposure}</b></span>
          </div>
          <p className="ef-math-check">
            {facility.base} + {facility.projectProximity} + {facility.pathExposure} = {facility.total}
          </p>
        </div>
      </details>
    </article>
  );
}

export function ExecutiveFirst() {
  const [activeBrief, setActiveBrief] = useState<Opportunity | null>(null);
  const [briefText, setBriefText] = useState('');
  const [copyStatus, setCopyStatus] = useState('');

  const prepareBrief = (opportunity: Opportunity) => {
    setActiveBrief(opportunity);
    setBriefText(
      `Discussion request: ${opportunity.utilityPair}\n\n${opportunity.nextAction}\n\nContext: ${opportunity.reason}\n\nPlease confirm current project records, dates, and any useful coordination contact.`,
    );
    setCopyStatus('');
  };

  const copyBrief = async () => {
    try {
      await navigator.clipboard.writeText(briefText);
      setCopyStatus('Brief copied to clipboard.');
    } catch {
      setCopyStatus('Copy is unavailable here. Select the draft text to copy it.');
    }
  };

  return (
    <main className="executive-first">
      <style>{`
        .executive-first {
          --ef-ink: var(--gridlock-ink, #edf3ff);
          --ef-muted: var(--gridlock-muted, #aab8d0);
          --ef-paper: var(--gridlock-paper, #080b13);
          --ef-surface: #111a29;
          --ef-raised: #151f30;
          --ef-line: var(--gridlock-line, #2a3955);
          --ef-pink: var(--gridlock-pink, #ff477e);
          --ef-cyan: var(--gridlock-cyan, #32d9ff);
          min-height: 100vh;
          padding: 0 30px 54px;
          color: var(--ef-ink);
          background:
            radial-gradient(ellipse at 13% 0%, rgb(255 71 126 / 9%), transparent 32%),
            var(--ef-paper);
          font-family: var(--gridlock-body, 'DM Sans', sans-serif);
        }
        .ef-shell { width: min(1100px, 100%); margin: 0 auto; }
        .ef-header {
          display: flex; justify-content: space-between; align-items: flex-start; gap: 24px;
          padding: 28px 0 24px; border-bottom: 1px solid var(--ef-line);
        }
        .ef-brand-line {
          display: flex; align-items: center; gap: 10px; color: #ff9ab4;
          font: 700 10px/1.3 var(--gridlock-mono, monospace); letter-spacing: .1em; text-transform: uppercase;
        }
        .ef-brand-mark {
          display: grid; place-items: center; width: 27px; height: 27px; border: 1px solid #704254;
          border-radius: 7px; background: #271722; color: #ff9ab4; font: 700 13px var(--gridlock-display, sans-serif);
        }
        .ef-header h1 {
          margin: 16px 0 0; color: #f5eefe; font: 700 clamp(30px, 4vw, 46px)/.98 var(--gridlock-display, sans-serif);
          letter-spacing: -.065em;
        }
        .ef-header-copy { max-width: 590px; margin: 10px 0 0; color: var(--ef-muted); font-size: 13px; line-height: 1.55; }
        .ef-context-tag {
          display: flex; flex: none; align-items: center; gap: 9px; margin-top: 2px; padding: 9px 11px;
          border: 1px solid #65404f; border-radius: 5px; background: #211622; color: #ffc1d1;
          font: 700 9px var(--gridlock-mono, monospace); letter-spacing: .06em; text-transform: uppercase;
        }
        .ef-context-tag i { width: 7px; height: 7px; border-radius: 50%; background: var(--ef-pink); }
        .ef-briefing-strip {
          display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 20px;
          margin-top: 24px; padding: 17px 20px; border: 1px solid #39465d; border-radius: 8px;
          background: linear-gradient(110deg, #182233, #111a29 70%);
        }
        .ef-strip-label, .ef-section-kicker, .ef-label {
          color: var(--ef-cyan); font: 700 9px/1.35 var(--gridlock-mono, monospace);
          letter-spacing: .09em; text-transform: uppercase;
        }
        .ef-briefing-strip h2 {
          margin: 5px 0 0; font: 600 17px/1.15 var(--gridlock-display, sans-serif); letter-spacing: -.025em;
        }
        .ef-briefing-strip p { margin: 5px 0 0; color: var(--ef-muted); font-size: 11px; line-height: 1.45; }
        .ef-strip-side { max-width: 260px; padding-left: 18px; border-left: 1px solid #35445b; }
        .ef-strip-side b { display: block; color: #f5eefe; font: 600 13px var(--gridlock-display, sans-serif); }
        .ef-strip-side span { display: block; margin-top: 4px; color: var(--ef-muted); font-size: 10px; line-height: 1.45; }
        .ef-section { padding-top: 36px; }
        .ef-section-heading {
          display: flex; justify-content: space-between; align-items: flex-end; gap: 18px; margin-bottom: 15px;
        }
        .ef-section-heading h2 {
          margin: 5px 0 0; color: #f4eff8; font: 600 25px/1.05 var(--gridlock-display, sans-serif);
          letter-spacing: -.045em;
        }
        .ef-section-subtitle { max-width: 430px; margin: 0; color: var(--ef-muted); font-size: 11px; line-height: 1.5; }
        .ef-source-legend {
          display: flex; flex-wrap: wrap; gap: 9px 17px; margin-bottom: 12px; padding: 10px 12px;
          border: 1px solid #26354b; border-radius: 6px; background: #0d1420;
        }
        .ef-legend-item { display: flex; align-items: center; gap: 8px; color: #c4d0e2; font-size: 10px; line-height: 1.4; }
        .ef-legend-dot { width: 8px; height: 8px; border: 1px solid #65c9d9; border-radius: 50%; background: #65c9d9; }
        .ef-legend-dot.hollow { border-color: #dba359; background: transparent; }
        .ef-legend-note { width: 100%; margin: 0; color: #8899b3; font-size: 9px; line-height: 1.45; }
        .ef-opportunity-list { display: grid; grid-template-columns: 1.12fr .88fr; gap: 12px; align-items: stretch; }
        .ef-opportunity {
          display: flex; flex-direction: column; min-width: 0; padding: 18px 19px 15px;
          border: 1px solid #344159; border-radius: 8px; background: linear-gradient(150deg, #151d2b, #111724);
          box-shadow: 0 5px 18px rgb(2 5 12 / 15%);
        }
        .ef-featured { border-color: #744054; background: linear-gradient(150deg, #241925, #151724 70%); }
        .ef-opportunity-topline { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 8px; }
        .ef-opportunity-topline > span:first-child {
          color: #b8c5d9; font: 700 9px var(--gridlock-mono, monospace); letter-spacing: .055em;
        }
        .ef-source-badge {
          display: inline-flex; align-items: center; gap: 6px; padding: 4px 7px; border: 1px solid #356071;
          border-radius: 3px; color: #9bdde9; font: 700 8px var(--gridlock-mono, monospace);
        }
        .ef-source-badge i { width: 6px; height: 6px; border-radius: 50%; background: #70cadb; }
        .ef-opportunity h3 {
          margin: 15px 0 0; color: #f5eefe; font: 600 21px/1.12 var(--gridlock-display, sans-serif);
          letter-spacing: -.045em;
        }
        .ef-project-line { margin: 6px 0 0; color: #9caec7; font-size: 10px; line-height: 1.45; }
        .ef-why { margin-top: 17px; }
        .ef-why p { margin: 6px 0 0; color: #d6ddeb; font-size: 12px; line-height: 1.55; }
        .ef-next {
          display: flex; gap: 10px; margin-top: 15px; padding: 11px 12px; border-left: 2px solid var(--ef-pink);
          background: #251923;
        }
        .ef-next-mark { color: #ff9ab4; font: 700 18px/1 var(--gridlock-display, sans-serif); }
        .ef-next .ef-label { color: #ffabc0; }
        .ef-next p { margin: 5px 0 0; color: #f1dbe3; font-size: 10px; line-height: 1.5; }
        .ef-card-footer { margin-top: auto; padding-top: 15px; }
        .ef-primary-action {
          display: flex; justify-content: space-between; align-items: center; width: 100%; min-height: 39px;
          padding: 0 12px; border: 1px solid #755062; border-radius: 5px; background: #392331;
          color: #ffd3de; font-size: 11px; font-weight: 700; text-align: left; transition: background .16s, transform .16s;
        }
        .ef-primary-action:hover { transform: translateY(-1px); background: #48293a; }
        .ef-primary-action.is-active { border-color: #7abac3; background: #1c3038; color: #c4f2f1; }
        .ef-primary-action span { font-size: 15px; }
        .ef-disclosure { color: #c3cddd; font-size: 10px; }
        .ef-disclosure summary {
          width: fit-content; margin-top: 10px; color: #a5c5d8; font-size: 10px; font-weight: 700;
          text-decoration: underline; text-decoration-color: #4b7183; text-underline-offset: 3px;
        }
        .ef-disclosure summary:hover { color: #d7f4fa; }
        .ef-disclosure summary:focus-visible, .ef-primary-action:focus-visible, .ef-copy:focus-visible,
        .ef-close:focus-visible, .ef-draft:focus-visible {
          outline: 2px solid var(--ef-cyan); outline-offset: 3px;
        }
        .ef-detail-content { margin-top: 10px; padding: 11px; border: 1px solid #304158; border-radius: 5px; background: #0d1420; }
        .ef-detail-total { display: flex; flex-wrap: wrap; align-items: baseline; gap: 7px 11px; padding-bottom: 9px; border-bottom: 1px solid #293950; }
        .ef-detail-total span, .ef-detail-total small { color: #9baec6; font-size: 9px; }
        .ef-detail-total strong { color: #f2eafa; font: 700 12px var(--gridlock-mono, monospace); }
        .ef-detail-block { margin-top: 10px; }
        .ef-detail-block h4 { margin: 0 0 5px; color: #c8d6e8; font-size: 10px; }
        .ef-detail-block p, .ef-caveat { margin: 5px 0 0; color: #9eacc1; font-size: 9px; line-height: 1.5; }
        .ef-factor-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px 14px; margin: 0; padding: 0; list-style: none; }
        .ef-factor-list li { color: #afbdd1; font: 9px/1.45 var(--gridlock-mono, monospace); }
        .ef-caveat { padding: 8px; border-left: 2px solid #d5819b; background: #211821; color: #d1b8c4; }
        .ef-brief-draft {
          margin-top: 15px; padding: 16px; border: 1px solid #3d6370; border-radius: 7px;
          background: linear-gradient(110deg, #14242c, #111a29 70%);
        }
        .ef-draft-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; }
        .ef-draft-head h3 { margin: 4px 0 0; color: #eef8fa; font: 600 17px var(--gridlock-display, sans-serif); }
        .ef-draft-head p { margin: 4px 0 0; color: var(--ef-muted); font-size: 10px; }
        .ef-close {
          flex: none; padding: 5px 8px; border: 1px solid #46566b; border-radius: 4px; background: transparent;
          color: #b9c8d9; font-size: 10px;
        }
        .ef-draft {
          display: block; width: 100%; min-height: 112px; margin-top: 12px; padding: 11px;
          resize: vertical; border: 1px solid #354a5b; border-radius: 5px; background: #0c151e;
          color: #dce8ef; font: 11px/1.55 var(--gridlock-body, sans-serif);
        }
        .ef-draft-actions { display: flex; align-items: center; gap: 12px; margin-top: 9px; }
        .ef-copy {
          padding: 7px 11px; border: 1px solid #58818c; border-radius: 4px; background: #1d3740;
          color: #c4eff0; font-size: 10px; font-weight: 700;
        }
        .ef-copy-status { color: #9fc4c9; font-size: 10px; }
        .ef-facility-section { margin-top: 40px; padding-top: 25px; border-top: 1px solid #354052; }
        .ef-facility-section .ef-section-heading { align-items: flex-end; }
        .ef-facility-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
        .ef-facility-card {
          min-width: 0; padding: 14px; border: 1px solid #2c3a50; border-radius: 7px;
          background: #111a29;
        }
        .ef-priority { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
        .ef-priority > span { color: #899bb4; font: 700 8px var(--gridlock-mono, monospace); letter-spacing: .055em; text-transform: uppercase; }
        .ef-priority strong { padding: 4px 7px; border: 1px solid #506b63; border-radius: 3px; background: #192c2b; color: #a8e3c9; font-size: 9px; }
        .ef-priority-high strong { border-color: #794758; background: #321e2a; color: #ffb0c2; }
        .ef-priority-monitor strong { border-color: #796143; background: #2b271d; color: #edcf93; }
        .ef-facility-card h3 { margin: 13px 0 3px; color: #eaf0f9; font: 600 15px/1.2 var(--gridlock-display, sans-serif); letter-spacing: -.025em; }
        .ef-facility-type { color: #91a4bf; font-size: 10px; }
        .ef-facility-card > p { min-height: 48px; margin: 10px 0 0; color: #b4c1d3; font-size: 10px; line-height: 1.5; }
        .ef-facility-disclosure { margin-top: 3px; padding-top: 9px; border-top: 1px solid #293950; }
        .ef-facility-disclosure summary { margin-top: 0; }
        .ef-scenario-note { margin: 0; color: #a5b3c6; font-size: 9px; line-height: 1.5; }
        .ef-facility-math { display: grid; gap: 6px; margin-top: 9px; }
        .ef-facility-math span { display: flex; justify-content: space-between; gap: 8px; color: #9eadc1; font-size: 9px; }
        .ef-facility-math b { color: #dbe6f4; font: 700 9px var(--gridlock-mono, monospace); }
        .ef-math-check { margin: 9px 0 0; padding-top: 7px; border-top: 1px solid #293950; color: #8fbed0; font: 9px var(--gridlock-mono, monospace); }
        .ef-context-footer {
          display: grid; grid-template-columns: auto 1fr; gap: 10px; align-items: start; margin-top: 15px;
          padding: 11px 13px; border: 1px solid #384458; border-radius: 6px; background: #101722;
        }
        .ef-context-footer strong { color: #cbd7e6; font-size: 10px; }
        .ef-context-footer p { margin: 0; color: #9caec4; font-size: 9px; line-height: 1.55; }
        @media (max-width: 760px) {
          .executive-first { padding: 0 18px 36px; }
          .ef-header { flex-direction: column; gap: 14px; padding-top: 20px; }
          .ef-context-tag { margin: 0; }
          .ef-briefing-strip { grid-template-columns: 1fr; gap: 13px; }
          .ef-strip-side { max-width: none; padding: 10px 0 0; border-top: 1px solid #35445b; border-left: 0; }
          .ef-opportunity-list { grid-template-columns: 1fr; }
          .ef-facility-grid { grid-template-columns: 1fr; }
          .ef-facility-card > p { min-height: auto; }
          .ef-section-heading { align-items: flex-start; flex-direction: column; }
        }
        @media (max-width: 420px) {
          .executive-first { padding-right: 14px; padding-left: 14px; }
          .ef-opportunity { padding: 14px; }
          .ef-factor-list { grid-template-columns: 1fr; }
          .ef-context-footer { grid-template-columns: 1fr; }
        }
      `}</style>

      <div className="ef-shell">
        <header className="ef-header">
          <div>
            <div className="ef-brand-line"><span className="ef-brand-mark">G</span> GridLock <span>·</span> Planner briefing</div>
            <h1>Where a conversation<br />could prevent a conflict.</h1>
            <p className="ef-header-copy">
              A focused review of nearby public utility plans. Compare the opportunity, understand the evidence,
              and leave with a practical next step.
            </p>
          </div>
          <div className="ef-context-tag"><i aria-hidden="true" /> Simulated storm scenario</div>
        </header>

        <section className="ef-briefing-strip" aria-label="Briefing scope">
          <div>
            <span className="ef-strip-label">Planning desk / Coastal Georgia</span>
            <h2>Utility coordination opportunities</h2>
            <p>Project conversations lead. Facility context is included below as a supporting scenario view.</p>
          </div>
          <div className="ef-strip-side">
            <b>Two pairings to review</b>
            <span>Point proximity is a screening signal—not a route, schedule, or shared-asset confirmation.</span>
          </div>
        </section>

        <section className="ef-section" aria-labelledby="ef-opportunities-title">
          <div className="ef-section-heading">
            <div>
              <span className="ef-section-kicker">01 / Coordination review</span>
              <h2 id="ef-opportunities-title">Start with the project pairs</h2>
            </div>
            <p className="ef-section-subtitle">
              Each opportunity states why to look and what to do next. Point totals and source caveats stay in the details.
            </p>
          </div>

          <div className="ef-source-legend" aria-label="Evidence types">
            <span className="ef-legend-item"><i className="ef-legend-dot" aria-hidden="true" /> Source-linked mapped project point</span>
            <span className="ef-legend-item"><i className="ef-legend-dot hollow" aria-hidden="true" /> Unverified workbook candidate</span>
            <p className="ef-legend-note">
              The mapped points below are source-linked. The pasted Okatie–Bluffton budget is an unverified workbook candidate,
              not a mapped project point or a verified filing value.
            </p>
          </div>

          <div className="ef-opportunity-list">
            {opportunities.map((opportunity) => (
              <OpportunityCard
                key={opportunity.id}
                opportunity={opportunity}
                onPrepare={prepareBrief}
                isActive={activeBrief?.id === opportunity.id}
              />
            ))}
          </div>

          {activeBrief && (
            <section className="ef-brief-draft" aria-labelledby="ef-draft-title">
              <div className="ef-draft-head">
                <div>
                  <span className="ef-section-kicker">Local working draft</span>
                  <h3 id="ef-draft-title">Prepare a discussion opener</h3>
                  <p>This text stays in the browser; it is not sent to either utility.</p>
                </div>
                <button className="ef-close" type="button" onClick={() => setActiveBrief(null)}>Close draft</button>
              </div>
              <textarea
                className="ef-draft"
                aria-label="Editable discussion brief"
                value={briefText}
                onChange={(event) => setBriefText(event.target.value)}
              />
              <div className="ef-draft-actions">
                <button className="ef-copy" type="button" onClick={copyBrief}>Copy draft</button>
                <span className="ef-copy-status" role="status" aria-live="polite">{copyStatus}</span>
              </div>
            </section>
          )}
        </section>

        <section className="ef-facility-section" aria-labelledby="ef-facility-title">
          <div className="ef-section-heading">
            <div>
              <span className="ef-section-kicker">02 / Supporting context · demo locations</span>
              <h2 id="ef-facility-title">Facilities in the scenario</h2>
            </div>
            <p className="ef-section-subtitle">
              Scenario context for planner discussion only. These facility locations do not indicate live risk or service dependence.
            </p>
          </div>
          <div className="ef-facility-grid">
            {facilities.map((facility) => <FacilityCard key={facility.name} facility={facility} />)}
          </div>
          <div className="ef-context-footer">
            <strong>Interpretation boundary</strong>
            <p>
              Facility locations are demo/scenario context. Storm conditions and path exposure are simulated, not a forecast.
              Nothing here establishes live risk, outage likelihood, service dependence, or dispatch priority.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}