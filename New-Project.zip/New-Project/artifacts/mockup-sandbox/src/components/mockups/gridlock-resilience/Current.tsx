import './_group.css';

type Pair = {
  title: string;
  score: string;
  rationale: string;
  factors: string[];
  basis: string;
  budget: string;
  missing: string;
};

const pairs: Pair[] = [
  {
    title: 'Dominion Energy South Carolina ↔ Georgia Power',
    score: '75 known points / 120 possible · 3/6 factors assessed',
    rationale: 'Why review: 3.02 mi apart (+30); dates 183 days apart (+20); $40.66M pasted Dominion estimate (+25).',
    factors: [
      'Distance: +30',
      'Shared infrastructure: not assessed',
      'Date gap: +20',
      'Project budget: +25',
      'Listed critical site: not assessed',
      'Coastal-area proxy: not assessed',
    ],
    basis: 'Source-linked named endpoints and exact planned in-service dates. This is point proximity, not confirmed route overlap; construction schedule and GPC budget remain unverified.',
    budget: 'Okatie-Bluffton 115kV: Rebuild: $40.66M; user-supplied pasted Dominion Energy South Carolina 5 Year Budget. Verify against the current filing.',
    missing: 'Not established: shared infrastructure connection, comprehensive hospital/airport/emergency/water/military coverage, FEMA flood zone, storm surge, hurricane frequency, and wind exposure. Coastal points are a broad scenario proxy, not measured hazard.',
  },
  {
    title: 'Dominion Energy South Carolina ↔ Georgia Power',
    score: '55 known points / 120 possible · 3/6 factors assessed',
    rationale: 'Why review: 8.41 mi apart (+20); dates 90 days apart (+20); a listed critical site is nearby (+15).',
    factors: [
      'Distance: +20',
      'Shared infrastructure: not assessed',
      'Date gap: +20',
      'Project budget: not assessed',
      'Listed critical site: +15',
      'Coastal-area proxy: not assessed',
    ],
    basis: 'Source-linked point proximity only—not either project’s full route or a confirmed construction overlap.',
    budget: 'No supported budget is available for these projects.',
    missing: 'Scenario output only—not a weather forecast or dispatch plan.',
  },
];

function ScoreDetails({ pair }: { pair: Pair }) {
  return (
    <details className="resilience-details">
      <summary>See points and evidence</summary>
      <ul className="resilience-factors">
        {pair.factors.map((factor) => <li key={factor}>{factor}</li>)}
      </ul>
      <p className="resilience-basis">{pair.basis}</p>
      <p className="resilience-basis">{pair.budget}</p>
      <p className="resilience-missing">{pair.missing}</p>
    </details>
  );
}

function ResilienceCard({ pair }: { pair: Pair }) {
  return (
    <article className="resilience-card">
      <h3>{pair.title}</h3>
      <div className="resilience-score">{pair.score}</div>
      <p>{pair.rationale}</p>
      <ScoreDetails pair={pair} />
      <button className="resilience-focus" type="button">Find endpoints on map</button>
    </article>
  );
}

function FacilityRow({
  rank, name, type, tier, score, proximity,
}: {
  rank: number; name: string; type: string; tier: string; score: string; proximity: string;
}) {
  const tone = tier === 'High' ? 'high' : tier === 'Review' ? 'review' : '';
  return (
    <li>
      <button className={`facility-row ${tone}`} type="button">
        <span className="facility-rank">#{rank}</span>
        <span className="facility-label">
          <b>{name}</b>
          <span>{type} · {tier} · {proximity}</span>
        </span>
        <span className="facility-score">{score}/100</span>
      </button>
    </li>
  );
}

export function Current() {
  return (
    <main className="gridlock-resilience-preview">
      <header className="preview-header">
        <div className="preview-kicker">GridLock · Resilience Operations View</div>
        <h1>Storm readiness</h1>
        <p>See which demo projects and facilities are near a simulated corridor.</p>
      </header>

      <section className="resilience-preview-panel" aria-labelledby="resilience-heading">
        <div className="preview-section-kicker">Storm scenario · simulated</div>
        <h2 id="resilience-heading">Readiness indicators</h2>
        <p className="resilience-intro">Scenario context for discussion with utility planners. Not a dispatch recommendation.</p>
        <div className="impact-counter-grid">
          <div className="impact-counter"><span>Demo projects within 20 km</span><strong>2</strong><small>Simulated path only</small></div>
          <div className="impact-counter"><span>Demo facilities within 20 km</span><strong>4</strong><small>Simulated path only</small></div>
          <div className="impact-counter"><span>Shared response assets</span><strong>—</strong><small>Not assessed</small></div>
          <div className="impact-counter"><span>Restoration impact</span><strong>—</strong><small>Not estimated</small></div>
        </div>
        <p className="storm-recommendation"><strong>Discussion:</strong> Review staging options with utility planners. This simulation does not establish outage likelihood or response priority.</p>
        <div className="risk-key">
          <span className="risk-key-title">Distance from simulated path</span>
          <div className="risk-key-items">
            <span className="risk-key-item"><i className="risk-dot risk-red" />≤5 km <b>1</b></span>
            <span className="risk-key-item"><i className="risk-dot risk-orange" />&gt;5–10 km <b>1</b></span>
            <span className="risk-key-item"><i className="risk-dot risk-yellow" />&gt;10–20 km <b>2</b></span>
            <span className="risk-key-item"><i className="risk-dot risk-green" />&gt;20 km <b>8</b></span>
          </div>
          <p className="risk-note">Distance only—not hazard, outage likelihood, or dispatch priority.</p>
        </div>
        <div className="resilience-list">
          {pairs.map((pair) => <ResilienceCard key={pair.score} pair={pair} />)}
        </div>
      </section>

      <section className="facility-preview-panel" aria-labelledby="facility-heading">
        <div className="preview-section-kicker">Facility priority · demo</div>
        <h2 id="facility-heading">Priority sites</h2>
        <p className="facility-intro">Scenario-ranked facilities are supporting context for the project review above.</p>
        <p className="facility-status">3 listed priority sites · storm scenario active</p>
        <ol className="facility-list">
          <FacilityRow rank={1} name="Savannah General Hospital" type="Hospital" tier="High" score="92" proximity="4.2 km from simulated path" />
          <FacilityRow rank={2} name="Chatham County Fire Station 7" type="Fire Station" tier="Review" score="68" proximity="8.7 km from simulated path" />
          <FacilityRow rank={3} name="Coastal Pines Nursing Home" type="Nursing Home" tier="Monitor" score="44" proximity="23.1 km from simulated path" />
        </ol>
        <details className="facility-guide">
          <summary>How is priority calculated?</summary>
          <p>Score /100 = facility category + distance from simulated storm corridor + distance to nearest demo project center. High ≥70 only during the scenario; Review ≥50. Demo ranking only—not an outage forecast, live risk assessment, or crew dispatch order.</p>
        </details>
      </section>
    </main>
  );
}