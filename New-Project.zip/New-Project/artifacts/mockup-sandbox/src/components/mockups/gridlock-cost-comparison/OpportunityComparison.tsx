import { useState } from "react";
import "./_group.css";

const scenarios = [
  {
    index: "01",
    name: "Conservative Scenario",
    scope: "Shared permitting",
    note: "One permitting workstream, if jurisdictions and schedules align.",
    shared: ["Permitting"],
  },
  {
    index: "02",
    name: "Expected Scenario",
    scope: "Permitting + staging",
    note: "Adds coordinated site staging to a shared permitting plan.",
    shared: ["Permitting", "Staging"],
  },
  {
    index: "03",
    name: "Maximum Collaboration",
    scope: "Permitting + equipment + contractors + staging",
    note: "Broadest planning case; every shared resource remains unconfirmed.",
    shared: ["Permitting", "Equipment", "Contractors", "Staging"],
  },
];

const savingsSources = [
  ["Shared Permitting", "Potential coordination source"],
  ["Shared Staging", "Potential coordination source"],
  ["Shared Equipment", "Potential coordination source"],
  ["Shared Contractors", "Potential coordination source"],
];

export function OpportunityComparison() {
  const [analysisGenerated, setAnalysisGenerated] = useState(false);

  return (
    <main className="gridlock-cost-page opportunity-page">
      <style>{`
        .opportunity-page {
          --opp-ink: var(--view-ink, #11172f);
          --opp-muted: var(--view-muted, #58627b);
          --opp-line: var(--view-line, #d9deef);
          --opp-blue: var(--view-teal, #3155ff);
          --opp-blue-dark: var(--view-teal-dark, #1a2f9c);
          --opp-wash: #f5f7ff;
          --opp-coral: var(--view-coral, #7c3aed);
          min-height: 100vh;
          padding: 22px 34px 48px;
          background: #fff;
          color: var(--opp-ink);
          font-family: var(--body, "DM Sans", sans-serif);
        }
        .opportunity-page * { box-sizing: border-box; }
        .opportunity-page .opp-brand {
          display: flex;
          align-items: baseline;
          gap: 18px;
          padding-bottom: 18px;
          border-bottom: 1px solid var(--opp-line);
          font: 700 19px/1 var(--display, "Space Grotesk", sans-serif);
          letter-spacing: -.05em;
        }
        .opportunity-page .opp-brand small {
          color: var(--opp-muted);
          font: 700 9px/1.2 var(--mono, "Space Mono", monospace);
          letter-spacing: .09em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-content { max-width: 1240px; margin: 0 auto; }
        .opportunity-page .opp-heading {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 20px;
          margin: 30px 0 20px;
        }
        .opportunity-page .opp-kicker,
        .opportunity-page .opp-eyebrow {
          margin: 0;
          color: var(--opp-blue);
          font: 700 9px/1.4 var(--mono, "Space Mono", monospace);
          letter-spacing: .1em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-heading h1 {
          margin: 7px 0 8px;
          font: 700 clamp(25px, 3vw, 35px)/1.04 var(--display, "Space Grotesk", sans-serif);
          letter-spacing: -.055em;
        }
        .opportunity-page .opp-subtitle {
          max-width: 690px;
          margin: 0;
          color: var(--opp-muted);
          font-size: 13px;
          line-height: 1.6;
        }
        .opportunity-page .opp-status {
          flex: none;
          margin-top: 4px;
          padding: 7px 10px;
          border: 1px solid #bbc6ff;
          border-radius: 4px;
          color: var(--opp-blue-dark);
          background: #f8f9ff;
          font: 700 9px/1 var(--mono, "Space Mono", monospace);
          letter-spacing: .06em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-section {
          margin-top: 18px;
          border: 1px solid var(--opp-line);
          border-radius: 8px;
          background: #fff;
        }
        .opportunity-page .opp-section-head {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 18px;
          padding: 17px 19px 13px;
        }
        .opportunity-page .opp-section-head h2 {
          margin: 4px 0 0;
          font: 700 17px/1.2 var(--display, "Space Grotesk", sans-serif);
          letter-spacing: -.035em;
        }
        .opportunity-page .opp-section-head > p {
          max-width: 430px;
          margin: 2px 0 0;
          color: var(--opp-muted);
          font-size: 11px;
          line-height: 1.5;
          text-align: right;
        }
        .opportunity-page .opp-pair-grid {
          display: grid;
          grid-template-columns: minmax(0, 1fr) 104px minmax(0, 1fr);
          align-items: stretch;
          gap: 10px;
          padding: 0 19px 17px;
        }
        .opportunity-page .opp-project {
          min-width: 0;
          padding: 14px;
          border: 1px solid var(--opp-line);
          border-radius: 6px;
          background: #fbfcff;
        }
        .opportunity-page .opp-utility {
          color: var(--opp-muted);
          font: 700 9px/1.3 var(--mono, "Space Mono", monospace);
          letter-spacing: .05em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-project h3 {
          margin: 7px 0 12px;
          font: 700 15px/1.3 var(--display, "Space Grotesk", sans-serif);
          letter-spacing: -.025em;
        }
        .opportunity-page .opp-project dl {
          display: grid;
          grid-template-columns: max-content minmax(0, 1fr);
          gap: 5px 10px;
          margin: 0;
          font-size: 10px;
          line-height: 1.4;
        }
        .opportunity-page .opp-project dt { color: var(--opp-muted); }
        .opportunity-page .opp-project dd { margin: 0; font-weight: 700; }
        .opportunity-page .opp-link {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          gap: 8px;
          color: var(--opp-blue-dark);
          text-align: center;
        }
        .opportunity-page .opp-link-mark {
          display: grid;
          width: 34px;
          height: 34px;
          place-items: center;
          border: 1px solid #bcc7ff;
          border-radius: 50%;
          background: var(--opp-wash);
          font: 700 16px/1 var(--body, sans-serif);
        }
        .opportunity-page .opp-link small {
          max-width: 90px;
          font: 700 8px/1.45 var(--mono, monospace);
          letter-spacing: .015em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-caveat {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          margin: 0 19px 17px;
          padding: 10px 12px;
          border-left: 2px solid #929de0;
          background: #f6f7fd;
          color: #4d5873;
          font-size: 10px;
          line-height: 1.5;
        }
        .opportunity-page .opp-caveat strong { color: var(--opp-ink); }
        .opportunity-page .opp-budget {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 205px;
          border-top: 1px solid var(--opp-line);
        }
        .opportunity-page .opp-budget-item {
          min-width: 0;
          padding: 16px 19px;
        }
        .opportunity-page .opp-budget-item + .opp-budget-item { border-left: 1px solid var(--opp-line); }
        .opportunity-page .opp-budget-title {
          margin: 0 0 8px;
          color: var(--opp-muted);
          font: 700 9px/1.4 var(--mono, monospace);
          letter-spacing: .055em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-budget-value {
          display: block;
          margin-bottom: 7px;
          font: 700 clamp(20px, 2.3vw, 27px)/1 var(--display, sans-serif);
          letter-spacing: -.05em;
        }
        .opportunity-page .opp-budget-item p:last-child {
          margin: 0;
          color: var(--opp-muted);
          font-size: 10px;
          line-height: 1.45;
        }
        .opportunity-page .opp-budget-item .opp-unverified {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          margin-bottom: 8px;
          color: #8c5621;
          font: 700 8px/1.3 var(--mono, monospace);
          letter-spacing: .04em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-unknown {
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 16px;
          background: #f7f8fc;
        }
        .opportunity-page .opp-unknown strong {
          display: block;
          margin: 4px 0;
          font: 700 15px/1.1 var(--display, sans-serif);
        }
        .opportunity-page .opp-unknown span:last-child {
          color: var(--opp-muted);
          font-size: 9px;
          line-height: 1.4;
        }
        .opportunity-page .opp-source-details {
          border-top: 1px solid var(--opp-line);
          padding: 0 19px;
        }
        .opportunity-page .opp-source-details summary {
          width: fit-content;
          padding: 10px 0;
          color: var(--opp-blue-dark);
          cursor: pointer;
          font-size: 10px;
          font-weight: 700;
        }
        .opportunity-page .opp-source-details summary:focus-visible,
        .opportunity-page button:focus-visible {
          outline: 3px solid #aeb9ff;
          outline-offset: 3px;
        }
        .opportunity-page .opp-source-details p {
          max-width: 900px;
          margin: 0 0 13px;
          color: var(--opp-muted);
          font-size: 10px;
          line-height: 1.55;
        }
        .opportunity-page .opp-construction {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
          padding: 0 19px 17px;
        }
        .opportunity-page .opp-path {
          padding: 12px 14px;
          border: 1px solid var(--opp-line);
          border-radius: 5px;
          background: #fbfcff;
        }
        .opportunity-page .opp-path.is-coordinated {
          border-color: #b9c3ff;
          background: #f7f8ff;
        }
        .opportunity-page .opp-path span {
          display: block;
          margin-bottom: 5px;
          color: var(--opp-muted);
          font: 700 8px/1.4 var(--mono, monospace);
          letter-spacing: .07em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-path strong {
          font: 700 13px/1.25 var(--display, sans-serif);
        }
        .opportunity-page .opp-path p {
          margin: 5px 0 0;
          color: var(--opp-muted);
          font-size: 9px;
          line-height: 1.45;
        }
        .opportunity-page .opp-scenarios {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 9px;
          padding: 0 19px 18px;
        }
        .opportunity-page .opp-scenario {
          min-width: 0;
          padding: 13px;
          border: 1px solid var(--opp-line);
          border-radius: 6px;
          background: #fff;
        }
        .opportunity-page .opp-scenario-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 8px;
        }
        .opportunity-page .opp-index {
          color: #8993ad;
          font: 700 9px var(--mono, monospace);
        }
        .opportunity-page .opp-scenario h3 {
          min-height: 38px;
          margin: 6px 0 4px;
          font: 700 14px/1.2 var(--display, sans-serif);
          letter-spacing: -.025em;
        }
        .opportunity-page .opp-scope {
          min-height: 28px;
          margin: 0;
          color: var(--opp-blue-dark);
          font-size: 10px;
          font-weight: 700;
          line-height: 1.4;
        }
        .opportunity-page .opp-unestimated {
          position: relative;
          display: flex;
          min-height: 45px;
          justify-content: space-between;
          align-items: center;
          overflow: hidden;
          gap: 8px;
          margin: 12px 0 9px;
          padding: 8px 10px;
          border: 1px dashed #b8bfd6;
          border-radius: 4px;
          background: repeating-linear-gradient(135deg, #f7f8fc 0 7px, #eff1f8 7px 8px);
        }
        .opportunity-page .opp-unestimated strong {
          position: relative;
          z-index: 1;
          padding: 3px 5px;
          border-radius: 2px;
          background: #fff;
          color: #4f5973;
          font: 700 9px/1.25 var(--mono, monospace);
          text-transform: uppercase;
        }
        .opportunity-page .opp-unestimated span {
          position: relative;
          z-index: 1;
          color: #747e98;
          font: 700 8px var(--mono, monospace);
          text-transform: uppercase;
        }
        .opportunity-page .opp-scenario-note {
          min-height: 42px;
          margin: 0;
          color: var(--opp-muted);
          font-size: 9px;
          line-height: 1.5;
        }
        .opportunity-page .opp-shared {
          display: flex;
          flex-wrap: wrap;
          gap: 4px;
          margin-top: 10px;
        }
        .opportunity-page .opp-shared span {
          padding: 4px 5px;
          border: 1px solid #e1e5f1;
          border-radius: 3px;
          color: #59637b;
          font: 700 7px/1.2 var(--mono, monospace);
          text-transform: uppercase;
        }
        .opportunity-page .opp-savings {
          display: grid;
          grid-template-columns: minmax(200px, .75fr) minmax(0, 1.7fr);
          border-top: 1px solid var(--opp-line);
        }
        .opportunity-page .opp-savings-intro {
          padding: 17px 19px;
          border-right: 1px solid var(--opp-line);
        }
        .opportunity-page .opp-savings-intro h3 {
          margin: 5px 0 6px;
          font: 700 16px/1.2 var(--display, sans-serif);
          letter-spacing: -.035em;
        }
        .opportunity-page .opp-savings-intro p {
          margin: 0;
          color: var(--opp-muted);
          font-size: 10px;
          line-height: 1.5;
        }
        .opportunity-page .opp-savings-coverage {
          margin-top: 14px;
          padding-top: 11px;
          border-top: 1px solid var(--opp-line);
        }
        .opportunity-page .opp-savings-coverage-head {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          gap: 8px;
          margin-bottom: 6px;
          color: var(--opp-muted);
          font: 700 8px/1.35 var(--mono, monospace);
          letter-spacing: .035em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-savings-coverage-head strong {
          color: var(--opp-blue-dark);
          font-size: 9px;
          white-space: nowrap;
        }
        .opportunity-page .opp-coverage-track {
          height: 8px;
          overflow: hidden;
          border: 1px solid #cbd1e2;
          border-radius: 99px;
          background: #f4f5f9;
        }
        .opportunity-page .opp-coverage-track > span {
          display: block;
          width: 0;
          height: 100%;
          background: var(--opp-blue);
        }
        .opportunity-page .opp-savings-coverage small {
          display: block;
          margin-top: 6px;
          color: var(--opp-muted);
          font-size: 9px;
          line-height: 1.4;
        }
        .opportunity-page .opp-source-list { padding: 10px 17px; }
        .opportunity-page .opp-source-row {
          display: grid;
          grid-template-columns: minmax(110px, .8fr) minmax(80px, 1.3fr) max-content;
          align-items: center;
          gap: 10px;
          min-height: 35px;
          border-bottom: 1px solid #edf0f7;
        }
        .opportunity-page .opp-source-row:last-child { border: 0; }
        .opportunity-page .opp-source-row strong { font-size: 10px; }
        .opportunity-page .opp-source-track {
          height: 8px;
          border: 1px dashed #c5cadd;
          border-radius: 99px;
          background: repeating-linear-gradient(135deg, #f7f8fc 0 6px, #e9ecf5 6px 7px);
        }
        .opportunity-page .opp-source-row b {
          white-space: nowrap;
          color: #4f5973;
          font: 700 9px/1.3 var(--mono, monospace);
        }
        .opportunity-page .opp-withheld {
          display: grid;
          grid-template-columns: 145px minmax(0, 1fr);
          gap: 14px;
          align-items: start;
          margin: 18px 0 0;
          padding: 14px 16px;
          border: 1px solid #d9deef;
          border-left: 3px solid var(--opp-coral);
          border-radius: 6px;
          background: #fbfaff;
        }
        .opportunity-page .opp-withheld-label {
          color: var(--opp-coral);
          font: 700 9px/1.45 var(--mono, monospace);
          letter-spacing: .04em;
          text-transform: uppercase;
        }
        .opportunity-page .opp-withheld p {
          margin: 0;
          color: #505a73;
          font-size: 10px;
          line-height: 1.55;
        }
        .opportunity-page .opp-analysis {
          display: grid;
          grid-template-columns: minmax(200px, .72fr) minmax(0, 1.7fr);
          gap: 18px;
          align-items: center;
          margin-top: 18px;
          padding: 17px 19px;
          border-radius: 7px;
          background: #f3f5ff;
        }
        .opportunity-page .opp-analysis h2 {
          margin: 5px 0 6px;
          font: 700 16px/1.2 var(--display, sans-serif);
          letter-spacing: -.03em;
        }
        .opportunity-page .opp-analysis-copy {
          margin: 0;
          color: var(--opp-muted);
          font-size: 10px;
          line-height: 1.5;
        }
        .opportunity-page .opp-analysis-action { min-width: 0; }
        .opportunity-page .opp-generate {
          display: inline-flex;
          min-height: 38px;
          align-items: center;
          gap: 10px;
          padding: 0 13px;
          border: 1px solid var(--opp-blue-dark);
          border-radius: 4px;
          background: var(--opp-blue);
          color: #fff;
          cursor: pointer;
          font: 700 10px var(--body, sans-serif);
          transition: transform 150ms ease, opacity 150ms ease;
        }
        .opportunity-page .opp-generate:hover { transform: translateY(-1px); }
        .opportunity-page .opp-generate:active { transform: translateY(0); }
        .opportunity-page .opp-result {
          margin: 9px 0 0;
          padding: 10px 12px;
          border: 1px solid #d5daf0;
          border-radius: 4px;
          background: #fff;
          color: #48536d;
          font-size: 10px;
          line-height: 1.55;
        }
        .opportunity-page .opp-result strong { color: var(--opp-ink); }
        .opportunity-page .opp-footer {
          display: flex;
          justify-content: space-between;
          gap: 15px;
          margin-top: 15px;
          color: #7a849c;
          font: 700 8px/1.5 var(--mono, monospace);
          letter-spacing: .045em;
          text-transform: uppercase;
        }
        @media (max-width: 760px) {
          .opportunity-page { padding: 18px 14px 30px; }
          .opportunity-page .opp-heading { margin-top: 23px; }
          .opportunity-page .opp-heading h1 { font-size: 27px; }
          .opportunity-page .opp-heading { flex-direction: column; gap: 11px; }
          .opportunity-page .opp-section-head { flex-direction: column; gap: 6px; }
          .opportunity-page .opp-section-head > p { text-align: left; }
          .opportunity-page .opp-pair-grid { grid-template-columns: 1fr; padding: 0 13px 13px; }
          .opportunity-page .opp-link { flex-direction: row; }
          .opportunity-page .opp-link small { max-width: none; }
          .opportunity-page .opp-link-mark { width: 28px; height: 28px; transform: rotate(90deg); }
          .opportunity-page .opp-budget { grid-template-columns: 1fr 1fr; }
          .opportunity-page .opp-budget-item { padding: 14px; }
          .opportunity-page .opp-budget-item + .opp-budget-item { border-left: 0; }
          .opportunity-page .opp-budget-item:nth-child(2) { border-left: 1px solid var(--opp-line); }
          .opportunity-page .opp-unknown { grid-column: 1 / -1; border-top: 1px solid var(--opp-line); }
          .opportunity-page .opp-source-details { padding: 0 14px; }
          .opportunity-page .opp-section-head { padding: 15px 14px 12px; }
          .opportunity-page .opp-construction { grid-template-columns: 1fr; padding: 0 14px 14px; }
          .opportunity-page .opp-scenarios { grid-template-columns: 1fr; padding: 0 14px 14px; }
          .opportunity-page .opp-scenario h3,
          .opportunity-page .opp-scope,
          .opportunity-page .opp-scenario-note { min-height: 0; }
          .opportunity-page .opp-savings { grid-template-columns: 1fr; }
          .opportunity-page .opp-savings-intro { border-right: 0; border-bottom: 1px solid var(--opp-line); }
          .opportunity-page .opp-savings-coverage { max-width: 360px; }
          .opportunity-page .opp-withheld { grid-template-columns: 1fr; gap: 6px; }
          .opportunity-page .opp-analysis { grid-template-columns: 1fr; gap: 12px; }
          .opportunity-page .opp-footer { flex-direction: column; gap: 3px; }
        }
        @media (max-width: 420px) {
          .opportunity-page .opp-brand { gap: 10px; }
          .opportunity-page .opp-brand small { font-size: 7px; }
          .opportunity-page .opp-budget { grid-template-columns: 1fr; }
          .opportunity-page .opp-budget-item:nth-child(2) { border-left: 0; border-top: 1px solid var(--opp-line); }
          .opportunity-page .opp-budget-item:first-child { border-bottom: 0; }
          .opportunity-page .opp-unknown { grid-column: auto; }
          .opportunity-page .opp-source-row { grid-template-columns: minmax(0, 1fr) max-content; gap: 5px 8px; padding: 7px 0; }
          .opportunity-page .opp-source-track { grid-column: 1 / -1; grid-row: 2; }
          .opportunity-page .opp-source-row b { grid-column: 2; grid-row: 1; }
        }
        @media (prefers-reduced-motion: reduce) {
          .opportunity-page .opp-generate { transition: none; }
        }
      `}</style>

      <div className="opp-brand">
        GRIDLOCK
        <small>Executive reports &amp; budget</small>
      </div>

      <div className="opp-content">
        <header className="opp-heading">
          <div>
            <p className="opp-kicker">Coordination review / Opportunity 01</p>
            <h1>Cost comparison</h1>
            <p className="opp-subtitle">
              A source-led view of two nearby infrastructure projects. Budget impact stays
              unestimated until both project baselines and potential shared scope are supported.
            </p>
          </div>
          <span className="opp-status">Evidence led</span>
        </header>

        <section className="opp-section" aria-labelledby="opp-pair-title">
          <div className="opp-section-head">
            <div>
              <p className="opp-eyebrow">Selected opportunity</p>
              <h2 id="opp-pair-title">Projects in review</h2>
            </div>
            <p>The pair is carried forward from the coordination view. No manual budget or savings inputs.</p>
          </div>
          <div className="opp-pair-grid">
            <article className="opp-project">
              <span className="opp-utility">Dominion Energy South Carolina</span>
              <h3>Jasper–Okatie 230 kV #2: Construct</h3>
              <dl>
                <dt>Review role</dt><dd>Selected project</dd>
                <dt>Budget evidence</dt><dd>User-supplied filing snapshot</dd>
              </dl>
            </article>
            <div className="opp-link" aria-label="Paired by public point proximity">
              <span className="opp-link-mark" aria-hidden="true">↔</span>
              <small>Public point proximity</small>
            </div>
            <article className="opp-project">
              <span className="opp-utility">Georgia Power</span>
              <h3>SAV: McIntosh–Purrysburg 230 kV Reactors</h3>
              <dl>
                <dt>Review role</dt><dd>Nearby comparison</dd>
                <dt>Budget evidence</dt><dd>Not available</dd>
              </dl>
            </article>
          </div>
          <p className="opp-caveat">
            <strong>Proximity caveat</strong>
            <span>This pairing is based on public point proximity, not confirmed route overlap. It is a coordination lead, not evidence of shared construction scope.</span>
          </p>

          <div className="opp-budget" aria-label="Available project budget evidence">
            <div className="opp-budget-item">
              <p className="opp-budget-title">Dominion · five-year budget snapshot</p>
              <span className="opp-unverified">Snapshot · verify current filing</span>
              <strong className="opp-budget-value">$23,787,423</strong>
              <p>Jasper–Okatie 230 kV #2 · Total Estimated Project Cost in the user-supplied snapshot.</p>
            </div>
            <div className="opp-budget-item">
              <p className="opp-budget-title">Georgia Power · comparison budget</p>
              <strong className="opp-budget-value">Not available</strong>
              <p>No comparable project budget is available for this review.</p>
            </div>
            <div className="opp-unknown">
              <span className="opp-eyebrow">Evidence status</span>
              <strong>Baseline incomplete</strong>
              <span>One unverified snapshot; one missing budget. Unknown is not zero.</span>
            </div>
          </div>
          <details className="opp-source-details">
            <summary>View budget source and limitation</summary>
            <p>
              Source: user-supplied pasted Dominion Energy South Carolina 5 Year Budget, project 23 of 44,
              “Total Estimated Project Cost,” Jasper–Okatie 230 kV #2. The source itself says to verify
              against the current filing. This snapshot is not a confirmed current budget. No comparable
              Georgia Power project budget is available. The $40.66M amount shown elsewhere belongs to a
              different Dominion project and is not used here.
            </p>
          </details>
        </section>

        <section className="opp-section" aria-labelledby="opp-scenarios-title">
          <div className="opp-section-head">
            <div>
              <p className="opp-eyebrow">Planning cases · not forecasts</p>
              <h2 id="opp-scenarios-title">Independent vs coordinated construction</h2>
            </div>
            <p>Scenarios describe possible coordination scope only. No scenario implies a confirmed saving.</p>
          </div>
          <div className="opp-construction">
            <div className="opp-path">
              <span>Baseline pathway</span>
              <strong>Independent construction</strong>
              <p>Projects proceed separately. Combined cost cannot be calculated from the available evidence.</p>
            </div>
            <div className="opp-path is-coordinated">
              <span>Opportunity pathway</span>
              <strong>Coordinated construction</strong>
              <p>Potential shared work is explored below; route overlap, scope and cost remain unconfirmed.</p>
            </div>
          </div>
          <div className="opp-scenarios">
            {scenarios.map((scenario) => (
              <article className="opp-scenario" key={scenario.index}>
                <div className="opp-scenario-top">
                  <span className="opp-index">CASE {scenario.index}</span>
                  <span className="opp-index">PLANNING ONLY</span>
                </div>
                <h3>{scenario.name}</h3>
                <p className="opp-scope">{scenario.scope}</p>
                <div className="opp-unestimated" aria-label="Savings not estimated; this is not a zero-value estimate">
                  <strong>Not estimated</strong>
                  <span>Scope open</span>
                </div>
                <p className="opp-scenario-note">{scenario.note}</p>
                <div className="opp-shared" aria-label="Potential shared scope">
                  {scenario.shared.map((item) => <span key={item}>Shared {item}</span>)}
                </div>
              </article>
            ))}
          </div>
          <div className="opp-savings">
            <div className="opp-savings-intro">
              <p className="opp-eyebrow">Potential savings sources</p>
              <h3>Unpriced, not zero</h3>
              <p>Each is a hypothesis for review—not a claimed saving or a committed shared resource.</p>
              <div className="opp-savings-coverage">
                <div className="opp-savings-coverage-head">
                  <span>Verified estimate coverage</span>
                  <strong>0 of 4 sources</strong>
                </div>
                <div
                  className="opp-coverage-track"
                  role="progressbar"
                  aria-label="Verified estimate coverage for potential savings sources"
                  aria-valuemin={0}
                  aria-valuemax={4}
                  aria-valuenow={0}
                  aria-valuetext="Zero of four sources have verified cost estimates. This is unestimated, not zero savings."
                >
                  <span />
                </div>
                <small>Zero of four categories have verified cost estimates; unestimated does not mean zero savings.</small>
              </div>
            </div>
            <div className="opp-source-list" role="list" aria-label="Potential savings categories">
              {savingsSources.map(([name, description]) => (
                <div className="opp-source-row" role="listitem" key={name}>
                  <strong>{name}</strong>
                  <div className="opp-source-track" role="img" aria-label={`${description}; ${name} savings amount unestimated, not zero`} />
                  <b>Not estimated</b>
                </div>
              ))}
            </div>
          </div>
        </section>

        <aside className="opp-withheld" aria-label="Why combined cost and savings are withheld">
          <span className="opp-withheld-label">Why totals are withheld</span>
          <p>
            A combined cost needs comparable project baselines, while a savings estimate also needs verified
            overlap and a defined shared scope. The Georgia Power baseline is missing, the Dominion snapshot
            needs current-filing verification, and no shared work is confirmed—so a total or savings figure
            would imply evidence we do not have.
          </p>
        </aside>

        <section className="opp-analysis" aria-labelledby="opp-analysis-title">
          <div>
            <p className="opp-eyebrow">Locally generated · no external analysis</p>
            <h2 id="opp-analysis-title">Prepare a savings analysis</h2>
            <p className="opp-analysis-copy">Generate a plain-English evidence summary for this selected pair.</p>
          </div>
          <div className="opp-analysis-action">
            <button
              className="opp-generate"
              type="button"
              onClick={() => setAnalysisGenerated(true)}
              aria-controls="opp-analysis-result"
            >
              Generate Savings Analysis <span aria-hidden="true">→</span>
            </button>
            {analysisGenerated ? (
              <p className="opp-result" id="opp-analysis-result" aria-live="polite" role="status">
                <strong>Generated locally: </strong>
                The available Dominion budget is a snapshot that needs verification against the current filing.
                A comparable Georgia Power project budget is missing, and shared route overlap and work scope
                are unconfirmed. GridLock cannot responsibly quantify combined cost or savings yet. Confirm
                both baselines and the potential shared scope before estimating.
              </p>
            ) : (
              <p className="opp-result" id="opp-analysis-result" aria-live="polite" role="status">
                Select “Generate Savings Analysis” to preview a local plain-English summary. No external AI call is made in this design preview.
              </p>
            )}
          </div>
        </section>

        <footer className="opp-footer">
          <span>GridLock · Executive review</span>
          <span>Every claim carries its source and limitation</span>
        </footer>
      </div>
    </main>
  );
}