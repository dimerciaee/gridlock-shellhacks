import "./_group.css";

export function Current() {
  return (
    <main className="gridlock-cost-page">
      <div className="gridlock-cost-brand">
        GRIDLOCK
        <small>Executive Reports &amp; Budget</small>
      </div>

      <section className="workspace-view-reports" aria-labelledby="reportsViewTitle">
        <div className="workspace-view-heading">
          <div>
            <p className="workspace-view-number">View 03 / Evidence desk</p>
            <h2 id="reportsViewTitle">Executive Reports &amp; Budget</h2>
          </div>
          <span className="workspace-view-status">EVIDENCE LED</span>
        </div>

        <p className="workspace-view-copy">
          Prepare an executive briefing or inspect the supporting records. Budget impact is{" "}
          <strong>Not estimated</strong> unless supplied by an authorized source.
        </p>

        <div className="report-scope-grid" aria-label="Report scope">
          <div>
            <span>Executive export</span>
            <strong>Ranked discussion agenda</strong>
            <small>Illustrative planning context only</small>
          </div>
          <div>
            <span>Technical export</span>
            <strong>Evidence and limitations</strong>
            <small>Source status stays visible</small>
          </div>
          <div>
            <span>Budget measure</span>
            <strong>Not estimated</strong>
            <small>No cost or savings claim</small>
          </div>
        </div>

        <div className="report-ai-actions">
          <button className="ai-btn" type="button">Generate Executive Summary</button>
          <div className="portfolio-ai-result">Executive summary appears here.</div>
        </div>

        <section className="cost-comparison" aria-labelledby="costComparisonTitle">
          <h3 id="costComparisonTitle">Cost comparison scenarios</h3>
          <p>Enter two budgets and reduction assumptions. Scenarios are illustrative, not verified savings.</p>

          <div className="cost-input-grid">
            <label>
              Project A budget (USD)
              <input type="number" min="0" step="1000" aria-label="Project A budget in USD" />
            </label>
            <label>
              Project B budget (USD)
              <input type="number" min="0" step="1000" aria-label="Project B budget in USD" />
            </label>
            <label>
              Low reduction assumption (%)
              <input type="number" min="0" max="100" step="0.1" aria-label="Low reduction assumption" />
            </label>
            <label>
              Mid reduction assumption (%)
              <input type="number" min="0" max="100" step="0.1" aria-label="Mid reduction assumption" />
            </label>
            <label>
              High reduction assumption (%)
              <input type="number" min="0" max="100" step="0.1" aria-label="High reduction assumption" />
            </label>
          </div>

          <div className="cost-scenario-grid">
            <div><span>Do separately</span><strong>—</strong><small>Combined budget</small></div>
            <div><span>Low coordination case</span><strong>—</strong><small>Difference: —</small></div>
            <div><span>Mid coordination case</span><strong>—</strong><small>Difference: —</small></div>
            <div><span>High coordination case</span><strong>—</strong><small>Difference: —</small></div>
          </div>

          <p className="cost-assumption-status">Enter both budgets and all three assumptions to calculate.</p>
          <button className="ai-btn" type="button">Generate Cost Saving Analysis</button>
          <div className="portfolio-ai-result">Analysis appears here.</div>
        </section>
      </section>
    </main>
  );
}