import { distanceKm, getProjectCenter } from './data-utils.js';

// A repeatable what-if track for a demo, not a weather model or forecast.
const WAYPOINTS = [
  [32.31, -81.62], [32.23, -81.43], [32.13, -81.30],
  [32.04, -81.16], [31.99, -81.01], [31.90, -80.87],
];
const FACILITY_POINTS = { hospital: 45, nursing_home: 40, fire_station: 35 };
const FACILITY_NAMES = { hospital: 'Hospital', nursing_home: 'Nursing home', fire_station: 'Fire station' };
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export function displayPriorityLevel(tier) {
  if (tier === 'High') return 'High';
  if (tier === 'Review') return 'Monitor';
  return 'Low';
}

export function priorityReason(site, stormActive) {
  if (stormActive && Number.isFinite(site?.corridorKm) && site.corridorKm <= 20) {
    return 'This facility is near the simulated storm path; confirm local conditions and site contacts before using it in planning.';
  }
  if (Number.isFinite(site?.nearestProjectKm) && site.nearestProjectKm <= 15) {
    return 'This facility is near a demo utility project; proximity does not establish service or operational dependence.';
  }
  return 'This facility is included as planning context; verify its role and location before relying on it.';
}

export function generateScenarioTrack() {
  const points = [];
  for (let segment = 0; segment < WAYPOINTS.length - 1; segment += 1) {
    const p0 = WAYPOINTS[Math.max(0, segment - 1)];
    const p1 = WAYPOINTS[segment];
    const p2 = WAYPOINTS[segment + 1];
    const p3 = WAYPOINTS[Math.min(WAYPOINTS.length - 1, segment + 2)];
    for (let step = 0; step < 10; step += 1) {
      const t = step / 10;
      const cubic = (a, b, c, d) => 0.5 * (
        2 * b + (-a + c) * t +
        (2 * a - 5 * b + 4 * c - d) * t * t +
        (-a + 3 * b - 3 * c + d) * t * t * t
      );
      const progress = (segment + t) / (WAYPOINTS.length - 1);
      points.push([
        cubic(p0[0], p1[0], p2[0], p3[0]) +
          0.008 * Math.sin(progress * Math.PI * 4) * Math.sin(progress * Math.PI),
        cubic(p0[1], p1[1], p2[1], p3[1]),
      ]);
    }
  }
  points.push(WAYPOINTS.at(-1));
  return points;
}

export function distanceToTrackKm(site, track) {
  if (!Number.isFinite(site?.lat) || !Number.isFinite(site?.lon) || !Array.isArray(track) || !track.length) return null;
  const latScale = 111.2;
  const lonScale = latScale * Math.cos(site.lat * Math.PI / 180);
  let nearest = Infinity;
  for (let i = 0; i < track.length - 1; i += 1) {
    const [latA, lonA] = track[i];
    const [latB, lonB] = track[i + 1];
    const ax = (lonA - site.lon) * lonScale;
    const ay = (latA - site.lat) * latScale;
    const bx = (lonB - site.lon) * lonScale;
    const by = (latB - site.lat) * latScale;
    const dx = bx - ax;
    const dy = by - ay;
    const t = clamp(-(ax * dx + ay * dy) / (dx * dx + dy * dy || 1), 0, 1);
    nearest = Math.min(nearest, Math.hypot(ax + t * dx, ay + t * dy));
  }
  return track.length === 1
    ? distanceKm(site.lat, site.lon, track[0][0], track[0][1])
    : nearest;
}

export function rankPrioritySites(sites, projects, stormActive, track = generateScenarioTrack()) {
  const centers = projects.map(getProjectCenter).filter(Boolean);
  return sites.map((site) => {
    const base = FACILITY_POINTS[site.type] ?? 20;
    const corridorKm = distanceToTrackKm(site, track);
    const nearestProjectKm = centers.length
      ? Math.min(...centers.map((center) => distanceKm(site.lat, site.lon, center.lat, center.lon)))
      : null;
    const exposure = stormActive && corridorKm !== null
      ? Math.round(clamp((20 - corridorKm) / 20, 0, 1) * 40)
      : 0;
    const projectProximity = nearestProjectKm !== null
      ? Math.round(clamp((15 - nearestProjectKm) / 15, 0, 1) * 15)
      : 0;
    const score = base + exposure + projectProximity;
    const tier = stormActive && score >= 70 ? 'High' : score >= 50 ? 'Review' : 'Monitor';
    return {
      ...site,
      score,
      tier,
      corridorKm,
      nearestProjectKm,
      factors: { facility: base, exposure, projectProximity },
      facilityLabel: FACILITY_NAMES[site.type] || 'Community site',
    };
  }).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
    .map((site, index) => ({ ...site, rank: index + 1 }));
}