export const OVERLAP_THRESHOLD_MILES = 25;
export const MILES_PER_KILOMETER = 0.621371192237334;

function isValidCoordinate(point) {
  const supplied = (value) =>
    typeof value === 'number' ||
    (typeof value === 'string' && value.trim() !== '');
  return (
    point &&
    supplied(point.lat) &&
    supplied(point.lon) &&
    Number.isFinite(Number(point.lat)) &&
    Number.isFinite(Number(point.lon)) &&
    Number(point.lat) >= -90 &&
    Number(point.lat) <= 90 &&
    Number(point.lon) >= -180 &&
    Number(point.lon) <= 180
  );
}

export function getProjectCenter(project) {
  const subpoints = Array.isArray(project?.subpoints) ? project.subpoints : [];

  if (subpoints.length > 0) {
    // The challenge specifies one located point or the midpoint of two named points.
    if (subpoints.length > 2 || !subpoints.every(isValidCoordinate)) return null;
    const pointCount = subpoints.length;
    const lat =
      subpoints.reduce((total, point) => total + Number(point.lat), 0) /
      pointCount;
    const lon =
      subpoints.reduce((total, point) => total + Number(point.lon), 0) /
      pointCount;
    const method =
      pointCount === 1
        ? `Single located point: ${subpoints[0].name || 'unnamed point'}`
        : `Midpoint: ${subpoints[0].name || 'point 1'} ↔ ${subpoints[1].name || 'point 2'}`;

    return { lat, lon, method, pointCount };
  }

  if (isValidCoordinate(project)) {
    return {
      lat: Number(project.lat),
      lon: Number(project.lon),
      method: 'Single supplied point',
      pointCount: 1,
    };
  }

  return null;
}

export function distanceKm(lat1, lon1, lat2, lon2) {
  const toRad = (degrees) => (degrees * Math.PI) / 180;
  const earthRadiusKm = 6371;
  const deltaLat = toRad(lat2 - lat1);
  const deltaLon = toRad(lon2 - lon1);
  const a =
    Math.sin(deltaLat / 2) ** 2 +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(deltaLon / 2) ** 2;
  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function planningWindowsOverlap(projectA, projectB) {
  const inputs = [
    projectA?.start,
    projectA?.end,
    projectB?.start,
    projectB?.end,
  ];
  if (
    inputs.some(
      (value) =>
        value === null ||
        value === undefined ||
        (typeof value === 'string' && value.trim() === ''),
    )
  ) {
    return null;
  }
  const values = inputs.map(Number);
  if (!values.every(Number.isFinite)) return null;

  const [startA, endA, startB, endB] = values;
  if (endA < startA || endB < startB) return null;
  return startA <= endB && startB <= endA;
}

export function formatDistanceMiles(miles) {
  if (!Number.isFinite(miles)) return 'Not available';
  const rounded = miles.toFixed(2);
  // A qualifying pair must not appear as 25.00 mi due to display rounding.
  return miles < OVERLAP_THRESHOLD_MILES && Number(rounded) >= OVERLAP_THRESHOLD_MILES
    ? '<25.00'
    : rounded;
}

function parseIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return null;
  }

  const timestamp = Date.parse(`${value}T00:00:00Z`);
  if (!Number.isFinite(timestamp)) {
    return null;
  }
  const parsed = new Date(timestamp);
  if (parsed.toISOString().slice(0, 10) !== value) {
    return null;
  }
  return timestamp;
}

export function getInServiceDateGapDays(projectA, projectB) {
  const dateA = parseIsoDate(projectA?.inServiceDate);
  const dateB = parseIsoDate(projectB?.inServiceDate);
  if (dateA === null || dateB === null) {
    return null;
  }
  return Math.round(Math.abs(dateA - dateB) / 86_400_000);
}

export function buildOverlapRows(projects, utilityACode, utilityBCode) {
  if (!utilityACode || !utilityBCode || utilityACode === utilityBCode) {
    return [];
  }

  const utilityAProjects = projects.filter(
    (project) => project.utility === utilityACode,
  );
  const utilityBProjects = projects.filter(
    (project) => project.utility === utilityBCode,
  );
  const rows = [];

  utilityAProjects.forEach((d) => {
    const dCenter = getProjectCenter(d);
    if (!dCenter) return;

    utilityBProjects.forEach((g) => {
      const gCenter = getProjectCenter(g);
      if (!gCenter) return;

      const dist = distanceKm(
        dCenter.lat,
        dCenter.lon,
        gCenter.lat,
        gCenter.lon,
      );
      const distMiles = dist * MILES_PER_KILOMETER;
      if (distMiles >= OVERLAP_THRESHOLD_MILES) return;

      rows.push({
        d,
        g,
        dCenter,
        gCenter,
        dist,
        distMiles,
        timeOverlap: planningWindowsOverlap(d, g),
        inServiceDateGapDays: getInServiceDateGapDays(d, g),
      });
    });
  });

  return rows;
}

// A submitted workbook coordinate alone is not sufficient to enter the sourced map.
export function buildSourcedOverlapRows(projects) {
  const eligible = projects.filter((project) =>
    project.sourceUrl && project.sourcePage && project.mapEvidence &&
    project.locationConfidence === 'named-endpoint' && getProjectCenter(project),
  );
  return buildOverlapRows(eligible, 'DESC', 'GPC');
}