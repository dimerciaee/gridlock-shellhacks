import { distanceKm } from './data-utils.js';
import {
  budgetForProject, calculateResiliencePriority, isCoastalPlanningArea,
} from './resilience-priority.js';

const make = (tag, className, value) => {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (value !== undefined) element.textContent = value;
  return element;
};

const money = (amount) => `$${(amount / 1_000_000).toFixed(2)}M`;
const labels = {
  distanceScore: 'Distance',
  infrastructureScore: 'Shared infrastructure',
  timelineScore: 'Date gap',
  costScore: 'Project budget',
  criticalityScore: 'Listed critical site',
  weatherRiskScore: 'Coastal-area proxy',
};

function buildCard({ title, basis, distanceMiles, timeGapDays, projectA, projectB, centers, sites, focus }) {
  const budgetA = budgetForProject(projectA);
  const budgetB = budgetForProject(projectB);
  const budgets = [budgetA?.amount, budgetB?.amount].filter((amount) => Number.isFinite(amount));
  const criticalSite = centers?.length === 2
    ? sites.find((site) => ['hospital', 'fire_station', 'nursing_home'].includes(site.type) &&
      centers.some((center) => distanceKm(center.lat, center.lon, site.lat, site.lon) < 20))
    : null;
  const coastalArea = centers?.length === 2 &&
    centers.every((point) => isCoastalPlanningArea(point) === true) ? true : null;
  const score = calculateResiliencePriority({
    distanceMiles, timeGapDays, budgets,
    infrastructureLinked: null, // No pair-linked network inventory is available.
    nearCriticalSite: criticalSite ? true : null,
    coastalArea,
  });
  const card = make('article', 'resilience-card');
  const heading = make('h3', '', title);
  const plainReasons = [];
  if (score.parts.distanceScore > 0) {
    plainReasons.push('the located project points are close enough to review together');
  }
  if (score.parts.timelineScore > 0) {
    plainReasons.push('published in-service dates provide useful planning context');
  }
  const largeBudget = [budgetA, budgetB].find((budget) => budget?.amount > 30_000_000);
  if (largeBudget) plainReasons.push('a pasted budget record suggests a larger planning item');
  const rationale = make('p', '',
    plainReasons.length
      ? `Why it matters: ${plainReasons.join(' and ')}.`
      : 'Why it matters: Available records do not yet establish a coordination benefit; verify both projects before ranking.');
  const nextAction = make('p', 'resilience-next-action',
    'Recommended next action: Schedule a joint review to compare scope, permits, access, and construction timing.');
  card.append(heading, nextAction);

  const details = make('details', 'resilience-details');
  details.appendChild(make('summary', '', 'View Technical Details'));
  details.appendChild(rationale);
  const scoreDetails = make('details', 'resilience-score-details');
  scoreDetails.appendChild(make('summary', '', 'View Details'));
  scoreDetails.appendChild(make('div', 'resilience-score',
    `${score.knownTotal} known points / ${score.maxPossible} possible · ${score.assessed}/6 factors assessed`));
  const factors = make('ul', 'resilience-factors');
  for (const [key, label] of Object.entries(labels)) {
    const points = score.parts[key];
    factors.appendChild(make('li', '', `${label}: ${points === null ? 'not assessed' : `+${points}`}`));
  }
  scoreDetails.appendChild(factors);
  scoreDetails.appendChild(make('p', 'resilience-basis', basis));
  if (budgetA || budgetB) {
    const budgetText = [budgetA, budgetB].filter(Boolean)
      .map((budget) => `${budget.name}: ${money(budget.amount)}; ${budget.citation}`).join(' ');
    scoreDetails.appendChild(make('p', 'resilience-basis', budgetText));
  } else {
    scoreDetails.appendChild(make('p', 'resilience-basis', 'No supported budget is available for these projects.'));
  }
  if (criticalSite) {
    scoreDetails.appendChild(make('p', 'resilience-basis',
      `${criticalSite.name} is within 20 km of a named endpoint in demo facility data. Near does not mean electrically served or operationally dependent.`));
  }
  scoreDetails.appendChild(make('p', 'resilience-missing',
    'Not established: shared infrastructure connection, comprehensive hospital/airport/emergency/water/military coverage, FEMA flood zone, storm surge, hurricane frequency, and wind exposure. Coastal points are a broad scenario proxy, not measured hazard.'));
  details.appendChild(scoreDetails);
  card.appendChild(details);
  if (focus) {
    const button = make('button', 'resilience-focus', 'Find endpoints on map');
    button.type = 'button';
    button.addEventListener('click', focus);
    card.appendChild(button);
  }
  return { card, score };
}

export function renderResilienceList({
  target, pairs, submittedCandidates, sites, onFocusPair,
}) {
  target.replaceChildren();
  const sourced = [...pairs].map((pair) => ({
    pair,
    result: buildCard({
      title: `${pair.d.name} ↔ ${pair.g.name}`,
      basis: 'Source-linked named endpoints and exact planned in-service dates. This is point proximity, not confirmed route overlap; construction schedule and GPC budget remain unverified.',
      distanceMiles: pair.distMiles,
      timeGapDays: pair.inServiceDateGapDays,
      projectA: pair.d,
      projectB: pair.g,
      centers: [pair.dCenter, pair.gCenter],
      sites,
      focus: () => onFocusPair(pair),
    }),
  })).sort((a, b) => b.result.score.knownTotal - a.result.score.knownTotal);
  if (!sourced.length) {
    target.appendChild(make('p', 'resilience-empty',
      'No source-linked endpoint pair is ready to rank. Check the cited project data; submitted workbook candidates are not verified map matches.'));
  } else {
    sourced.forEach(({ result }) => target.appendChild(result.card));
  }

  if (submittedCandidates.length) {
    const workbook = make('details', 'resilience-details resilience-workbook');
    workbook.appendChild(make('summary', '',
      `Submitted workbook candidates (${submittedCandidates.length}) · unverified, view separately`));
    workbook.appendChild(make('p', 'resilience-basis',
      'Workbook distances and day gaps have not been independently reconciled with current filings; no geolocated endpoints, coastal or critical-site points are awarded.'));
    const candidates = submittedCandidates.map((candidate) => ({
      candidate,
      result: buildCard({
        title: `${candidate.descName} ↔ ${candidate.gpcName}`,
        basis: 'Submitted workbook only: distance and day gap unverified against current utility plans. Not mapped as a sourced pair.',
        distanceMiles: candidate.distanceMiles,
        timeGapDays: candidate.dateGapDays,
        projectA: { name: candidate.descName },
        projectB: { name: candidate.gpcName },
        centers: null,
        sites,
        focus: null,
      }),
    })).sort((a, b) => b.result.score.knownTotal - a.result.score.knownTotal);
    candidates.forEach(({ result }) => workbook.appendChild(result.card));
    target.appendChild(workbook);
  }
  return sourced[0]?.pair ?? null;
}