import assert from 'node:assert/strict';
import test from 'node:test';
import {
  classifyScenarioProximity,
  summarizeScenarioProximity,
} from './scenario-proximity.js';

test('scenario bands use explicit corridor-distance thresholds', () => {
  assert.equal(classifyScenarioProximity(0).key, 'red');
  assert.equal(classifyScenarioProximity(5).key, 'red');
  assert.equal(classifyScenarioProximity(5.01).key, 'orange');
  assert.equal(classifyScenarioProximity(10).key, 'orange');
  assert.equal(classifyScenarioProximity(10.01).key, 'yellow');
  assert.equal(classifyScenarioProximity(20).key, 'yellow');
  assert.equal(classifyScenarioProximity(20.01).key, 'green');
  assert.equal(classifyScenarioProximity(null), null);
  assert.equal(classifyScenarioProximity(-1), null);
});

test('scenario impact counts include only facilities with a measurable simulated distance', () => {
  assert.deepEqual(summarizeScenarioProximity([
    { corridorKm: 4 }, { corridorKm: 9 }, { corridorKm: 18 },
    { corridorKm: 27 }, { corridorKm: null },
  ]), {
    total: 5,
    assessed: 4,
    within20Km: 3,
    bands: { red: 1, orange: 1, yellow: 1, green: 1 },
  });
});