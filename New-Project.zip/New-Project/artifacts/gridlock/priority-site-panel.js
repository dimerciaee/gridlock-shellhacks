import './gridlock-planning.css';
import { displayPriorityLevel, priorityReason } from './storm-priority.js';

function makeElement(tagName, className, text) {
  const element = document.createElement(tagName);
  if (className) element.className = className;
  if (text !== undefined && text !== null) element.textContent = String(text);
  return element;
}

function setTestId(element, testId) {
  if (element && testId) element.dataset.testid = testId;
  return element;
}

function slug(value) {
  return String(value ?? 'site')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 64) || 'site';
}

function formatNumber(value, digits = 1) {
  return Number.isFinite(Number(value)) ? Number(value).toFixed(digits) : 'Not available';
}

function forecastAlertStatus(forecast) {
  if (forecast === 'loading' || forecast?.loading) return 'Weather alerts loading';
  if (forecast === 'error' || forecast?.error) return 'Weather alert status unavailable';
  if (!forecast) return 'Weather alerts not requested';
  const count = Array.isArray(forecast.alerts) ? forecast.alerts.length : 0;
  return count ? `${count} active NOAA weather alert${count === 1 ? '' : 's'} nearby` : 'No active NOAA weather alerts nearby';
}

function appendMetric(parent, label, value, help, testId) {
  const item = makeElement('div', 'priority-site-metric');
  item.append(
    makeElement('span', 'priority-site-metric-label', label),
    setTestId(makeElement('strong', 'priority-site-metric-value', value), testId),
  );
  if (help) item.appendChild(makeElement('small', 'priority-site-metric-help', help));
  parent.appendChild(item);
}

function renderForecast(panel, forecast, siteKey) {
  const section = makeElement('section', 'priority-site-forecast');
  const heading = makeElement('div', 'priority-site-section-heading');
  heading.append(
    makeElement('div', 'priority-site-section-kicker', 'NOAA POINT FORECAST'),
    makeElement('h3', '', 'Conditions at the selected location'),
  );
  section.appendChild(heading);

  if (forecast === null || forecast === undefined) {
    section.appendChild(setTestId(makeElement('p', 'priority-site-muted', 'Forecast not requested for this site.'), `status-forecast-${siteKey}`));
    return section;
  }
  if (forecast === 'loading' || forecast.loading) {
    section.appendChild(setTestId(makeElement('p', 'priority-site-loading', 'Loading NOAA point forecast…'), `status-forecast-${siteKey}`));
    return section;
  }
  if (forecast === 'error' || forecast.error) {
    section.appendChild(setTestId(makeElement('p', 'priority-site-error', 'NOAA point forecast is unavailable right now.'), `status-forecast-${siteKey}`));
    return section;
  }

  const period = forecast.period || forecast.forecastPeriod || 'Current forecast period';
  const checkedAt = forecast.checkedAt ? `Checked ${forecast.checkedAt}` : 'Check weather.gov before operational use.';
  section.append(
    setTestId(makeElement('p', 'priority-site-forecast-period', `${period} · ${checkedAt}`), `text-forecast-period-${siteKey}`),
    setTestId(makeElement('p', 'priority-site-forecast-summary', forecast.shortForecast || 'Short forecast not available.'), `text-forecast-summary-${siteKey}`),
  );
  const metrics = makeElement('div', 'priority-site-metrics');
  appendMetric(metrics, 'Temperature', forecast.temperature ?? 'Not available', 'Forecast value, not a sensor reading.', `text-forecast-temperature-${siteKey}`);
  appendMetric(metrics, 'Wind', forecast.wind ?? 'Not available', 'Forecast wind at this point.', `text-forecast-wind-${siteKey}`);
  appendMetric(metrics, 'Rain chance', forecast.rainChance == null ? 'Not available' : `${forecast.rainChance}%`, 'NOAA probability of precipitation.', `text-forecast-rain-${siteKey}`);
  section.appendChild(metrics);
  const alerts = Array.isArray(forecast.alerts) ? forecast.alerts : [];
  const alertText = alerts.length
    ? `${alerts.length} active NOAA alert${alerts.length === 1 ? '' : 's'} near this point`
    : 'No active NOAA alerts found near this point';
  section.appendChild(setTestId(makeElement('p', 'priority-site-alerts', alertText), `status-forecast-alerts-${siteKey}`));
  if (alerts.length) {
    const alertList = makeElement('ul', 'priority-site-alert-list');
    alerts.slice(0, 3).forEach((alert, index) => {
      const event = alert?.event || 'Weather alert';
      const headline = alert?.headline || '';
      const severity = alert?.severity ? ` · ${alert.severity}` : '';
      const area = alert?.area ? ` · ${alert.area}` : '';
      alertList.appendChild(setTestId(
        makeElement('li', '', `${event}${severity}${area}${headline ? ` — ${headline}` : ''}`),
        `row-forecast-alert-${siteKey}-${index + 1}`,
      ));
    });
    section.appendChild(alertList);
    if (alerts.length > 3) {
      section.appendChild(makeElement('p', 'priority-site-muted', `Showing 3 of ${alerts.length} nearby alerts.`));
    }
  }
  section.appendChild(makeElement('p', 'priority-site-disclaimer', 'This is a NOAA point forecast at the selected coordinates, not equipment telemetry or a live on-site reading. Nearby alerts do not establish facility impact.'));
  const source = setTestId(makeElement('a', 'priority-site-weather-source', 'Open weather.gov'), `link-noaa-weather-${siteKey}`);
  source.href = 'https://www.weather.gov/';
  source.target = '_blank';
  source.rel = 'noopener noreferrer';
  section.appendChild(source);
  return section;
}

function renderSourcePair(parent, nearestSourcePair, siteKey, onOpenOpportunity) {
  const section = makeElement('section', 'priority-site-source-pair');
  section.append(
    makeElement('div', 'priority-site-section-kicker', 'SOURCE CONTEXT'),
    makeElement('h3', '', 'Nearest located source pair'),
  );
  if (!nearestSourcePair) {
    section.appendChild(setTestId(makeElement('p', 'priority-site-muted', 'No nearby independently located source pair was supplied.'), `status-source-pair-${siteKey}`));
    parent.appendChild(section);
    return;
  }
  section.append(
    setTestId(makeElement('strong', 'priority-site-source-title', nearestSourcePair.title || 'Located source pair'), `text-source-pair-title-${siteKey}`),
    setTestId(makeElement('p', 'priority-site-source-distance', `${formatNumber(nearestSourcePair.distanceKm)} km`), `text-source-pair-distance-${siteKey}`),
    setTestId(makeElement('p', 'priority-site-source-explanation', nearestSourcePair.explanation || 'Point proximity only.'), `text-source-pair-explanation-${siteKey}`),
    makeElement('p', 'priority-site-disclaimer', 'Located point proximity is not full-route overlap, electrical connectivity, or confirmed shared construction.'),
  );
  if (nearestSourcePair.pairId && typeof onOpenOpportunity === 'function') {
    const button = setTestId(
      makeElement('button', 'priority-site-opportunity-button', 'Open coordination opportunity'),
      `button-open-source-opportunity-${siteKey}`,
    );
    button.type = 'button';
    button.addEventListener('click', () => onOpenOpportunity(nearestSourcePair.pairId));
    section.appendChild(button);
  }
  parent.appendChild(section);
}

function renderDemoProjects(parent, nearbyDemoProjects, siteKey) {
  if (!Array.isArray(nearbyDemoProjects) || !nearbyDemoProjects.length) return;
  const section = makeElement('section', 'priority-site-demo-projects');
  section.append(
    makeElement('div', 'priority-site-section-kicker', 'SCENARIO CONTEXT'),
    makeElement('h3', '', 'Nearby sample projects'),
    makeElement('p', 'priority-site-muted', 'Demo records shown for planning discussion; proximity does not verify a facility relationship.'),
  );
  const list = makeElement('ul', 'priority-site-demo-list');
  nearbyDemoProjects.forEach((project, index) => {
    const itemKey = slug(project?.id || project?.name || `project-${index + 1}`);
    const item = setTestId(makeElement('li', 'priority-site-demo-item'), `row-demo-project-${siteKey}-${itemKey}`);
    const name = setTestId(makeElement('strong', '', project?.name || 'Unnamed demo project'), `text-demo-project-${siteKey}-${itemKey}`);
    const label = makeElement('span', 'priority-site-demo-label', 'DEMO');
    const detail = makeElement('span', 'priority-site-demo-detail', project?.distanceKm == null ? 'Sample project record' : `${formatNumber(project.distanceKm)} km from selected site`);
    item.append(name, label, detail);
    list.appendChild(item);
  });
  section.appendChild(list);
  parent.appendChild(section);
}

function renderMapLinks(parent, site, siteKey) {
  const lat = Number(site?.lat);
  const lon = Number(site?.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
  const section = makeElement('section', 'priority-site-map-links');
  section.append(
    makeElement('div', 'priority-site-section-kicker', 'LOCATION'),
    makeElement('p', 'priority-site-muted', `${lat.toFixed(5)}, ${lon.toFixed(5)} · links open a map at the selected point`),
  );
  const links = makeElement('div', 'priority-site-link-row');
  const google = setTestId(makeElement('a', 'priority-site-map-link', 'Google Maps'), `link-google-maps-${siteKey}`);
  google.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${lat},${lon}`)}`;
  google.target = '_blank';
  google.rel = 'noopener noreferrer';
  const osm = setTestId(makeElement('a', 'priority-site-map-link', 'OpenStreetMap'), `link-openstreetmap-${siteKey}`);
  osm.href = `https://www.openstreetmap.org/?mlat=${encodeURIComponent(lat)}&mlon=${encodeURIComponent(lon)}#map=12/${encodeURIComponent(lat)}/${encodeURIComponent(lon)}`;
  osm.target = '_blank';
  osm.rel = 'noopener noreferrer';
  links.append(google, osm);
  section.appendChild(links);
  parent.appendChild(section);
}

/**
 * Render a scenario-ranked facility panel. The caller supplies forecast state and
 * owns fetching; this module only renders and emits the close interaction.
 */
export function renderPrioritySitePanel({
  site,
  stormMode,
  forecast,
  nearestSourcePair,
  nearbyDemoProjects,
  onOpenOpportunity,
  onClose,
}) {
  const siteKey = slug(site?.name || 'selected-site');
  const panel = setTestId(makeElement('aside', 'priority-site-panel'), `panel-priority-site-${siteKey}`);
  panel.setAttribute('aria-label', 'Priority site details');
  const header = makeElement('header', 'priority-site-header');
  const close = setTestId(makeElement('button', 'priority-site-close', 'Close'), `button-close-priority-site-${siteKey}`);
  close.type = 'button';
  close.setAttribute('aria-label', 'Close priority site details');
  close.addEventListener('click', () => {
    if (typeof onClose === 'function') onClose();
  });
  const heading = makeElement('div', 'priority-site-heading');
  heading.append(
    makeElement('div', 'priority-site-section-kicker', 'FACILITY CONTEXT'),
    setTestId(makeElement('h2', '', site?.name || 'Selected site'), `text-priority-site-name-${siteKey}`),
    setTestId(makeElement('p', 'priority-site-facility', site?.facilityLabel || 'Facility type not available'), `text-priority-site-facility-${siteKey}`),
  );
  header.append(heading, close);

  const technicalDetails = makeElement('details', 'priority-site-technical-details');
  technicalDetails.appendChild(makeElement('summary', '', 'View Technical Details'));
  const score = makeElement('section', 'priority-site-score-block');
  const scoreValue = Number.isFinite(Number(site?.score)) ? `${site.score}/100` : 'Not scored';
  score.append(
    makeElement('span', 'priority-site-score-label', 'Scenario screening score'),
    setTestId(makeElement('strong', 'priority-site-score', scoreValue), `text-priority-site-score-${siteKey}`),
    makeElement('p', 'priority-site-disclaimer', 'Demo/scenario screening only — not a live risk rating or dispatch recommendation. Do not infer that this facility is at risk from the simulation.'),
  );

  const factors = makeElement('section', 'priority-site-factors');
  factors.append(
    makeElement('div', 'priority-site-section-kicker', 'SCREENING INPUTS'),
    makeElement('h3', '', 'What shaped the scenario score'),
  );
  const factorList = makeElement('dl', 'priority-site-factor-list');
  const factorEntries = Object.entries(site?.factors || {});
  const factorLabels = {
    facility: 'Facility base score',
    projectProximity: 'Demo project proximity score',
    exposure: 'Simulated weather/path exposure score',
  };
  if (!factorEntries.length) {
    factorList.appendChild(makeElement('dd', 'priority-site-muted', 'No factor breakdown was supplied.'));
  } else {
    factorEntries.forEach(([label, value]) => {
      const displayLabel = factorLabels[label] || label;
      const term = setTestId(makeElement('dt', '', displayLabel), `text-priority-factor-label-${siteKey}-${slug(label)}`);
      const description = setTestId(makeElement('dd', '', value), `text-priority-factor-${siteKey}-${slug(label)}`);
      factorList.append(term, description);
    });
  }
  factors.appendChild(factorList);

  const corridor = makeElement('p', 'priority-site-corridor');
  corridor.append(
    makeElement('strong', '', 'Simulated corridor distance'),
    setTestId(makeElement('span', '', `${formatNumber(site?.corridorKm)} km`), `text-priority-corridor-${siteKey}`),
    makeElement('small', '', 'Distance to a deterministic what-if path; not measured hazard or outage likelihood.'),
  );

  const content = makeElement('div', 'priority-site-content');
  const displayTier = displayPriorityLevel(site?.tier);
  const priority = makeElement('p', 'priority-site-priority', `Priority Level: ${displayTier}`);
  const weatherStatus = setTestId(
    makeElement('p', 'priority-site-weather-status', forecastAlertStatus(forecast)),
    `status-weather-alerts-${siteKey}`,
  );
  // Keep the executive surface to the facility facts and qualitative screening result.
  // The numeric score, rationale, coordinates, source context, and caveats stay below.
  const technicalMethod = makeElement(
    'p',
    'priority-site-disclaimer',
    `Methodology: ${priorityReason(site, stormMode)} This deterministic scenario is not a weather forecast, hazard assessment, outage finding, or dispatch recommendation.`,
  );
  const scoreDetails = makeElement('details', 'priority-site-score-details');
  scoreDetails.appendChild(makeElement('summary', '', 'View Details'));
  scoreDetails.append(score, factors);
  technicalDetails.append(
    scoreDetails,
    technicalMethod,
  );
  const technicalContent = makeElement('div', 'priority-site-technical-content');
  renderSourcePair(technicalContent, nearestSourcePair, siteKey, onOpenOpportunity);
  technicalContent.appendChild(renderForecast(technicalContent, forecast, siteKey));
  renderDemoProjects(technicalContent, nearbyDemoProjects, siteKey);
  renderMapLinks(technicalContent, site, siteKey);
  technicalDetails.append(technicalContent);
  content.append(priority, corridor, weatherStatus, technicalDetails);

  panel.append(header, content);
  return panel;
}