import assert from 'node:assert/strict';
import test from 'node:test';
import {
  calculateBudgetRangeSavings,
  calculateCoordinationScore,
  getCoordinationPotentialScore,
  gradeCoordinationPotentialScore,
  calculateSnapshotSavings,
  estimateGeorgiaPowerInvestment,
  POTENTIAL_SAVINGS_SOURCE_EXAMPLES,
  SCHEDULE_SAVINGS_SCENARIO,
  getCoordinationScore,
  scenarioSavings,
} from './opportunity-model.js';

test('coordination potential normalizes its grade over available drivers', () => {
  const partial = getCoordinationPotentialScore({
    distanceMiles: 3.02,
    timeGapDays: 183,
    projectCosts: null,
    sharedResourceCount: null,
    regionalResiliencePoints: null,
  });
  assert.equal(partial.knownTotal, 43);
  assert.equal(partial.assessedMax, 50);
  assert.equal(partial.normalizedScore, 86);
  assert.equal(partial.maxPossible, 100);
  assert.equal(partial.parts.geographicProximity, 30);
  assert.equal(partial.parts.timelineAlignment, 13);
  assert.equal(partial.parts.projectScale, null);
  assert.equal(partial.parts.sharedResourceOpportunity, null);
  assert.equal(partial.parts.regionalResilienceImpact, null);
  assert.equal(partial.complete, false);
  assert.deepEqual(partial.grade, { grade: 'A', label: 'High' });
  assert.deepEqual(partial.omittedDrivers, [
    'projectScale', 'sharedResourceOpportunity', 'regionalResilienceImpact',
  ]);
});

test('a complete 87-point example receives the requested A / High grade', () => {
  const complete = getCoordinationPotentialScore({
    distanceMiles: 4,
    timeGapDays: 120,
    projectCosts: [20_000_000, 20_000_000],
    sharedResourceCount: 1,
    regionalResiliencePoints: 12,
  });
  assert.equal(complete.knownTotal, 87);
  assert.equal(complete.complete, true);
  assert.deepEqual(complete.grade, { grade: 'A', label: 'High' });
  assert.equal(complete.parts.sharedResourceOpportunity, 10);
});

test('coordination potential grade bands use the requested boundaries', () => {
  assert.equal(gradeCoordinationPotentialScore(90).grade, 'A+');
  assert.equal(gradeCoordinationPotentialScore(89).grade, 'A');
  assert.equal(gradeCoordinationPotentialScore(79).grade, 'B');
  assert.equal(gradeCoordinationPotentialScore(69).grade, 'C');
  assert.equal(gradeCoordinationPotentialScore(59).grade, 'D');
  assert.equal(gradeCoordinationPotentialScore(101), null);
});

test('score adds only known evidence and exposes missing components', () => {
  const partial = getCoordinationScore({ distanceMiles: 4.9, timeGapDays: 183 });
  assert.equal(partial.knownTotal, 60);
  assert.equal(partial.complete, false);
  assert.deepEqual(partial.missing, ['cost', 'infrastructure']);
  const complete = getCoordinationScore({
    distanceMiles: 5.65, timeGapDays: 152,
    projectCost: 20_000_001, infrastructureCount: 1,
  });
  assert.equal(complete.knownTotal, 100);
  assert.equal(complete.complete, true);
  assert.equal(getCoordinationScore({ distanceMiles: 12, timeGapDays: null }).parts.time, null);
});

test('illustrative components total $1.25M, never a sourced project cost', () => {
  assert.equal(scenarioSavings(), 1_250_000);
});

test('executive score follows the requested distance and date-gap formula', () => {
  assert.equal(calculateCoordinationScore(3.05, 183), 85);
  assert.equal(calculateCoordinationScore(5, 0), 90);
  assert.equal(calculateCoordinationScore(25, 600), 25);
  assert.equal(calculateCoordinationScore(25.01, 0), 0);
  assert.equal(calculateCoordinationScore(3, null), null);
  assert.equal(calculateCoordinationScore(NaN, 20), null);
  assert.equal(calculateCoordinationScore(-1, 20), null);
});

test('snapshot savings use the specified distance-tier percentages and exact pair baseline', () => {
  const close = calculateSnapshotSavings(4.99, [23_787_423, 16_212_577]);
  assert.equal(close.combinedInvestment, 40_000_000);
  assert.equal(close.distanceTier, 'Under 5 miles');
  assert.deepEqual(close.rates, { conservative: 0.02, expected: 0.04, maximum: 0.06 });
  assert.deepEqual(close.savings, { conservative: 800_000, expected: 1_600_000, maximum: 2_400_000 });

  const middle = calculateSnapshotSavings(5, [20_000_000, 20_000_000]);
  assert.equal(middle.distanceTier, '5–under 10 miles');
  assert.deepEqual(middle.rates, { conservative: 0.015, expected: 0.03, maximum: 0.05 });
  assert.deepEqual(middle.savings, { conservative: 600_000, expected: 1_200_000, maximum: 2_000_000 });

  const outer = calculateSnapshotSavings(10, [20_000_000, 20_000_000]);
  assert.equal(outer.distanceTier, '10–25 miles');
  assert.deepEqual(outer.rates, { conservative: 0.01, expected: 0.02, maximum: 0.04 });
  assert.deepEqual(outer.savings, { conservative: 400_000, expected: 800_000, maximum: 1_600_000 });
  assert.equal(calculateSnapshotSavings(25, [20_000_000, 20_000_000]).savings.maximum, 1_600_000);
  assert.equal(calculateSnapshotSavings(25.01, [20_000_000, 20_000_000]), null);
  assert.equal(calculateSnapshotSavings(4, [23_787_423]), null);
  assert.equal(calculateSnapshotSavings(4, [23_787_423, null]), null);
  assert.equal(calculateSnapshotSavings(null, [20_000_000, 20_000_000]), null);
  assert.equal(SCHEDULE_SAVINGS_SCENARIO, '30–90 days');
});

test('Georgia Power project types map to medium-confidence benchmark ranges', () => {
  const examples = [
    ['230kV Line Construction', '230kV Line Construction', 20_000_000, 40_000_000],
    ['230kV Reactor Project', 'SAV: MCINTOSH - PURRYSBURG 230KV REACTORS', 10_000_000, 20_000_000],
    ['115kV Rebuild', '115kV Rebuild', 5_000_000, 15_000_000],
    ['Substation Expansion', 'Substation Expansion', 10_000_000, 40_000_000],
  ];
  for (const [category, name, minimum, maximum] of examples) {
    assert.deepEqual(
      estimateGeorgiaPowerInvestment({ utility: 'GPC', name }),
      {
        category,
        minimum,
        maximum,
        confidence: 'Medium',
        costBasis: 'Transmission project benchmark',
      },
    );
  }
  assert.equal(estimateGeorgiaPowerInvestment({ utility: 'GPC', name: 'Regional planning study' }), null);
  assert.equal(estimateGeorgiaPowerInvestment({ utility: 'DESC', name: '230kV Line Construction' }), null);
});

test('budget range savings apply distance tiers to both ends of the combined investment', () => {
  const close = calculateBudgetRangeSavings(3.02, [
    { minimum: 23_787_423, maximum: 23_787_423 },
    { minimum: 10_000_000, maximum: 20_000_000 },
  ]);
  assert.deepEqual(close.combinedInvestmentRange, {
    minimum: 33_787_423,
    maximum: 43_787_423,
  });
  assert.deepEqual(close.rates, { conservative: 0.02, expected: 0.04, maximum: 0.06 });
  assert.deepEqual(close.savings, {
    conservative: { minimum: 675_748, maximum: 875_748 },
    expected: { minimum: 1_351_497, maximum: 1_751_497 },
    maximum: { minimum: 2_027_245, maximum: 2_627_245 },
  });

  const middle = calculateBudgetRangeSavings(5, [
    { minimum: 20_000_000, maximum: 40_000_000 },
    { minimum: 10_000_000, maximum: 20_000_000 },
  ]);
  assert.deepEqual(middle.rates, { conservative: 0.015, expected: 0.03, maximum: 0.05 });
  assert.deepEqual(middle.savings.expected, { minimum: 900_000, maximum: 1_800_000 });

  const outer = calculateBudgetRangeSavings(10, [
    { minimum: 20_000_000, maximum: 40_000_000 },
    { minimum: 10_000_000, maximum: 20_000_000 },
  ]);
  assert.deepEqual(outer.rates, { conservative: 0.01, expected: 0.02, maximum: 0.04 });
  assert.deepEqual(outer.savings.maximum, { minimum: 1_200_000, maximum: 2_400_000 });
  assert.equal(calculateBudgetRangeSavings(25, [
    { minimum: 1, maximum: 2 },
    { minimum: 3, maximum: 4 },
  ]).distanceTier, '10–25 miles');
  assert.equal(calculateBudgetRangeSavings(25.01, [
    { minimum: 1, maximum: 2 },
    { minimum: 3, maximum: 4 },
  ]), null);
  assert.equal(calculateBudgetRangeSavings(4, [
    { minimum: 5, maximum: 4 },
    { minimum: 3, maximum: 4 },
  ]), null);
});

test('source examples keep environmental reviews unallocated and separate from scenarios', () => {
  assert.deepEqual(
    POTENTIAL_SAVINGS_SOURCE_EXAMPLES.slice(0, 4).map(({ amount }) => amount),
    [800_000, 600_000, 300_000, 200_000],
  );
  assert.deepEqual(POTENTIAL_SAVINGS_SOURCE_EXAMPLES.map(({ source }) => source), [
    'Shared Equipment',
    'Shared Contractors',
    'Shared Staging Areas',
    'Shared Permitting',
    'Environmental Reviews',
  ]);
  assert.equal(
    POTENTIAL_SAVINGS_SOURCE_EXAMPLES
      .filter(({ amount }) => Number.isFinite(amount))
      .reduce((sum, { amount }) => sum + amount, 0),
    1_900_000,
  );
  assert.equal(POTENTIAL_SAVINGS_SOURCE_EXAMPLES.at(-1).amount, null);
});