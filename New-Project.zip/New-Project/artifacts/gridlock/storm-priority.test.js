import assert from 'node:assert/strict';
import test from 'node:test';
import {
  displayPriorityLevel, distanceToTrackKm, generateScenarioTrack, priorityReason, rankPrioritySites,
} from './storm-priority.js';

const track = generateScenarioTrack();
const sites = [
  { type: 'fire_station', name: 'Fire', lat: 32.05, lon: -81.1 },
  { type: 'hospital', name: 'Hospital', lat: 32.05, lon: -81.1 },
  { type: 'nursing_home', name: 'Nursing', lat: 32.05, lon: -81.1 },
];

test('scenario track is smoothly curved and repeatable, not four straight points', () => {
  assert.equal(track.length, 51);
  assert.deepEqual(generateScenarioTrack(), track);
  const slopes = track.slice(1).map((point, index) =>
    (point[0] - track[index][0]) / (point[1] - track[index][1]));
  assert(new Set(slopes.map((slope) => slope.toFixed(2))).size > 10);
});

test('priority ranking uses visible facility, scenario exposure, and demo project proximity factors', () => {
  const projects = [{ name: 'Demo', lat: 32.05, lon: -81.1 }];
  const calm = rankPrioritySites(sites, projects, false, track);
  const storm = rankPrioritySites(sites, projects, true, track);
  assert.deepEqual(storm.map((item) => item.name), ['Hospital', 'Nursing', 'Fire']);
  assert(storm.every((item) => item.factors.exposure > 0 && item.score > calm.find((s) => s.name === item.name).score));
  assert(storm.every((item) => item.score === Object.values(item.factors).reduce((a, b) => a + b, 0)));
  assert(calm.every((item) => item.tier !== 'High'));
  assert.equal(storm[0].factors.facility, 45);
  assert.equal(storm[0].factors.projectProximity, 15);
});

test('distant sites do not receive simulated exposure and unknown locations cannot be measured', () => {
  assert.equal(distanceToTrackKm({ lat: 0, lon: 0 }, []), null);
  const distant = rankPrioritySites([{ type: 'hospital', name: 'Distant', lat: 34, lon: -83 }], [], true, track)[0];
  assert.equal(distant.factors.exposure, 0);
  assert.equal(distant.factors.projectProximity, 0);
  assert.equal(distant.score, 45);
});

test('executive facility labels map internal tiers without changing ranking', () => {
  assert.equal(displayPriorityLevel('High'), 'High');
  assert.equal(displayPriorityLevel('Review'), 'Monitor');
  assert.equal(displayPriorityLevel('Monitor'), 'Low');
  assert.equal(priorityReason({
    corridorKm: 4,
    nearestProjectKm: 30,
  }, true), 'This facility is near the simulated storm path; confirm local conditions and site contacts before using it in planning.');
  assert.equal(
    priorityReason({ corridorKm: 35, nearestProjectKm: 10 }, false),
    'This facility is near a demo utility project; proximity does not establish service or operational dependence.',
  );
  assert.equal(
    priorityReason({ corridorKm: 35, nearestProjectKm: 30 }, false),
    'This facility is included as planning context; verify its role and location before relying on it.',
  );
});