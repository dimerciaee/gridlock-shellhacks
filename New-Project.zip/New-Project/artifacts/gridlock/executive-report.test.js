import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import { buildSourcedOverlapRows } from './data-utils.js';
import { renderReportDashboardHtml } from './report-dashboard.js';

const projects = JSON.parse(readFileSync(new URL('./public/verified-projects.json', import.meta.url), 'utf8'));
const pair = buildSourcedOverlapRows(projects)[0];

test('executive and technical reports share a printable, evidence-separated review list', () => {
  const html = renderReportDashboardHtml({
    primaryPair: pair,
    verifiedPairs: [pair],
    demoOpportunities: [{
      d: { ...pair.d, name: 'Demo project A', locationConfidence: 'unverified' },
      g: { ...pair.g, name: 'Demo project B', locationConfidence: 'unverified' },
      dCenter: { lat: 32.1, lon: -81.1 },
      gCenter: { lat: 32.2, lon: -81.2 },
      distMiles: 4.4,
      inServiceDateGapDays: null,
    }],
    submittedCandidates: [{
      descName: 'Workbook-only project',
      gpcName: 'Unverified partner project',
      distanceMiles: 14.34,
      dateGapDays: 183,
    }],
    facilityCount: 3,
    corridorCount: 2,
    riskCounts: { red: 1, orange: 1, yellow: 1, green: 0 },
    stormMode: true,
    interpretation: 'Review the independently located endpoints and current schedules with both utilities.',
    interpretationSource: 'Evidence-based template fallback · AI unavailable',
    generatedAt: '2026-09-26T12:00:00Z',
  });
  assert.match(html, /Coordination pairs for review/);
  assert.match(html, /Potential savings/);
  assert.match(html, /Not estimated/);
  assert(!html.includes('Known screen points'));
  assert(!html.includes('SCREENING RANK'));
  assert.match(html, /PROJECT COMPARISON/);
  assert.match(html, /SCHEMATIC · NOT TO SCALE/);
  assert.match(html, /Validate before estimating benefits/);
  assert.match(html, /Customers \/ outages/);
  assert.match(html, /Not assessed/);
  assert.match(html, /Submitted workbook candidates/);
  assert.match(html, /@media print/);
  assert.match(html, /@media\(max-width:760px\)/);
  assert.match(html, /<details class="appendix">/);
  assert.match(html, /<summary>View Technical Details<\/summary>/);
  assert.match(html, /2 of 3 listed demo facilities/);
  assert.match(html, /SUPPLEMENTAL PLANNING NOTE/);
  assert.match(html, /Evidence-based template fallback/);
  assert(!html.includes('$1.2M'));
  assert(!html.includes('45,000'));
  assert(!html.includes('<script'));
});

test('untrusted project names are escaped and unsafe links are not exported', () => {
  const html = renderReportDashboardHtml({
    primaryPair: {
      ...pair,
      d: { ...pair.d, name: '<script>alert(1)</script>', sourceUrl: 'javascript:alert(1)' },
    },
    verifiedPairs: [{
      ...pair,
      d: { ...pair.d, name: '<script>alert(1)</script>', sourceUrl: 'javascript:alert(1)' },
    }],
  });
  assert.match(html, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
  assert(!html.includes('href="javascript:'));
  assert(!html.includes('<script>alert(1)</script>'));
});

test('unsupported AI impact and savings claims are excluded from the report', () => {
  const html = renderReportDashboardHtml({
    primaryPair: pair,
    verifiedPairs: [pair],
    interpretation: 'This plan will affect 45,000 customers and save $2.1M.',
    interpretationSource: 'AI-assisted draft',
  });
  assert(!html.includes('45,000 customers'));
  assert(!html.includes('$2.1M'));
});

test('spelled-out cost claims are also excluded from the report', () => {
  const html = renderReportDashboardHtml({
    primaryPair: pair,
    verifiedPairs: [pair],
    interpretation: 'The teams could save two million dollars through a shared staging yard.',
    interpretationSource: 'AI-assisted draft',
  });
  assert(!html.includes('two million dollars'));
  assert(!html.includes('shared staging yard.'));
});

test('a report remains useful without a sourced pair and technical detail starts closed', () => {
  const html = renderReportDashboardHtml({ reportKind: 'technical' });
  assert.match(html, /Technical detail report/);
  assert.match(html, /No source-linked named-endpoint pair/);
  assert.match(html, /<details class="appendix">/);
  assert.match(html, /No served-customer or outage-impact data supplied/);
});