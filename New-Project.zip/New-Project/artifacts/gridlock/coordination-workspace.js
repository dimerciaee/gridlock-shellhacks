export function setupCoordinationWorkspace() {
  const dialog = document.getElementById('workspaceDialog');
  const title = document.getElementById('workspaceTitle');
  const messages = document.getElementById('workspaceMessages');
  const form = document.getElementById('workspaceForm');
  const noteInput = document.getElementById('workspaceNote');
  const status = document.getElementById('workspaceStatus');
  let storageKey = '';

  const examples = [
    ['Georgia Power · fictional example', 'Can share crane fleet Q2 2028.'],
    ['Dominion · fictional example', 'Environmental review underway.'],
  ];
  function appendMessage(sender, text) {
    const item = document.createElement('p');
    const label = document.createElement('strong');
    label.textContent = `${sender}: `;
    item.append(label, document.createTextNode(text));
    messages.appendChild(item);
  }
  function loadNotes() {
    try {
      const stored = JSON.parse(localStorage.getItem(storageKey) || '[]');
      return Array.isArray(stored) ? stored.filter((value) => typeof value === 'string') : [];
    } catch {
      status.textContent = 'Local notes could not be loaded.';
      return [];
    }
  }
  function render() {
    messages.replaceChildren();
    examples.forEach(([sender, text]) => appendMessage(sender, text));
    loadNotes().forEach((note) => appendMessage('Your local note · not sent', note));
  }
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const note = noteInput.value.trim();
    if (!note) return;
    try {
      const notes = loadNotes();
      notes.push(note);
      localStorage.setItem(storageKey, JSON.stringify(notes));
      noteInput.value = '';
      status.textContent = 'Saved on this device only. No utility received this note.';
      render();
    } catch {
      status.textContent = 'Unable to save locally. Copy your note before closing.';
    }
  });
  document.getElementById('closeWorkspaceBtn').addEventListener('click', () => dialog.close());
  return (pair, sourced) => {
    const key = `${sourced ? 'sourced' : 'demo'}:${pair.d.id || pair.d.name}:${pair.g.id || pair.g.name}`;
    storageKey = `gridlock-workspace:${key}`;
    title.textContent = `Coordination Workspace · ${sourced ? 'sourced point pair' : 'demo pair'}`;
    status.textContent = 'Local-only prototype. Verified company accounts are needed for real messaging.';
    noteInput.value = '';
    render();
    dialog.showModal();
  };
}