export const SCENARIO_PROXIMITY_BANDS = Object.freeze([
  { key: 'red', label: 'Very near', range: '0–5 km', maxKm: 5, color: '#b42318' },
  { key: 'orange', label: 'Near', range: '>5–10 km', maxKm: 10, color: '#d97706' },
  { key: 'yellow', label: 'Within screen', range: '>10–20 km', maxKm: 20, color: '#ca8a04' },
  { key: 'green', label: 'Outside screen', range: '>20 km', maxKm: Infinity, color: '#16805d' },
]);

export function classifyScenarioProximity(distanceKm) {
  if (typeof distanceKm !== 'number' || !Number.isFinite(distanceKm) || distanceKm < 0) {
    return null;
  }
  return SCENARIO_PROXIMITY_BANDS.find((band) => distanceKm <= band.maxKm);
}

export function summarizeScenarioProximity(sites) {
  const bands = Object.fromEntries(SCENARIO_PROXIMITY_BANDS.map(({ key }) => [key, 0]));
  let assessed = 0;

  for (const site of sites) {
    const band = classifyScenarioProximity(site?.corridorKm);
    if (!band) continue;
    assessed += 1;
    bands[band.key] += 1;
  }

  return {
    total: Array.isArray(sites) ? sites.length : 0,
    assessed,
    within20Km: bands.red + bands.orange + bands.yellow,
    bands,
  };
}