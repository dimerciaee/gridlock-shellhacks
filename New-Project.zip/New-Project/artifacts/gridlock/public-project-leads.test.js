import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const leads = JSON.parse(
  readFileSync(new URL('./public/public-project-leads.json', import.meta.url), 'utf8'),
);

test('public research leads remain separate from map-ready projects', () => {
  assert.equal(leads.length, 15);
  assert.equal(leads.filter((lead) => lead.utility === 'DESC').length, 5);
  assert.equal(leads.filter((lead) => lead.utility === 'GPC').length, 10);
  assert(leads.every((lead) => lead.center === null));
  assert(
    leads
      .filter((lead) => lead.utility === 'GPC')
      .every((lead) => lead.plannedInServiceDate === null && lead.printedDate === null),
  );
});

test('detailed public Georgia Power pages include areas beyond directory summaries', () => {
  const big = leads.find((lead) => lead.name === 'Big Tazewell - Farley 500 kV');
  assert.equal(
    big.sourceUrl,
    'https://www.georgiapower.com/about/grid-reliability/grid-improvements/grid-projects/transmission-projects/big-tazewell-farley.html',
  );
  assert.match(big.region, /Houston County, AL/);
  assert.match(big.region, /Marion/);

  const ashley = leads.find((lead) => lead.name === 'Ashley Park – Wansley 500 kV');
  assert.equal(
    ashley.sourceUrl,
    'https://www.georgiapower.com/about/grid-reliability/grid-improvements/grid-projects/transmission-projects/ashley-park.html',
  );
  assert.match(ashley.region, /Fayette/);
  assert.match(ashley.region, /Fulton/);
  assert.match(ashley.region, /Coweta/);
  assert.match(ashley.region, /Heard/);
});

test('selected Dominion filing updates retain cited public pages and valid exact dates', () => {
  const expected = new Map([
    ['0139 M,N', ['12/31/2026', '2026-12-31', 11]],
    ['06367 D - G', ['12/01/2026', '2026-12-01', 12]],
    ['6359', ['6/1/2027', '2027-06-01', 17]],
    ['6238 H', ['9/7/2027', '2027-09-07', 18]],
    ['6808 L', ['12/31/2027', '2027-12-31', 21]],
  ]);
  for (const lead of leads.filter((item) => item.utility === 'DESC')) {
    assert.deepEqual(
      [lead.printedDate, lead.plannedInServiceDate, lead.sourcePage],
      expected.get(lead.filingProjectId),
    );
    assert.equal(
      lead.sourceUrl,
      'https://www.scrtp.com/assets/pdfs/home/2026-2030-2million-and-above-project-descriptions.pdf',
    );
    const [year, month, day] = lead.plannedInServiceDate.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    assert.deepEqual(
      [date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate()],
      [year, month, day],
    );
  }
});