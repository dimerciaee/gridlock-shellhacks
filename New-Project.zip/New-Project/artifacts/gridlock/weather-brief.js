function textElement(tagName, className, text) {
  const element = document.createElement(tagName);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function metric(label, value, help, testId) {
  const item = textElement('div', 'weather-metric');
  const valueElement = textElement('strong', 'weather-metric-value', value);
  valueElement.dataset.testid = testId;
  item.append(
    textElement('span', 'weather-metric-label', label),
    valueElement,
    textElement('small', 'weather-metric-help', help),
  );
  return item;
}

function renderWeatherSummary(panel, data) {
  const content = textElement('div', 'weather-brief');
  const heading = textElement('div', 'weather-brief-header');
  heading.append(
    textElement('h3', 'weather-brief-title', 'NOAA point forecast'),
    textElement(
      'time',
      'weather-brief-checked',
      `NOAA data · checked ${data.checkedAt.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`,
    ),
  );
  heading.querySelector('time').dateTime = data.checkedAt.toISOString();
  content.append(
    heading,
    textElement('p', 'weather-brief-meta', `Forecast period: ${data.forecastPeriod}`),
  );

  const temperature = data.temperature == null
    ? 'Not available'
    : `${data.temperature}°${data.temperatureUnit || 'F'}`;
  const description = data.shortForecast || 'Forecast description not available.';
  const rainValue = data.rainChance == null ? 'Not available' : `${data.rainChance}%`;
  const rainHelp = data.rainChance == null
    ? 'NOAA did not provide a percentage for this hour.'
    : 'Chance of rain during this forecast hour.';
  const metrics = textElement('div', 'weather-metrics');
  metrics.append(
    metric('Temperature', temperature, 'NOAA hourly point forecast, not an on-site reading.', 'weather-temperature'),
    metric('Wind', data.wind, 'Forecast wind speed at this point.', 'weather-wind'),
    metric('Chance of rain', rainValue, rainHelp, 'weather-rain-chance'),
  );
  content.append(
    metrics,
    textElement('p', 'weather-subnote', `Forecast: ${description}`),
    textElement('p', 'weather-subnote', 'Expected rainfall amount: not provided for this point forecast.'),
  );

  const floodCount = data.floodAlerts.length;
  const floodBox = textElement('div', 'weather-alert-box');
  floodBox.append(
    textElement('strong', '', 'Flood alerts'),
    textElement(
      'p',
      '',
      floodCount
        ? `${floodCount} active flood alert${floodCount === 1 ? '' : 's'} near this point.`
        : 'No active flood alerts found near this point.',
    ),
    textElement(
      'p',
      '',
      floodCount
        ? 'Open the alert on the map for its details.'
        : 'This does not predict flooding or rule it out.',
    ),
  );
  floodBox.querySelector('strong').dataset.testid = 'weather-flood-alerts';

  const alertBox = textElement('div', 'weather-alert-box');
  alertBox.append(
    textElement('strong', '', 'All active weather alerts'),
    textElement(
      'p',
      '',
      data.alertCount
        ? `${data.alertCount} active weather alert${data.alertCount === 1 ? '' : 's'} near this point.`
        : 'No active weather alerts found near this point.',
    ),
    textElement(
      'p',
      '',
      data.mappableCount
        ? `GridLock shows ${data.mappableCount} alert area${data.mappableCount === 1 ? '' : 's'} on the map.`
        : 'NOAA did not supply an alert area to show on the map.',
    ),
  );

  const screen = textElement('div', `weather-screen-box ${data.impact.toLowerCase()}`);
  const screenTitle = textElement('strong', '', `Weather signal: ${data.impact}`);
  screenTitle.dataset.testid = 'weather-impact-screen';
  screen.append(
    screenTitle,
    textElement('p', '', 'Based only on the point data above—not an official NOAA rating or a project-specific hazard assessment.'),
  );

  const technicalDetails = textElement('details', 'weather-technical-details');
  technicalDetails.append(
    textElement('summary', '', 'View Technical Details'),
    textElement('p', 'weather-subnote', `Map center: ${data.point}`),
    screen,
    textElement('p', 'weather-subnote', 'NOAA point data describes conditions near the map center; it is not equipment telemetry or a live on-site reading. An alert near a facility or project does not prove facility impact, flooding, damage, or an outage.'),
  );
  const sourceLink = textElement('a', 'weather-source-link', 'Open weather.gov');
  sourceLink.href = 'https://www.weather.gov/';
  sourceLink.target = '_blank';
  sourceLink.rel = 'noopener noreferrer';
  technicalDetails.append(
    textElement('p', 'weather-subnote', 'Check the official forecast and alert details before making operational decisions.'),
    sourceLink,
  );
  content.append(
    floodBox,
    alertBox,
    technicalDetails,
  );
  panel.replaceChildren(content);
}

function renderWeatherError(panel, error) {
  const state = textElement('div', 'weather-load-error');
  const details = textElement('details', 'weather-error-details');
  details.append(
    textElement('summary', '', 'View Technical Details'),
    textElement('small', '', error.message || 'Request failed.'),
  );
  state.append(
    textElement('strong', '', 'NOAA weather is unavailable right now.'),
    textElement('p', '', 'No current weather summary is shown. Try again later.'),
    details,
  );
  panel.replaceChildren(state);
}

export async function loadWeatherAtPoint(lat, lon, signal) {
  const point = `${Number(lat).toFixed(4)},${Number(lon).toFixed(4)}`;
  const load = async (url) => {
    const response = await fetch(url, {
      headers: { Accept: 'application/geo+json' },
      signal,
    });
    if (!response.ok) throw new Error(`NOAA returned ${response.status}`);
    return response.json();
  };
  const [location, alerts] = await Promise.all([
    load(`https://api.weather.gov/points/${point}`),
    load(`https://api.weather.gov/alerts/active?point=${point}`),
  ]);
  const forecastUrl = location.properties?.forecastHourly;
  if (typeof forecastUrl !== 'string' || !forecastUrl.startsWith('https://api.weather.gov/')) {
    throw new Error('NOAA hourly forecast link unavailable');
  }
  const forecast = await load(forecastUrl);
  const hour = forecast.properties?.periods?.[0];
  const alertFeatures = Array.isArray(alerts.features) ? alerts.features : [];
  const mappableAlerts = alertFeatures.filter((feature) => feature.geometry);
  const floodAlerts = alertFeatures.filter((item) =>
    /flood/i.test(`${item.properties?.event || ''} ${item.properties?.headline || ''}`));
  const wind = hour?.windSpeed || 'Not available';
  const rainChance = hour?.probabilityOfPrecipitation?.value ?? null;
  const severe = alertFeatures.some((item) =>
    ['Extreme', 'Severe'].includes(item.properties?.severity));
  const windMph = Number.parseInt(wind, 10);
  const impact = severe || floodAlerts.length || windMph >= 40
    ? 'High' : alertFeatures.length || windMph >= 25 || rainChance >= 60
      ? 'Medium' : 'Low';
  return {
    point,
    checkedAt: new Date(),
    forecastPeriod: hour?.name || 'Next forecast period',
    temperature: Number.isFinite(hour?.temperature) ? hour.temperature : null,
    temperatureUnit: hour?.temperatureUnit || 'F',
    shortForecast: hour?.shortForecast || 'Not available',
    wind,
    rainChance,
    floodAlerts,
    alerts: alertFeatures,
    mappableAlerts,
    alertCount: alertFeatures.length,
    mappableCount: mappableAlerts.length,
    impact,
  };
}

export function setupWeatherBrief(map, L) {
  const checkbox = document.getElementById('layerWeather');
  const panel = document.getElementById('weatherPanel');
  const alertLayer = L.geoJSON(null, {
    style: { color: '#b91c1c', weight: 2, fillColor: '#ef4444', fillOpacity: 0.2 },
    onEachFeature(feature, layer) {
      const popup = document.createElement('span');
      popup.textContent = `NOAA active alert: ${feature.properties?.event || 'Weather alert'}. Verify at weather.gov.`;
      layer.bindPopup(popup);
    },
  });
  let controller;
  let timer;
  let polling;

  async function refresh() {
    controller?.abort();
    controller = new AbortController();
    alertLayer.clearLayers();
    map.removeLayer(alertLayer);
    if (!checkbox.checked) {
      panel.textContent = 'Turn on this layer to see NOAA conditions and active alerts near the map center. GridLock’s storm path is a simulation, not a weather forecast.';
      return;
    }
    panel.replaceChildren(textElement('p', 'weather-loading', 'Loading NOAA weather and active alerts for the map center…'));
    const { lat, lng } = map.getCenter();
    try {
      const weather = await loadWeatherAtPoint(lat, lng, controller.signal);
      if (controller.signal.aborted) return;
      if (weather.mappableAlerts.length) {
        alertLayer.addData({ type: 'FeatureCollection', features: weather.mappableAlerts });
        alertLayer.addTo(map);
      }
      renderWeatherSummary(panel, weather);
    } catch (error) {
      if (error.name === 'AbortError') return;
      renderWeatherError(panel, error);
    }
  }
  function schedule() {
    window.clearTimeout(timer);
    timer = window.setTimeout(refresh, 600);
  }
  checkbox.addEventListener('change', () => {
    window.clearInterval(polling);
    if (checkbox.checked) polling = window.setInterval(refresh, 5 * 60 * 1000);
    schedule();
  });
  map.on('moveend', () => { if (checkbox.checked) schedule(); });
}