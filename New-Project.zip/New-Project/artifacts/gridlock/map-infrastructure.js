const SERVICES = {
  lines: 'https://services.arcgis.com/HQ0xoN0EzDPBOEci/ArcGIS/rest/services/Electric_Power_Transmission_Lines/FeatureServer/0/query',
};

export function setupInfrastructureLayers(map, L) {
  const lineLayer = L.geoJSON(null, {
    style: { color: '#0891b2', weight: 2, opacity: 0.8 },
    onEachFeature(feature, layer) {
      const popup = document.createElement('span');
      popup.textContent = `Public HIFLD existing transmission line · ${feature.properties?.OWNER || 'owner not listed'}. Not a project route.`;
      layer.bindPopup(popup);
    },
  });
  const substationLayer = L.vectorGrid?.protobuf(
    'https://openinframap.org/tiles/{z}/{x}/{y}.pbf',
    {
      maxNativeZoom: 17,
      interactive: true,
      attribution: '© OpenStreetMap contributors · OpenInfraMap',
      vectorTileLayerStyles: {
        power_substation: { color: '#f59e0b', weight: 2, fill: true, fillColor: '#f59e0b', fillOpacity: 0.18 },
        power_substation_point: { radius: 5, color: '#fff', weight: 1, fill: true,
          fillColor: '#f59e0b', fillOpacity: 0.95 },
      },
    },
  );
  substationLayer?.on('click', (event) => {
    const name = event.layer?.properties?.name || 'Unnamed existing substation';
    const popup = document.createElement('span');
    popup.textContent = `${name} · Open Infrastructure Map / OpenStreetMap existing asset. Project association unverified.`;
    L.popup().setLatLng(event.latlng).setContent(popup).openOn(map);
  });
  const controls = {
    lines: document.getElementById('layerLines'),
    substations: document.getElementById('layerSubstations'),
  };
  const status = document.getElementById('infrastructureStatus');
  let timer;
  let controller;

  async function refresh() {
    controller?.abort();
    controller = new AbortController();
    const active = Object.entries(controls).filter(([, checkbox]) => checkbox.checked);
    map.removeLayer(lineLayer);
    if (substationLayer) map.removeLayer(substationLayer);
    lineLayer.clearLayers();
    if (!active.length) {
      status.textContent = 'Enable an existing-infrastructure layer and zoom in to load public map features.';
      return;
    }
    if (map.getZoom() < 9) {
      status.textContent = 'Zoom to level 9 or closer to load existing infrastructure.';
      return;
    }
    if (controls.substations.checked && substationLayer) substationLayer.addTo(map);
    if (controls.substations.checked && !substationLayer) {
      status.textContent = 'Open Infrastructure Map substation layer could not initialize.';
      if (!controls.lines.checked) return;
    }
    if (!controls.lines.checked) {
      status.textContent = 'Open Infrastructure Map substations in view; zoom in and click assets for names. Coverage may be incomplete.';
      return;
    }
    const bbox = map.getBounds().toBBoxString();
    status.textContent = 'Loading public HIFLD lines; Open Infrastructure Map substations are visible when selected…';
    try {
      const params = new URLSearchParams({
        f: 'geojson', where: '1=1', geometry: bbox,
        geometryType: 'esriGeometryEnvelope', spatialRel: 'esriSpatialRelIntersects',
        inSR: '4326', outSR: '4326', outFields: '*', resultRecordCount: '250',
      });
      const response = await fetch(`${SERVICES.lines}?${params}`, { signal: controller.signal });
      if (!response.ok) throw new Error(`HIFLD lines service returned ${response.status}`);
      const data = await response.json();
      if (data.type !== 'FeatureCollection' || !Array.isArray(data.features)) {
        throw new Error('HIFLD lines service returned invalid map data');
      }
      if (controller.signal.aborted) return;
      lineLayer.addData(data);
      lineLayer.addTo(map);
      status.textContent = `${data.features.length}${data.features.length === 250 ? '+' : ''} HIFLD lines in view` +
        (controls.substations.checked ? ' · Open Infrastructure Map substations; click for names' : '') +
        '. Public coverage may be incomplete; zoom in for detail.';
    } catch (error) {
      if (error.name === 'AbortError') return;
      console.warn('Public infrastructure data unavailable:', error);
      status.textContent = 'Infrastructure data unavailable. Open Infrastructure Map linked below to inspect the area.';
    }
  }
  function schedule() {
    window.clearTimeout(timer);
    timer = window.setTimeout(refresh, 350);
  }
  map.on('moveend', schedule);
  Object.values(controls).forEach((checkbox) => checkbox.addEventListener('change', schedule));
}