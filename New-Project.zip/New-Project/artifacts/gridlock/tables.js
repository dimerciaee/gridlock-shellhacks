import {
  formatDistanceMiles,
  getProjectCenter,
  OVERLAP_THRESHOLD_MILES,
} from './data-utils.js';
import { DOCUMENTED_BUDGETS, budgetForProject } from './resilience-priority.js';

const projectHeaders = [
  'Utility',
  'Project',
  'Sample planning years',
  'Center coordinate (lat, lon)',
  'Center method',
  'Exact in-service date',
  'Location confidence',
  'Filing source / page',
];

const overlapHeaders = [
  'Utility A project',
  'Utility B project',
  'Distance (mi)',
  'Distance (km)',
  'Sample planning windows overlap',
  'In-service date gap (days)',
  'Nearby listed sites',
  'Location confidence',
];

const sourceHeaders = [
  'Listing #',
  'Project',
  'Filing project ID',
  'Supplied budget snapshot',
  'Status as printed',
  'Planned in-service date as printed',
  'Single date (ISO)',
  'Location status',
  'Source',
];

const publicLeadHeaders = [
  'Utility',
  'Public project',
  'Filing project ID',
  'Reported area (may be partial)',
  'Published type',
  'Planned in-service date as printed',
  'Single date (ISO)',
  'Location status',
  'Official source URL / page',
];

const submittedHeaders = [
  'Workbook pair ID',
  'Dominion project ID',
  'Dominion project',
  'Georgia Power project ID',
  'Georgia Power project',
  'Workbook distance (mi, unverified)',
  'Workbook date gap (days, unverified)',
  'Date review',
];

const verifiedHeaders = [
  'Dominion project / filing ID',
  'Georgia Power project',
  'Located endpoints and map evidence',
  'Distance (mi)',
  'Planned in-service dates',
  'Gap (days)',
  'Filing sources / pages',
];

function verifiedRows(pairs) {
  return pairs.map(({ d, g, dCenter, gCenter, distMiles, inServiceDateGapDays }) => [
    `${d.name} / ${d.filingProjectId}`,
    g.name,
    `${d.subpoints[0].name}: ${dCenter.lat.toFixed(5)}, ${dCenter.lon.toFixed(5)} (${d.mapEvidence}); ${g.subpoints[0].name}: ${gCenter.lat.toFixed(5)}, ${gCenter.lon.toFixed(5)} (${g.mapEvidence})`,
    formatDistanceMiles(distMiles),
    `${d.inServiceDate} / ${g.inServiceDate}`,
    inServiceDateGapDays === null ? 'Unresolved' : String(inServiceDateGapDays),
    `${d.sourceDocument}, page ${d.sourcePage}: ${d.sourceUrl}; ${g.sourceDocument}, PDF page ${g.sourcePage}: ${g.sourceUrl}`,
  ]);
}

export function renderVerifiedPairs(pairs, errorMessage = null) {
  document.getElementById('sourceOverlapStatus').textContent = errorMessage
    ? 'Source-based overlaps: Evidence unavailable'
    : `Sourced point pairs: ${pairs.length} under ${OVERLAP_THRESHOLD_MILES} mi (not confirmed route overlap)`;
  document.getElementById('verifiedSummary').textContent = errorMessage ||
    `${pairs.length} independently located endpoint pair${pairs.length === 1 ? '' : 's'}; remaining workbook pairs are unverified.`;
  renderRows(document.getElementById('verifiedTableBody'), verifiedRows(pairs),
    verifiedHeaders.length, errorMessage || 'No sourced point pairs under 25 miles.');
  document.getElementById('exportVerifiedCsv').disabled = Boolean(errorMessage) || pairs.length === 0;
}

const sourceCitation =
  'Pasted Dominion Energy South Carolina Planned Transmission Projects $2M and above Total / 5 Year Budget; original PDF page not supplied';

function sourceLabel(project) {
  if (!project.sourceDocument) return 'Not provided';
  return project.sourcePage
    ? `${project.sourceDocument}, page ${project.sourcePage}`
    : project.sourceDocument;
}

function confidenceLabel(project) {
  return project.locationConfidence === 'verified' && project.sourceDocument
    ? 'Verified with cited filing'
    : 'Unverified sample';
}

function planningWindowLabel(project) {
  return Number.isFinite(project.start) && Number.isFinite(project.end)
    ? `${project.start}–${project.end} (sample)`
    : 'Not supplied';
}

function projectRows(projects, utilityLabel) {
  return projects.map((project) => {
    const center = getProjectCenter(project);
    return [
      utilityLabel(project.utility),
      project.name,
      planningWindowLabel(project),
      center ? `${center.lat.toFixed(5)}, ${center.lon.toFixed(5)}` : 'Not located',
      center?.method || 'Not located',
      project.inServiceDate || 'Not supplied',
      confidenceLabel(project),
      sourceLabel(project),
    ];
  });
}

function overlapRows(overlaps, utilityLabel) {
  return overlaps.map((overlap) => [
    `${utilityLabel(overlap.d.utility)}: ${overlap.d.name}`,
    `${utilityLabel(overlap.g.utility)}: ${overlap.g.name}`,
    formatDistanceMiles(overlap.distMiles),
    overlap.dist.toFixed(1),
    overlap.timeOverlap === null
      ? 'Not supplied'
      : overlap.timeOverlap
        ? 'Yes (sample years)'
        : 'No (sample years)',
    overlap.inServiceDateGapDays === null
      ? 'Not available — exact dates needed'
      : String(overlap.inServiceDateGapDays),
    String(overlap.humanitarianScore),
    `${confidenceLabel(overlap.d)} / ${confidenceLabel(overlap.g)}`,
  ]);
}

function sourceRows(sourceProjects) {
  return sourceProjects.map((project) => [
    String(project.listingNumber),
    project.name,
    project.projectId,
    (() => {
      const budget = budgetForProject(project);
      return budget
        ? `${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(budget.amount)}${budget.rounded ? ' (rounded)' : ''}`
        : 'No supplied snapshot';
    })(),
    project.status,
    project.printedDate,
    project.plannedInServiceDate || 'Not a single date; see printed text',
    'Not geolocated',
    sourceCitation,
  ]);
}

function publicLeadRows(publicLeads) {
  return publicLeads.map((project) => [
    project.utility === 'DESC'
      ? 'Dominion Energy South Carolina (DESC)'
      : 'Georgia Power (GPC)',
    project.name,
    project.filingProjectId || 'Not supplied',
    project.region || 'Named facilities in filing; no published center',
    project.projectType || 'Not classified in filing',
    project.printedDate || 'Not published as an exact date',
    project.plannedInServiceDate || 'Not supplied',
    project.utility === 'DESC'
      ? 'Named facilities; project center not verified'
      : 'Public region/page; project center not verified',
    project.sourcePage
      ? `${project.sourceUrl}#page=${project.sourcePage}`
      : project.sourceUrl,
  ]);
}

function submittedRows(candidates) {
  return candidates.map((candidate) => [
    candidate.id,
    candidate.descId,
    candidate.descName,
    candidate.gpcId,
    candidate.gpcName,
    candidate.distanceMiles.toFixed(2),
    String(candidate.dateGapDays),
    candidate.descId === 'DESC_3'
      ? 'Dominion planned date differs in newer public filing; gap outdated'
      : 'Georgia Power planned date not independently confirmed',
  ]);
}

function renderRows(body, rows, columnCount, emptyMessage) {
  body.replaceChildren();
  if (rows.length === 0) {
    const tr = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = columnCount;
    cell.textContent = emptyMessage;
    tr.appendChild(cell);
    body.appendChild(tr);
    return;
  }

  rows.forEach((row) => {
    const tr = document.createElement('tr');
    row.forEach((value) => {
      const cell = document.createElement('td');
      cell.textContent = value;
      tr.appendChild(cell);
    });
    body.appendChild(tr);
  });
}

export function renderTables({
  projects,
  overlaps,
  selectedUtilityA,
  selectedUtilityB,
  utilityLabel,
}) {
  document.getElementById('tablePairSummary').textContent =
    selectedUtilityA && selectedUtilityB
      ? `${utilityLabel(selectedUtilityA)} + ${utilityLabel(selectedUtilityB)} · ` +
        `${overlaps.length} pair${overlaps.length === 1 ? '' : 's'} under ${OVERLAP_THRESHOLD_MILES} mi. ` +
        'Demo coordinates are unverified.'
      : 'Demo map data unavailable; the source inventory remains separate.';

  renderRows(
    document.getElementById('projectsTableBody'),
    projectRows(projects, utilityLabel),
    projectHeaders.length,
    'No projects have been loaded.',
  );
  renderRows(
    document.getElementById('overlapsTableBody'),
    overlapRows(overlaps, utilityLabel),
    overlapHeaders.length,
    'No cross-utility pairs are under 25 miles for the selected utilities.',
  );
}

export function renderSourceInventory(sourceProjects, errorMessage = null) {
  const singleDateCount = sourceProjects.filter(
    (project) => project.plannedInServiceDate,
  ).length;
  document.getElementById('sourceInventorySummary').textContent =
    errorMessage ||
    `${sourceProjects.length} Dominion source projects · ${singleDateCount} single planned dates · ${DOCUMENTED_BUDGETS.length} supplied budget snapshots totaling ${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(DOCUMENTED_BUDGETS.reduce((sum, entry) => sum + entry.amount, 0))} · partial snapshot subtotal, not the full portfolio · no verified coordinates.`;
  renderRows(
    document.getElementById('sourceTableBody'),
    sourceRows(sourceProjects),
    sourceHeaders.length,
    errorMessage || 'No source projects were loaded.',
  );
  document.getElementById('exportSourceCsv').disabled =
    Boolean(errorMessage) || sourceProjects.length === 0;
}

export function renderPublicLeads(publicLeads, errorMessage = null) {
  const gpcCount = publicLeads.filter((project) => project.utility === 'GPC').length;
  const descCount = publicLeads.length - gpcCount;
  document.getElementById('publicLeadsSummary').textContent =
    errorMessage ||
    `${gpcCount} Georgia Power public projects · ${descCount} Dominion Energy South Carolina public filing updates · no verified project centers.`;
  document.getElementById('publicResearchStatus').textContent = errorMessage
    ? 'Public project review unavailable.'
    : `Public project review: ${publicLeads.length} leads; no sourced overlap claim without verified project centers.`;
  const body = document.getElementById('publicLeadsTableBody');
  renderRows(
    body,
    publicLeadRows(publicLeads),
    publicLeadHeaders.length,
    errorMessage || 'No public project leads were loaded.',
  );
  publicLeads.forEach((project, index) => {
    const cell = body.rows[index].cells[publicLeadHeaders.length - 1];
    const link = document.createElement('a');
    link.href = project.sourcePage
      ? `${project.sourceUrl}#page=${project.sourcePage}`
      : project.sourceUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = project.sourcePage
      ? `Public PDF, page ${project.sourcePage}`
      : 'Public project page';
    cell.replaceChildren(link);
  });
  document.getElementById('exportPublicLeadsCsv').disabled =
    Boolean(errorMessage) || publicLeads.length === 0;
}

export function renderSubmittedCandidates(candidates, errorMessage = null) {
  document.getElementById('submittedSummary').textContent =
    errorMessage ||
    `${candidates.length} submitted pairs · arithmetic checked against workbook inputs · project-location and current-date evidence still needed.`;
  document.getElementById('submittedCandidateStatus').textContent = errorMessage
    ? 'Submitted workbook: Candidate review unavailable'
    : `Submitted workbook: ${candidates.length} unverified candidates`;
  renderRows(
    document.getElementById('submittedTableBody'),
    submittedRows(candidates),
    submittedHeaders.length,
    errorMessage || 'No submitted candidate pairs were loaded.',
  );
  document.getElementById('exportSubmittedCsv').disabled =
    Boolean(errorMessage) || candidates.length === 0;
}

function csvCell(value) {
  let text = String(value ?? '');
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

function downloadCsv(headers, rows, fileName) {
  const csv = [headers, ...rows]
    .map((row) => row.map(csvCell).join(','))
    .join('\r\n');
  const url = URL.createObjectURL(
    new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' }),
  );
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function setupTablesDialog(getCurrentData) {
  const dialog = document.getElementById('tablesDialog');
  const tabs = [...dialog.querySelectorAll('[data-table-tab]')];
  const panels = {
    verified: document.getElementById('verifiedPanel'),
    projects: document.getElementById('projectsPanel'),
    overlaps: document.getElementById('overlapsPanel'),
    submitted: document.getElementById('submittedPanel'),
    publicLeads: document.getElementById('publicLeadsPanel'),
    source: document.getElementById('sourcePanel'),
    methodology: document.getElementById('methodologyPanel'),
  };

  function activateTab(name) {
    document.getElementById('tablePairSummary').hidden =
      name !== 'projects' && name !== 'overlaps';
    tabs.forEach((tab) => {
      const active = tab.dataset.tableTab === name;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
      panels[tab.dataset.tableTab].hidden = !active;
    });
  }

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activateTab(tab.dataset.tableTab));
    tab.addEventListener('keydown', (event) => {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
      event.preventDefault();
      const delta = event.key === 'ArrowRight' ? 1 : -1;
      const next = tabs[(index + delta + tabs.length) % tabs.length];
      activateTab(next.dataset.tableTab);
      next.focus();
    });
  });

  document.getElementById('tablesBtn').addEventListener('click', () => {
    activateTab('verified');
    dialog.showModal();
  });
  document.getElementById('closeTablesBtn').addEventListener('click', () => {
    dialog.close();
  });
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });

  document.getElementById('exportProjectsCsv').addEventListener('click', () => {
    const { projects, utilityLabel } = getCurrentData();
    downloadCsv(
      projectHeaders,
      projectRows(projects, utilityLabel),
      'GridLock_Projects.csv',
    );
  });
  document.getElementById('exportOverlapsCsv').addEventListener('click', () => {
    const { overlaps, utilityLabel } = getCurrentData();
    downloadCsv(
      overlapHeaders,
      overlapRows(overlaps, utilityLabel),
      'GridLock_Overlap_Candidates.csv',
    );
  });
  document.getElementById('exportSourceCsv').addEventListener('click', () => {
    const { sourceProjects } = getCurrentData();
    downloadCsv(
      sourceHeaders,
      sourceRows(sourceProjects),
      'GridLock_DESC_Source_Inventory.csv',
    );
  });
  document.getElementById('exportPublicLeadsCsv').addEventListener('click', () => {
    const { publicLeads } = getCurrentData();
    downloadCsv(
      publicLeadHeaders,
      publicLeadRows(publicLeads),
      'GridLock_Public_Project_Leads.csv',
    );
  });
  document.getElementById('exportSubmittedCsv').addEventListener('click', () => {
    const { submittedCandidates } = getCurrentData();
    downloadCsv(
      submittedHeaders,
      submittedRows(submittedCandidates),
      'GridLock_Submitted_Candidate_Review.csv',
    );
  });
  document.getElementById('exportVerifiedCsv').addEventListener('click', () => {
    const { verifiedPairs } = getCurrentData();
    downloadCsv(verifiedHeaders, verifiedRows(verifiedPairs), 'GridLock_Sourced_Point_Pairs.csv');
  });
  document.getElementById('copyOverpassQueryBtn').addEventListener('click', async () => {
    const status = document.getElementById('queryCopyStatus');
    try {
      await navigator.clipboard.writeText(
        document.getElementById('overpassQuery').textContent.trim(),
      );
      status.textContent = 'Query copied.';
    } catch {
      status.textContent = 'Copy unavailable. Select and copy the query above.';
    }
  });
}