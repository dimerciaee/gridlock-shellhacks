import assert from 'node:assert/strict';
import test from 'node:test';
import { evidenceNarrative, getExecutiveNarrative } from './executive-narrative.js';

const pair = {
  d: { name: 'Jasper – Okatie', inServiceDate: '2026-12-01' },
  g: { name: 'McIntosh – Purrysburg', inServiceDate: '2026-06-01' },
  distMiles: 3.05,
  inServiceDateGapDays: 183,
};

test('evidence draft states point proximity and missing shared work', () => {
  const text = evidenceNarrative(pair);
  assert.match(text, /independently located named endpoints/);
  assert.match(text, /3\.05 miles/);
  assert.match(text, /183 days apart/);
  assert.match(text, /have not been established/);
});

test('AI errors retain a clearly labeled evidence-based draft', async () => {
  const result = await getExecutiveNarrative(pair, {
    fetchImpl: async () => ({ ok: false, status: 429 }),
  });
  assert.match(result.narrativeSource, /AI unavailable/);
  assert.equal(result.narrative, evidenceNarrative(pair));
});

test('successful AI response is labeled as a draft, not verified analysis', async () => {
  const result = await getExecutiveNarrative(pair, {
    fetchImpl: async () => ({ ok: true, json: async () => ({ explanation: ' Review project scope. ' }) }),
  });
  assert.equal(result.narrative, 'Review project scope.');
  assert.match(result.narrativeSource, /verify before circulation/);
});