export const SAVINGS_ASSUMPTIONS = Object.freeze({
  crews: 350_000,
  equipment: 700_000,
  surveying: 120_000,
  permitting: 80_000,
});

export const SCHEDULE_SAVINGS_SCENARIO = '30–90 days';

export function scenarioSavings(assumptions = SAVINGS_ASSUMPTIONS) {
  return Object.values(assumptions).reduce((sum, value) => sum + value, 0);
}

export const COORDINATION_SCORE_WEIGHTS = Object.freeze({
  distance: 40,
  time: 30,
  cost: 30,
  infrastructure: 10,
});

export const COORDINATION_POTENTIAL_WEIGHTS = Object.freeze({
  geographicProximity: 30,
  timelineAlignment: 20,
  projectScale: 15,
  sharedResourceOpportunity: 15,
  regionalResilienceImpact: 20,
});

export const COORDINATION_POTENTIAL_DRIVER_LABELS = Object.freeze({
  geographicProximity: 'Geographic proximity',
  timelineAlignment: 'Published in-service dates (not a construction schedule)',
  projectScale: 'Project scale',
  sharedResourceOpportunity: 'Shared-resource opportunity',
  regionalResilienceImpact: 'Regional resilience impact',
});

export const COORDINATION_POTENTIAL_GRADE_BANDS = Object.freeze([
  { grade: 'A+', label: 'Exceptional', min: 90, max: 100 },
  { grade: 'A', label: 'High', min: 80, max: 89 },
  { grade: 'B', label: 'Moderate', min: 70, max: 79 },
  { grade: 'C', label: 'Low', min: 60, max: 69 },
  { grade: 'D', label: 'Minimal', min: 0, max: 59 },
]);

export function gradeCoordinationPotentialScore(score) {
  if (!Number.isFinite(score) || score < 0 || score > 100) return null;
  const rounded = Math.round(score);
  const band = COORDINATION_POTENTIAL_GRADE_BANDS.find(
    ({ min, max }) => rounded >= min && rounded <= max,
  );
  return band ? { grade: band.grade, label: band.label } : null;
}

export function getCoordinationPotentialScore({
  distanceMiles,
  timeGapDays = null,
  projectCosts = null,
  sharedResourceCount = null,
  regionalResiliencePoints = null,
}) {
  const distance = Number.isFinite(distanceMiles) && distanceMiles >= 0
    ? distanceMiles > 25 ? 0 :
      distanceMiles < 5 ? COORDINATION_POTENTIAL_WEIGHTS.geographicProximity :
        distanceMiles < 10 ? 23 : 11
    : null;
  const dateGap = Number.isFinite(timeGapDays) && timeGapDays >= 0
    ? timeGapDays < 180 ? COORDINATION_POTENTIAL_WEIGHTS.timelineAlignment :
      timeGapDays < 365 ? 13 : 0
    : null;
  const costsAreReviewed = Array.isArray(projectCosts) &&
    projectCosts.length === 2 &&
    projectCosts.every((amount) => Number.isFinite(amount) && amount >= 0);
  const totalCost = costsAreReviewed
    ? projectCosts.reduce((total, amount) => total + amount, 0)
    : null;
  const projectScale = totalCost === null
    ? null
    : totalCost >= 40_000_000 ? COORDINATION_POTENTIAL_WEIGHTS.projectScale :
      totalCost >= 20_000_000 ? 10 :
        totalCost > 0 ? 5 : 0;
  const sharedResources = Number.isInteger(sharedResourceCount) && sharedResourceCount >= 0
    ? sharedResourceCount >= 3 ? COORDINATION_POTENTIAL_WEIGHTS.sharedResourceOpportunity :
      sharedResourceCount > 0 ? 10 : 0
    : null;
  const resilience = Number.isFinite(regionalResiliencePoints) &&
    regionalResiliencePoints >= 0 &&
    regionalResiliencePoints <= COORDINATION_POTENTIAL_WEIGHTS.regionalResilienceImpact
    ? Math.round(regionalResiliencePoints)
    : null;
  const parts = {
    geographicProximity: distance,
    timelineAlignment: dateGap,
    projectScale,
    sharedResourceOpportunity: sharedResources,
    regionalResilienceImpact: resilience,
  };
  const omittedDrivers = Object.entries(parts)
    .filter(([, value]) => value === null)
    .map(([name]) => name);
  const knownTotal = Object.values(parts).reduce((sum, value) => sum + (value ?? 0), 0);
  const complete = omittedDrivers.length === 0;
  const assessedMax = Object.entries(parts).reduce(
    (sum, [name, value]) => sum + (value === null ? 0 : COORDINATION_POTENTIAL_WEIGHTS[name]),
    0,
  );
  const normalizedScore = assessedMax > 0
    ? Math.round((knownTotal / assessedMax) * 100)
    : null;
  return {
    parts,
    knownTotal,
    assessedMax,
    normalizedScore,
    maxPossible: 100,
    complete,
    omittedDrivers,
    grade: normalizedScore === null ? null : gradeCoordinationPotentialScore(normalizedScore),
  };
}

export function getCoordinationScore({
  distanceMiles,
  timeGapDays = null,
  projectCost = null,
  infrastructureCount = null,
}) {
  const distance = Number.isFinite(distanceMiles)
    ? distanceMiles < 5 ? COORDINATION_SCORE_WEIGHTS.distance :
      distanceMiles < 10 ? COORDINATION_SCORE_WEIGHTS.distance * 0.75 :
        COORDINATION_SCORE_WEIGHTS.distance * 0.375
    : null;
  const time = Number.isFinite(timeGapDays)
    ? timeGapDays < 180 ? COORDINATION_SCORE_WEIGHTS.time :
      timeGapDays < 365 ? COORDINATION_SCORE_WEIGHTS.time * (2 / 3) : 0
    : null;
  const cost = Number.isFinite(projectCost)
    ? projectCost > 20_000_000 ? COORDINATION_SCORE_WEIGHTS.cost : 0
    : null;
  // Only count assets explicitly reviewed for this pair. Nearby map features
  // alone are not evidence of shared infrastructure.
  const infrastructure = Number.isFinite(infrastructureCount)
    ? infrastructureCount > 0 ? COORDINATION_SCORE_WEIGHTS.infrastructure : 0
    : null;
  const parts = { distance, time, cost, infrastructure };
  const missing = Object.entries(parts)
    .filter(([, value]) => value === null)
    .map(([name]) => name);
  return {
    parts,
    knownTotal: Object.values(parts).reduce((sum, value) => sum + (value ?? 0), 0),
    complete: missing.length === 0,
    missing,
  };
}

// Executive briefing score uses only independently located endpoint separation
// and exact in-service date gap. It is distinct from the incomplete
// multi-factor screening score shown on the map.
export function calculateCoordinationScore(distanceMiles, timeGapDays) {
  if (!Number.isFinite(distanceMiles) || distanceMiles < 0) return null;
  if (distanceMiles > 25) return 0;
  if (!Number.isFinite(timeGapDays) || timeGapDays < 0) return null;
  const score = 100 - distanceMiles * 2 - Math.min(timeGapDays / 20, 25);
  return Math.max(Math.min(Math.round(score), 100), 0);
}

export const SNAPSHOT_SAVINGS_RATES = Object.freeze([
  { maxDistanceExclusive: 5, label: 'Under 5 miles', conservative: 0.02, expected: 0.04, maximum: 0.06 },
  { maxDistanceExclusive: 10, label: '5–under 10 miles', conservative: 0.015, expected: 0.03, maximum: 0.05 },
  { maxDistanceInclusive: 25, label: '10–25 miles', conservative: 0.01, expected: 0.02, maximum: 0.04 },
]);

export const GEORGIA_POWER_COST_BENCHMARKS = Object.freeze([
  { category: '230kV Line Construction', minimum: 20_000_000, maximum: 40_000_000 },
  { category: '230kV Reactor Project', minimum: 10_000_000, maximum: 20_000_000 },
  { category: '115kV Rebuild', minimum: 5_000_000, maximum: 15_000_000 },
  { category: 'Substation Expansion', minimum: 10_000_000, maximum: 40_000_000 },
]);

export const POTENTIAL_SAVINGS_SOURCE_EXAMPLES = Object.freeze([
  { source: 'Shared Equipment', amount: 800_000 },
  { source: 'Shared Contractors', amount: 600_000 },
  { source: 'Shared Staging Areas', amount: 300_000 },
  { source: 'Shared Permitting', amount: 200_000 },
  { source: 'Environmental Reviews', amount: null },
]);

export function estimateGeorgiaPowerInvestment(project) {
  if (!project) return null;
  const utility = `${project.utility || ''} ${project.utilityName || ''}`.toLowerCase();
  if (!/\bgpc\b|georgia\s+power/.test(utility)) return null;

  const evidence = `${project.name || ''} ${project.projectType || ''}`.toLowerCase();
  let category = null;
  if (/230\s*k?v/.test(evidence) && /\breactors?\b/.test(evidence)) {
    category = '230kV Reactor Project';
  } else if (/115\s*k?v/.test(evidence) && /\brebuild\b/.test(evidence)) {
    category = '115kV Rebuild';
  } else if (
    /230\s*k?v/.test(evidence) &&
    /\b(line|transmission|construct|construction)\b/.test(evidence)
  ) {
    category = '230kV Line Construction';
  } else if (
    /\b(substation|sub)\b/.test(evidence) &&
    /\b(expand|expansion|upgrade|construct|construction|autobank|transformer)\b/.test(evidence)
  ) {
    category = 'Substation Expansion';
  }
  const benchmark = GEORGIA_POWER_COST_BENCHMARKS.find((entry) => entry.category === category);
  return benchmark
    ? {
      ...benchmark,
      confidence: 'Medium',
      costBasis: 'Transmission project benchmark',
    }
    : null;
}

// Budget snapshots make this a transparent planning scenario, not a verified
// savings estimate. Both project amounts and a qualifying point distance are
// required; never infer a missing project budget.
export function calculateSnapshotSavings(distanceMiles, projectBudgets) {
  if (
    !Number.isFinite(distanceMiles) ||
    distanceMiles < 0 ||
    distanceMiles > 25 ||
    !Array.isArray(projectBudgets) ||
    projectBudgets.length !== 2 ||
    !projectBudgets.every((amount) => Number.isFinite(amount) && amount >= 0)
  ) {
    return null;
  }
  const tier = SNAPSHOT_SAVINGS_RATES.find(({ maxDistanceExclusive, maxDistanceInclusive }) =>
    maxDistanceExclusive === undefined
      ? distanceMiles <= maxDistanceInclusive
      : distanceMiles < maxDistanceExclusive);
  if (!tier) return null;
  const combinedInvestment = projectBudgets.reduce((sum, amount) => sum + amount, 0);
  return {
    combinedInvestment,
    distanceTier: tier.label,
    rates: {
      conservative: tier.conservative,
      expected: tier.expected,
      maximum: tier.maximum,
    },
    savings: {
      conservative: Math.round(combinedInvestment * tier.conservative),
      expected: Math.round(combinedInvestment * tier.expected),
      maximum: Math.round(combinedInvestment * tier.maximum),
    },
  };
}

export function calculateBudgetRangeSavings(distanceMiles, projectBudgetRanges) {
  if (
    !Number.isFinite(distanceMiles) ||
    distanceMiles < 0 ||
    distanceMiles > 25 ||
    !Array.isArray(projectBudgetRanges) ||
    projectBudgetRanges.length !== 2 ||
    !projectBudgetRanges.every((range) =>
      Number.isFinite(range?.minimum) &&
      Number.isFinite(range?.maximum) &&
      range.minimum >= 0 &&
      range.maximum >= range.minimum)
  ) {
    return null;
  }
  const tier = SNAPSHOT_SAVINGS_RATES.find(({ maxDistanceExclusive, maxDistanceInclusive }) =>
    maxDistanceExclusive === undefined
      ? distanceMiles <= maxDistanceInclusive
      : distanceMiles < maxDistanceExclusive);
  if (!tier) return null;
  const combinedInvestmentRange = {
    minimum: projectBudgetRanges.reduce((sum, range) => sum + range.minimum, 0),
    maximum: projectBudgetRanges.reduce((sum, range) => sum + range.maximum, 0),
  };
  const rates = {
    conservative: tier.conservative,
    expected: tier.expected,
    maximum: tier.maximum,
  };
  const savings = Object.fromEntries(Object.entries(rates).map(([scenario, rate]) => [
    scenario,
    {
      minimum: Math.round(combinedInvestmentRange.minimum * rate),
      maximum: Math.round(combinedInvestmentRange.maximum * rate),
    },
  ]));
  return {
    combinedInvestmentRange,
    distanceTier: tier.label,
    rates,
    savings,
  };
}

export function savingsText(assumptions = SAVINGS_ASSUMPTIONS) {
  const money = (value) => `$${value.toLocaleString('en-US')}`;
  return [
    'Example figures only — not an estimate for these projects:',
    `Crews: ${money(assumptions.crews)}`,
    `Equipment: ${money(assumptions.equipment)}`,
    `Surveying: ${money(assumptions.surveying)}`,
    `Permitting: ${money(assumptions.permitting)}`,
    `Potential scenario total: ${money(scenarioSavings(assumptions))}`,
    'No source-backed cost baseline or shared-work scope has been supplied.',
  ].join('\n');
}