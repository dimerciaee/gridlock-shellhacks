import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import { buildSourcedOverlapRows, getInServiceDateGapDays } from './data-utils.js';

const projects = JSON.parse(readFileSync(new URL('./public/verified-projects.json', import.meta.url), 'utf8'));

test('only independently located named endpoints produce a sourced point pair', () => {
  const pairs = buildSourcedOverlapRows(projects);
  assert.equal(pairs.length, 1);
  assert.equal(pairs[0].d.filingProjectId, '06367 D - G');
  assert.equal(pairs[0].g.name, 'SAV: MCINTOSH - PURRYSBURG 230KV REACTORS');
  assert(pairs[0].distMiles > 3 && pairs[0].distMiles < 3.1);
  assert.equal(pairs[0].inServiceDateGapDays, 183);
  assert(projects.every((p) => p.sourcePage && p.mapEvidence && p.subpoints.length === 1));
  assert.equal(buildSourcedOverlapRows([...projects, {
    ...projects[0], utility: 'DESC', mapEvidence: null,
  }]).length, 1);
});

test('phased or missing dates never yield a sourced date gap', () => {
  assert.equal(getInServiceDateGapDays(projects[0], { inServiceDate: '2026-06-01 / 2027-06-01' }), null);
  assert.equal(getInServiceDateGapDays(projects[0], { inServiceDate: null }), null);
});