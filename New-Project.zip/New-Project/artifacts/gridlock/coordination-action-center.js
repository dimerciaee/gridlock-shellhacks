import './gridlock-planning.css';
import {
  COORDINATION_POTENTIAL_DRIVER_LABELS,
  COORDINATION_POTENTIAL_GRADE_BANDS,
  COORDINATION_POTENTIAL_WEIGHTS,
} from './opportunity-model.js';

const STATUS_OPTIONS = [
  ['opportunity-identified', 'Opportunity Identified'],
  ['contact-initiated', 'Contact Initiated'],
  ['joint-review', 'Joint Review'],
  ['resource-sharing-plan', 'Resource Sharing Plan'],
  ['construction-coordination', 'Construction Coordination'],
  ['complete', 'Complete'],
];

const REQUEST_TYPES = [
  ['equipment-sharing', 'Equipment Sharing', 'Joint equipment planning'],
  ['crew-sharing', 'Crew Sharing', 'Joint crew planning'],
  ['permit-coordination', 'Permit Coordination', 'Align permitting reviews'],
  ['emergency-planning', 'Emergency Planning', 'Coordinate emergency planning'],
  ['environmental-review', 'Environmental Review', 'Coordinate environmental review'],
];

const REQUEST_STATUSES = [
  ['pending', 'Pending'],
  ['approved', 'Approved'],
  ['under-review', 'Under Review'],
  ['closed', 'Closed'],
];

const LOCAL_ACTION_PLAN = [
  'Schedule planning review.',
  'Compare contractor schedules.',
  'Evaluate shared staging locations.',
  'Coordinate permitting activities.',
  'Review resilience and storm preparedness impacts.',
];

const ACTION_LABELS = {
  'survey-contractor': 'Survey contractor',
  'permitting-schedule': 'Permitting schedule',
  'staging-yard': 'Staging yard',
  'environmental-review': 'Environmental review',
  'shared-right-of-way-access': 'Shared right-of-way access',
};

const RESOURCE_LABELS = {
  crews: 'Crews',
  equipment: 'Equipment',
  permitting: 'Permitting',
  'environmental-studies': 'Environmental studies',
  'land-access': 'Land access',
};

function makeElement(tagName, className, text) {
  const element = document.createElement(tagName);
  if (className) element.className = className;
  if (text !== undefined && text !== null) element.textContent = String(text);
  return element;
}

function setTestId(element, testId) {
  if (element && testId) element.dataset.testid = testId;
  return element;
}

function slug(value) {
  return String(value ?? 'item')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 72) || 'item';
}

function normalizeActions(actions) {
  return (Array.isArray(actions) ? actions : []).map((action, index) => {
    if (typeof action === 'string') {
      const id = slug(action);
      return { id, label: ACTION_LABELS[id] || action };
    }
    const label = action?.label || action?.name || `Discussion prompt ${index + 1}`;
    return { ...action, id: slug(action?.id || label), label };
  });
}

function normalizeResources(resourceItems) {
  return (Array.isArray(resourceItems) ? resourceItems : []).map((resource, index) => {
    if (typeof resource === 'string') {
      const id = slug(resource);
      return { id, label: RESOURCE_LABELS[id] || resource };
    }
    const label = resource?.label || resource?.name || `Category ${index + 1}`;
    return { ...resource, id: slug(resource?.id || label), label };
  });
}

function addValueRow(parent, label, value, explanation, testId, extraClass = '') {
  const row = makeElement('div', `coordination-value-row ${extraClass}`.trim());
  const heading = makeElement('div', 'coordination-value-heading');
  heading.append(
    setTestId(makeElement('span', 'coordination-value-label', label), `${testId}-label`),
    setTestId(makeElement('strong', 'coordination-value', value || 'In review'), testId),
  );
  row.append(heading);
  if (explanation) {
    row.append(setTestId(makeElement('p', 'coordination-value-explanation', explanation), `${testId}-explanation`));
  }
  parent.append(row);
  return row;
}

function renderSourceBadge(sourceType, pairKey) {
  const isPublic = sourceType === 'public-source point proximity';
  const badge = makeElement(
    'span',
    `coordination-source-badge ${isPublic ? 'is-public' : 'is-demo'}`,
    isPublic ? 'Source-linked projects' : 'Planning candidate',
  );
  badge.title = isPublic
    ? 'Independently located source points; this is point proximity, not full-route overlap.'
    : 'Demo project centers used for planning discussion; not a verified construction match.';
  return setTestId(badge, `status-source-type-${pairKey}`);
}

function renderStatusControl({ pairKey, status, onStatusChange }) {
  const wrapper = makeElement('section', 'coordination-status-control');
  wrapper.append(
    makeElement('span', 'coordination-control-label', 'Local collaboration progress'),
    makeElement('p', 'coordination-muted', 'Choose the current planning stage. This is not an external contact log.'),
  );
  const timeline = setTestId(makeElement('div', 'coordination-timeline'), `timeline-${pairKey}`);
  timeline.setAttribute('role', 'group');
  timeline.setAttribute('aria-label', 'Six-stage local coordination status');
  const currentIndex = Math.max(0, STATUS_OPTIONS.findIndex(([value]) => value === status));
  STATUS_OPTIONS.forEach(([value, label], index) => {
    const step = setTestId(makeElement('button', 'coordination-timeline-step'), `button-stage-${pairKey}-${value}`);
    step.type = 'button';
    step.classList.toggle('is-current', index === currentIndex);
    step.classList.toggle('is-complete', index < currentIndex);
    step.setAttribute('aria-pressed', String(index === currentIndex));
    step.setAttribute('aria-label', `Set local planning stage: ${label}`);
    step.append(
      makeElement('span', 'coordination-step-index', index <= currentIndex ? '✓' : '○'),
      makeElement('span', 'coordination-step-label', label),
    );
    step.addEventListener('click', () => {
      const selectedIndex = STATUS_OPTIONS.findIndex(([option]) => option === value);
      timeline.querySelectorAll('.coordination-timeline-step').forEach((button, buttonIndex) => {
        button.classList.toggle('is-current', buttonIndex === selectedIndex);
        button.classList.toggle('is-complete', buttonIndex < selectedIndex);
        const marker = button.querySelector('.coordination-step-index');
        if (marker) marker.textContent = buttonIndex <= selectedIndex ? '✓' : '○';
        button.setAttribute('aria-pressed', String(buttonIndex === selectedIndex));
      });
      if (typeof onStatusChange === 'function') onStatusChange(value);
    });
    timeline.appendChild(step);
  });
  wrapper.appendChild(timeline);
  return wrapper;
}

function renderActionList({ pairKey, actions, selectedActions, onActionToggle }) {
  const section = makeElement('section', 'coordination-actions');
  section.append(
    makeElement('div', 'coordination-subhead', 'Suggested coordination actions'),
    makeElement('p', 'coordination-muted', 'Select prompts to include in your local planning draft. Selection does not mark work complete.'),
  );
  const selected = new Set((Array.isArray(selectedActions) ? selectedActions : []).map(slug));
  const list = makeElement('div', 'coordination-action-list');
  actions.forEach((action) => {
    const label = makeElement('label', `coordination-action ${selected.has(action.id) ? 'is-selected' : ''}`.trim());
    const input = setTestId(document.createElement('input'), `toggle-action-${pairKey}-${action.id}`);
    input.type = 'checkbox';
    input.checked = selected.has(action.id);
    input.addEventListener('change', () => {
      label.classList.toggle('is-selected', input.checked);
      if (typeof onActionToggle === 'function') onActionToggle(action.id, input.checked);
    });
    label.append(input, setTestId(makeElement('span', '', action.label), `text-action-${pairKey}-${action.id}`));
    list.appendChild(label);
  });
  section.appendChild(list);
  return section;
}

function renderResourceList({ pairKey, resourceItems }) {
  const section = makeElement('section', 'coordination-resources coordination-resource-topics');
  const heading = makeElement('div', 'coordination-resource-heading');
  heading.append(
    makeElement('div', 'coordination-subhead', 'Shared Resources'),
    makeElement('span', 'coordination-resource-count', `${resourceItems.length} opportunities identified`),
  );
  section.appendChild(heading);
  const list = makeElement('ul', 'coordination-resource-list');
  resourceItems.forEach((resource) => {
    const row = makeElement('li', 'coordination-resource-row');
    const label = setTestId(makeElement('span', 'coordination-resource-label', resource.label), `text-resource-${pairKey}-${resource.id}`);
    row.append(
      makeElement('span', 'coordination-resource-check', '✓'),
      label,
    );
    list.appendChild(row);
  });
  if (!resourceItems.length) section.hidden = true;
  section.appendChild(list);
  return section;
}

function renderSuggestedNextAction({ nextAction }) {
  const section = makeElement('section', 'coordination-next-action');
  section.append(
    makeElement('div', 'coordination-subhead', 'Next Recommended Action'),
    makeElement('p', 'coordination-next-action-text', nextAction || 'Initiate Joint Review'),
  );
  return section;
}

function recommendedActionForStatus(status, isPublic) {
  if (!isPublic) return 'Use the planning sample to explore a joint review.';
  const recommendations = {
    'opportunity-identified': 'Initiate Joint Review',
    'contact-initiated': 'Confirm Utility Engagement',
    'joint-review': 'Align Project Scope',
    'resource-sharing-plan': 'Confirm Shared Resource Plan',
    'construction-coordination': 'Align Construction Milestones',
    complete: 'Review Coordination Outcomes',
  };
  return recommendations[status] || 'Initiate Joint Review';
}

function renderSourceLinks({ pairKey, sourceLinks }) {
  const links = Array.isArray(sourceLinks) ? sourceLinks : [];
  const section = makeElement('section', 'coordination-source-links');
  section.append(
    makeElement('div', 'coordination-subhead', 'Evidence links'),
    makeElement('p', 'coordination-muted', 'Open the cited filing or map evidence for the located point.'),
  );
  const list = makeElement('div', 'coordination-source-link-list');
  links.forEach((source, index) => {
    if (typeof source?.href !== 'string') return;
    let url;
    try {
      url = new URL(source.href);
    } catch {
      return;
    }
    if (!['https:', 'http:'].includes(url.protocol)) return;
    const link = setTestId(
      makeElement('a', 'coordination-source-link', source.label || `Source ${index + 1}`),
      `link-evidence-${pairKey}-${index + 1}`,
    );
    link.href = url.href;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    list.appendChild(link);
  });
  if (!list.childElementCount) {
    section.appendChild(makeElement(
      'p',
      'coordination-muted',
      'No public source link is attached to this demo candidate.',
    ));
  } else {
    section.appendChild(list);
  }
  return section;
}

export function renderCoordinationPotentialScore({ pairId, score }) {
  const pairKey = slug(pairId);
  const eligible = score?.eligible !== false;
  const section = makeElement('section', 'coordination-potential-score-card');
  const scoreDetails = makeElement('details', 'coordination-potential-score-details');
  scoreDetails.appendChild(makeElement('summary', '', 'View Methodology'));
  const heading = makeElement('div', 'coordination-subhead', 'Coordination Potential');
  const value = setTestId(
    makeElement(
      'strong',
      'coordination-potential-score-value',
      !eligible
        ? 'Review in progress'
        : score?.grade
          ? score.grade.grade
          : 'Review in progress',
    ),
    `text-coordination-potential-score-${pairKey}`,
  );
  const status = makeElement(
    'p',
    'coordination-potential-score-status',
    !eligible
      ? 'Planning inputs are being reviewed.'
      : score?.grade
        ? `${score.normalizedScore}/100 · ${score.grade.label} Opportunity`
        : 'Coordination potential is being reviewed.',
  );
  const detailContent = makeElement('div', 'coordination-potential-score-breakdown');
  detailContent.append(
    makeElement(
      'p',
      'coordination-potential-score-caveat',
      score?.grade
        ? `Available-input score: ${score.knownTotal}/${score.assessedMax}; normalized to ${score.normalizedScore}/100.`
        : 'A score appears when a usable distance or published-date input is available.',
    ),
    makeElement(
      'p',
      'coordination-potential-score-caveat',
      'Only drivers with available inputs contribute to the denominator. Unknown drivers are omitted from the calculation.',
    ),
  );
  const driverList = makeElement('ul', 'coordination-potential-driver-list');
  for (const [key, label] of Object.entries(COORDINATION_POTENTIAL_DRIVER_LABELS)) {
    const points = score?.parts?.[key];
    const maximum = COORDINATION_POTENTIAL_WEIGHTS[key];
    if (points == null) continue;
    driverList.appendChild(makeElement(
      'li',
      '',
      `${label}: +${points} of ${maximum} points`,
    ));
  }
  const gradeList = makeElement('ul', 'coordination-potential-grade-list');
  COORDINATION_POTENTIAL_GRADE_BANDS.forEach(({ grade, label, min, max }) => {
    gradeList.appendChild(makeElement('li', '', `${grade}: ${min}–${max} · ${label}`));
  });
  scoreDetails.append(
    makeElement('strong', 'coordination-potential-detail-title', 'Score drivers'),
    driverList,
    makeElement(
      'p',
      'coordination-potential-score-caveat',
      `Drivers omitted from this score: ${score?.omittedDrivers?.length ? score.omittedDrivers.join(', ') : 'none'}.`,
    ),
    makeElement('strong', 'coordination-potential-detail-title', 'Grade ranges'),
    gradeList,
    makeElement(
      'p',
      'coordination-potential-score-caveat',
      'Distance is between located sites. Published in-service dates are planning context, not construction schedules. Neither establishes route overlap or shared construction.',
    ),
  );
  scoreDetails.appendChild(detailContent);
  section.append(heading, value, status, scoreDetails);
  return section;
}

function renderPlanArea({ pairKey, onGeneratePlan }) {
  const section = makeElement('section', 'coordination-plan-area');
  const heading = makeElement('div', 'coordination-subhead', 'AI Coordination Summary');
  const note = makeElement('p', 'coordination-muted', 'Generate a discussion aid from located project sites, published dates, and selected prompts.');
  const button = setTestId(makeElement('button', 'coordination-primary-button', 'Generate AI Coordination Summary'), `button-generate-summary-${pairKey}`);
  button.type = 'button';
  const status = setTestId(makeElement('p', 'coordination-plan-status', ''), `status-plan-${pairKey}`);
  status.setAttribute('aria-live', 'polite');
  const result = setTestId(makeElement('div', 'coordination-plan-result'), `result-plan-${pairKey}`);
  result.setAttribute('aria-live', 'polite');
  button.addEventListener('click', async () => {
    if (typeof onGeneratePlan !== 'function') {
      status.textContent = 'Advisory drafting is not connected in this view.';
      return;
    }
    button.disabled = true;
    button.textContent = 'Generating summary…';
    status.textContent = 'Preparing an advisory draft…';
    result.replaceChildren();
    try {
      const draft = await onGeneratePlan();
      const label = makeElement('strong', 'coordination-plan-label', 'AI-generated coordination summary');
      const disclaimer = makeElement('p', 'coordination-plan-disclaimer', 'For local discussion only. Not an official plan, commitment, or agreement.');
      const body = setTestId(makeElement('p', 'coordination-plan-body', draft || 'No draft was returned.'), `text-plan-${pairKey}`);
      result.append(label, disclaimer, body);
      status.textContent = 'Draft ready for review.';
    } catch (error) {
      status.textContent = 'The advisory draft could not be generated. Try again.';
      const detail = error?.message ? `Details: ${error.message}` : 'The planning service returned no details.';
      result.appendChild(makeElement('p', 'coordination-plan-error', detail));
    } finally {
      button.disabled = false;
      button.textContent = 'Generate AI Coordination Summary';
    }
  });
  section.append(heading, note, button, status, result);
  return section;
}

function renderPlanSteps(parent, steps) {
  const list = makeElement('ol', 'coordination-joint-plan-steps');
  steps.forEach((step) => {
    list.appendChild(makeElement('li', '', step));
  });
  parent.appendChild(list);
}

function normalizedPlanSteps(text) {
  const lines = String(text || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => line.replace(/^(?:step\s*\d+\s*[:.)-]?\s*|\d+\s*[.)-]\s*|[-*]\s*)/i, '').trim())
    .filter(Boolean);
  return lines.slice(0, 5);
}

function renderJointActionPlanArea({ pairKey, onGenerateJointActionPlan }) {
  const section = makeElement('section', 'coordination-joint-plan-area coordination-ai-plan-area');
  const button = setTestId(
    makeElement('button', 'coordination-primary-button', 'Generate AI Plan'),
    `button-generate-ai-plan-${pairKey}`,
  );
  button.type = 'button';
  const status = setTestId(makeElement('p', 'coordination-plan-status', ''), `status-joint-plan-${pairKey}`);
  status.setAttribute('aria-live', 'polite');
  status.hidden = true;
  const result = setTestId(makeElement('div', 'coordination-plan-result'), `result-joint-plan-${pairKey}`);
  result.setAttribute('aria-live', 'polite');
  result.hidden = true;
  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'Generating AI plan…';
    status.textContent = 'Preparing a five-step draft…';
    status.hidden = false;
    result.replaceChildren();
    result.hidden = true;
    try {
      const generated = typeof onGenerateJointActionPlan === 'function'
        ? await onGenerateJointActionPlan()
        : '';
      const steps = normalizedPlanSteps(generated);
      if (steps.length === 5) {
        result.append(makeElement('strong', 'coordination-plan-label', 'AI-generated Joint Action Plan'));
        renderPlanSteps(result, steps);
        result.hidden = false;
        status.textContent = 'AI draft ready for review.';
      } else {
        throw new Error('The planning service returned no usable steps.');
      }
    } catch (error) {
      result.append(
        makeElement('strong', 'coordination-plan-label', 'Local planning template · not AI-generated'),
        makeElement('p', 'coordination-plan-disclaimer', 'The AI service was unavailable.'),
      );
      renderPlanSteps(result, LOCAL_ACTION_PLAN);
      result.hidden = false;
      status.textContent = 'AI unavailable; a clearly labeled local template is shown.';
      if (error?.message) {
        result.appendChild(makeElement('p', 'coordination-plan-error', `AI detail: ${error.message}`));
      }
    } finally {
      button.disabled = false;
      button.textContent = 'Generate AI Plan';
    }
  });
  section.append(button, status, result);
  return section;
}

function renderRequestArea({
  pairKey,
  utilityFrom,
  utilityTo,
  distanceLabel,
  savingsRange,
  timeSavedRange,
  requestType,
  requestStatus,
  onRequestChange,
}) {
  const section = makeElement('section', 'coordination-request-area');
  section.append(
    makeElement('div', 'coordination-subhead', 'Coordination Requests'),
    makeElement('p', 'coordination-muted', 'Prepare a request draft for review with participating utilities.'),
  );
  const dialog = setTestId(document.createElement('dialog'), `dialog-coordination-request-${pairKey}`);
  dialog.className = 'coordination-request-dialog';
  const titleId = `coordination-request-title-${pairKey}`;
  const title = makeElement('h3', 'coordination-request-title', 'Coordination Request Draft');
  title.id = titleId;
  dialog.setAttribute('aria-labelledby', titleId);
  const closeButton = makeElement('button', 'coordination-dialog-close', 'Close');
  closeButton.type = 'button';
  closeButton.addEventListener('click', () => dialog.close());

  const requestInfo = makeElement('div', 'coordination-request-details');
  addValueRow(requestInfo, 'FROM', utilityFrom, '', `request-from-${pairKey}`);
  addValueRow(requestInfo, 'TO', utilityTo, '', `request-to-${pairKey}`);
  const requestDisplay = makeElement('p', 'coordination-request-value');
  const benefit = makeElement(
    'p',
    'coordination-request-benefit',
    `Savings scenarios: ${savingsRange || 'Review in progress'} · Schedule planning range: ${timeSavedRange || 'Review in progress'}.`,
  );
  const reason = makeElement(
    'p',
    'coordination-request-reason',
    `Planning distance: ${distanceLabel || 'Review in progress'}.`,
  );

  const typeLabel = makeElement('label', 'coordination-request-field', 'Request Type');
  const typeSelect = setTestId(document.createElement('select'), `select-request-type-${pairKey}`);
  REQUEST_TYPES.forEach(([value, label]) => {
    const option = makeElement('option', '', label);
    option.value = value;
    typeSelect.appendChild(option);
  });
  typeSelect.value = REQUEST_TYPES.some(([value]) => value === requestType)
    ? requestType
    : REQUEST_TYPES[0][0];
  typeLabel.appendChild(typeSelect);
  const updateRequestDisplay = () => {
    const selected = REQUEST_TYPES.find(([value]) => value === typeSelect.value);
    requestDisplay.textContent = `REQUEST: ${selected?.[2] || 'Joint coordination planning'}`;
  };
  updateRequestDisplay();

  const statusLabel = makeElement('label', 'coordination-request-field', 'Status');
  const statusSelect = setTestId(document.createElement('select'), `select-request-status-${pairKey}`);
  REQUEST_STATUSES.forEach(([value, label]) => {
    const option = makeElement('option', '', label);
    option.value = value;
    statusSelect.appendChild(option);
  });
  statusSelect.value = REQUEST_STATUSES.some(([value]) => value === requestStatus)
    ? requestStatus
    : REQUEST_STATUSES[0][0];
  statusLabel.appendChild(statusSelect);

  typeSelect.addEventListener('change', updateRequestDisplay);
  const localStatus = setTestId(makeElement('p', 'coordination-request-local-status', ''), `status-request-${pairKey}`);
  localStatus.setAttribute('aria-live', 'polite');
  const saveButton = setTestId(
    makeElement('button', 'coordination-primary-button', 'Save Request Locally'),
    `button-save-request-${pairKey}`,
  );
  saveButton.type = 'button';
  saveButton.addEventListener('click', () => {
    if (typeof onRequestChange === 'function') {
      onRequestChange({
        requestType: typeSelect.value,
        requestStatus: statusSelect.value,
      });
    }
    const savedLabel = REQUEST_STATUSES.find(([value]) => value === statusSelect.value)?.[1] || 'Pending';
    savedStatus.textContent = `Local request status: ${savedLabel}.`;
    localStatus.textContent = 'Saved in this browser only. No request was sent.';
  });
  dialog.append(
    title,
    closeButton,
    makeElement('p', 'coordination-request-disclaimer', 'Demo only — this draft is not transmitted to either utility. Status is not an official approval.'),
    requestInfo,
    requestDisplay,
    reason,
    benefit,
    typeLabel,
    statusLabel,
    saveButton,
    localStatus,
  );

  const openButton = setTestId(
    makeElement('button', 'coordination-primary-button', 'Send Coordination Request'),
    `button-send-request-${pairKey}`,
  );
  openButton.type = 'button';
  const savedStatusLabel = REQUEST_STATUSES.find(([value]) => value === requestStatus)?.[1] || 'Pending';
  const savedStatus = setTestId(
    makeElement('p', 'coordination-request-saved-status', `Local request status: ${savedStatusLabel}.`),
    `text-request-saved-status-${pairKey}`,
  );
  savedStatus.setAttribute('aria-live', 'polite');
  openButton.addEventListener('click', () => {
    updateRequestDisplay();
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  });
  section.append(openButton, savedStatus, dialog);
  return section;
}

/**
 * Render a single coordination opportunity as a DOM-only, browser-local planning card.
 * The caller owns all persistence and data fetching through the callback contract.
 */
export function renderCoordinationActionCard({
  pairId,
  opportunityRank,
  participatingUtilities,
  projectAName,
  projectBName,
  distanceLabel,
  distanceExplanation,
  dateLabel,
  dateExplanation,
  sourceType,
  sourceLinks,
  coordinationPotentialScore,
  knownInvestment,
  dateGapLabel,
  costVisibility,
  budgetConfidence,
  resourceSharingPotential,
  savingsAnalysis,
  combinedInvestmentRange,
  savingsRange,
  timeSavedRange,
  expectedSavingsValue,
  expectedSavingsRange,
  implementationDifficulty,
  nextAction,
  actions,
  resourceItems,
  status,
  selectedActions,
  requestType,
  requestStatus,
  onStatusChange,
  onActionToggle,
  onRequestChange,
  onGeneratePlan,
  onGenerateJointActionPlan,
  onOpenWorkspace,
  onCompareCosts,
}) {
  const pairKey = slug(pairId || `${projectAName}-${projectBName}`);
  const card = setTestId(makeElement('article', 'coordination-action-card'), `card-coordination-${pairKey}`);
  card.dataset.pairid = String(pairId || '');
  card.tabIndex = -1;
  const header = makeElement('header', 'coordination-card-header');
  const isPublic = sourceType === 'public-source point proximity';
  const eyebrowText = isPublic && Number.isInteger(opportunityRank)
    ? `OPPORTUNITY #${opportunityRank}`
    : isPublic
      ? 'COORDINATION OPPORTUNITY'
      : 'PLANNING CANDIDATE';
  const eyebrow = makeElement('div', 'coordination-card-eyebrow', eyebrowText);
  const title = setTestId(makeElement('h3', 'coordination-card-title'), `text-pair-${pairKey}`);
  title.appendChild(makeElement('span', 'coordination-participating-label', 'Utility Pair'));
  const participants = makeElement('span', 'coordination-participating-utilities');
  (Array.isArray(participatingUtilities) ? participatingUtilities : [])
    .filter((name) => typeof name === 'string' && name.trim())
    .forEach((name, index) => {
      if (index > 0) participants.appendChild(makeElement('span', 'coordination-arrow', '↔'));
      participants.appendChild(setTestId(makeElement('span', 'coordination-participant', name), `text-participant-${pairKey}-${index + 1}`));
    });
  if (!participants.childElementCount) participants.textContent = 'Utilities under review';
  title.appendChild(participants);
  const projects = setTestId(
    makeElement('p', 'coordination-card-projects', `${projectAName || 'Project A'} ↔ ${projectBName || 'Project B'}`),
    `text-project-pair-${pairKey}`,
  );
  const statusChip = makeElement('span', 'coordination-status-chip');
  const updateStatusChip = (value) => {
    const label = STATUS_OPTIONS.find(([option]) => option === value)?.[1] || 'Opportunity Identified';
    statusChip.textContent = `Status · ${label}`;
  };
  updateStatusChip(status);
  header.append(eyebrow, title, projects, renderSourceBadge(sourceType, pairKey), statusChip);

  const technicalDetails = makeElement('details', 'coordination-technical-details');
  technicalDetails.appendChild(makeElement('summary', 'coordination-technical-summary', 'Methodology & Sources'));
  const metaContent = makeElement('div', 'coordination-impact-content');
  metaContent.append(
    makeElement('div', 'coordination-subhead', 'Evidence and planning context'),
    makeElement('p', 'coordination-muted', 'Point proximity and published dates are screening context only; they do not establish route overlap, compatible schedules, or shared construction.'),
  );
  const metaGrid = makeElement('div', 'coordination-meta-grid');
  addValueRow(metaGrid, 'Point distance', distanceLabel, distanceExplanation, `text-distance-${pairKey}`);
  addValueRow(metaGrid, 'Planned dates', dateLabel, dateExplanation, `text-dates-${pairKey}`);
  addValueRow(
    metaGrid,
    'Illustrative money-saved scenario',
    isPublic ? savingsRange || 'Not available' : 'Not available',
    isPublic
      ? 'Distance-tier planning scenario only; not a verified project estimate.'
      : 'Not shown for demo candidates because their coordinates are not source-verified.',
    `text-savings-${pairKey}`,
  );
  addValueRow(
    metaGrid,
    'Illustrative time-saved scenario',
    isPublic ? timeSavedRange || 'Not available' : 'Not available',
    isPublic
      ? 'Generic schedule scenario; not derived from project schedules or planned in-service dates.'
      : 'Not shown for demo candidates because their project match is not source-verified.',
    `text-schedule-reduction-${pairKey}`,
  );
  addValueRow(metaGrid, 'Planning effort', implementationDifficulty || 'Not assessed', 'Route, scope, permits, and access have not been jointly reviewed.', `text-difficulty-${pairKey}`);
  metaContent.appendChild(metaGrid);
  technicalDetails.append(
    metaContent,
    renderSourceLinks({ pairKey, sourceLinks }),
  );

  const caveat = setTestId(
    makeElement('p', 'coordination-caveat', sourceType === 'public-source point proximity'
      ? 'Located points show proximity only—not a full route or confirmed shared construction.'
      : 'Sample coordinates are candidates, not verified routes, projects, or commitments.'),
    `note-evidence-${pairKey}`,
  );
  technicalDetails.appendChild(caveat);
  technicalDetails.append(
    makeElement(
      'p',
      'coordination-muted',
      'Potential Shared Resources are discussion topics only; availability, authorization, and shared work are unconfirmed.',
    ),
    makeElement('p', 'coordination-muted', 'No meeting has been scheduled.'),
    makeElement('p', 'coordination-muted', 'Selections and request drafts remain in this browser; no contacts are sent.'),
    makeElement('p', 'coordination-muted', 'AI-generated plans are discussion drafts, not utility-approved work plans.'),
  );

  const nextStep = renderSuggestedNextAction({
    nextAction: recommendedActionForStatus(status, isPublic) || nextAction,
  });
  const nextActionText = nextStep.querySelector('.coordination-next-action-text');
  const planDetails = makeElement('details', 'coordination-plan-details');
  planDetails.appendChild(makeElement('summary', 'coordination-plan-summary', 'Status & Planning Context'));
  const body = makeElement('div', 'coordination-card-body');
  body.append(
    renderStatusControl({
      pairKey,
      status,
      onStatusChange(nextStatus) {
        updateStatusChip(nextStatus);
        if (nextActionText) nextActionText.textContent = recommendedActionForStatus(nextStatus, isPublic);
        if (typeof onStatusChange === 'function') onStatusChange(nextStatus);
      },
    }),
    renderActionList({ pairKey, actions: normalizeActions(actions), selectedActions, onActionToggle }),
    renderRequestArea({
      pairKey,
      utilityFrom: participatingUtilities?.[0],
      utilityTo: participatingUtilities?.[1],
      distanceLabel,
      savingsRange,
      timeSavedRange,
      requestType,
      requestStatus,
      onRequestChange,
    }),
  );
  const workspaceLink = makeElement('button', 'coordination-secondary-button coordination-inline-workspace', 'Open local planning workspace');
  workspaceLink.type = 'button';
  workspaceLink.addEventListener('click', () => {
    if (typeof onOpenWorkspace === 'function') onOpenWorkspace();
  });
  body.appendChild(workspaceLink);
  planDetails.appendChild(body);

  const opportunitySummary = makeElement('div', 'coordination-opportunity-summary');
  for (const [label, value, note] of [
    ['Distance', distanceLabel || 'Review in progress', ''],
    ['Expected Savings', expectedSavingsValue || 'Review in progress', expectedSavingsRange || ''],
  ]) {
    const fact = makeElement('div', 'coordination-opportunity-metric');
    fact.append(
      makeElement('span', 'coordination-opportunity-label', label),
      makeElement('strong', 'coordination-opportunity-value', value),
    );
    if (note) fact.appendChild(makeElement('small', 'coordination-opportunity-note', note));
    opportunitySummary.appendChild(fact);
  }

  const footer = makeElement('footer', 'coordination-card-footer');
  const openButton = setTestId(
    makeElement('button', 'coordination-secondary-button coordination-open-opportunity', 'Open Opportunity'),
    `button-cost-comparison-${pairKey}`,
  );
  openButton.type = 'button';
  openButton.addEventListener('click', () => {
    if (typeof onCompareCosts === 'function') onCompareCosts();
  });
  footer.append(openButton, renderJointActionPlanArea({ pairKey, onGenerateJointActionPlan }));

  const why = makeElement(
    'p',
    'coordination-card-why',
    isPublic
      ? 'Review project scope, location, and schedules with both utilities before evaluating shared construction.'
      : 'Use the planning sample to identify useful coordination questions.',
  );
  technicalDetails.appendChild(why);
  card.append(
    header,
    opportunitySummary,
    renderCoordinationPotentialScore({ pairId: pairKey, score: coordinationPotentialScore }),
    renderResourceList({ pairKey, resourceItems: normalizeResources(resourceItems) }),
    nextStep,
    technicalDetails,
    planDetails,
    footer,
  );
  return card;
}

export { STATUS_OPTIONS, ACTION_LABELS, RESOURCE_LABELS };