import { SCENARIO_PROXIMITY_BANDS } from './scenario-proximity.js';

const escapeHtml = (value) => String(value ?? '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#39;');

const safeUrl = (value) => {
  if (typeof value !== 'string') return null;
  try {
    const url = new URL(value.trim());
    return url.protocol === 'https:' && url.hostname && !url.username && !url.password
      ? escapeHtml(url.href)
      : null;
  } catch {
    return null;
  }
};

const shown = (value, fallback = 'Not available') =>
  value === null || value === undefined || String(value).trim() === ''
    ? fallback
    : escapeHtml(value);

const formatDate = (value) => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return 'Not provided';
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isNaN(date.getTime())
    ? 'Not provided'
    : new Intl.DateTimeFormat('en-US', {
      year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC',
    }).format(date);
};

const formatCount = (value) =>
  Number.isFinite(value) && value >= 0 ? Math.floor(value).toLocaleString('en-US') : '—';

const sourceLink = (url, label) => {
  const safe = safeUrl(url);
  return safe
    ? `<a href="${safe}" rel="noopener noreferrer">${escapeHtml(label)}</a>`
    : 'No safe HTTPS source link';
};

const namedEndpoint = (project) =>
  project?.subpoints?.[0]?.name || 'Endpoint not independently identified';

const comparisonCard = (project, side) => {
  const mapEvidence = sourceLink(project?.mapEvidence, 'Map feature');
  return `<article class="project-card">
    <div class="card-kicker">${side} / PROJECT RECORD</div>
    <h3>${shown(project?.utilityName, 'Utility not provided')}</h3>
    <p class="project-name">${shown(project?.name, 'Project not provided')}</p>
    <dl>
      <div><dt>Filing project ID</dt><dd>${shown(project?.filingProjectId)}</dd></div>
      <div><dt>Located endpoint</dt><dd>${shown(namedEndpoint(project))}</dd></div>
      <div><dt>Planned in-service</dt><dd>${shown(formatDate(project?.inServiceDate))}</dd></div>
      <div><dt>Filing / page</dt><dd>${shown(project?.sourceDocument)}${project?.sourcePage ? ` · p. ${escapeHtml(project.sourcePage)}` : ''}</dd></div>
      <div><dt>Map evidence</dt><dd>${mapEvidence}</dd></div>
    </dl>
    <p class="source-action">${sourceLink(project?.sourceUrl, 'Open cited filing')}</p>
  </article>`;
};

function schematicMap(pair) {
  if (!pair?.dCenter || !pair?.gCenter) {
    return '<div class="map-empty">No independently located endpoint pair is available for a schematic view.</div>';
  }
  const points = [
    { project: pair.d, center: pair.dCenter, side: 'A', x: 115, y: 104 },
    { project: pair.g, center: pair.gCenter, side: 'B', x: 385, y: 184 },
  ];
  return `<figure class="schematic">
    <figcaption><span>Endpoint proximity</span><span>SCHEMATIC · NOT TO SCALE</span></figcaption>
    <svg viewBox="0 0 500 255" role="img" aria-label="Schematic line between two independently located project endpoints; not an electrical route">
      <path class="map-grid" d="M20 40H480 M20 90H480 M20 140H480 M20 190H480 M80 20V225 M180 20V225 M280 20V225 M380 20V225"/>
      <path class="map-land" d="M0 210 C90 170 115 215 195 177 S340 163 500 192 V255 H0Z"/>
      <line class="endpoint-link" x1="115" y1="104" x2="385" y2="184"/>
      ${points.map(({ project, center, side, x, y }) => `<g>
        <circle class="endpoint-halo" cx="${x}" cy="${y}" r="15"/>
        <circle class="endpoint-dot" cx="${x}" cy="${y}" r="6"/>
        <text class="map-label" x="${x + (side === 'A' ? 20 : -20)}" y="${y - 11}" text-anchor="${side === 'A' ? 'start' : 'end'}">${escapeHtml(namedEndpoint(project))}</text>
        <text class="map-coordinate" x="${x + (side === 'A' ? 20 : -20)}" y="${y + 8}" text-anchor="${side === 'A' ? 'start' : 'end'}">${center.lat.toFixed(4)}, ${center.lon.toFixed(4)}</text>
      </g>`).join('')}
      <text class="map-distance" x="250" y="126" text-anchor="middle">${escapeHtml(Number(pair.distMiles).toFixed(2))} mi point distance</text>
    </svg>
    <p>Dashed line shows point-to-point proximity only. It is not an electrical route, project alignment, or confirmed construction overlap.</p>
  </figure>`;
}

function opportunityRows(verifiedPairs, demoOpportunities) {
  const sortForReview = (rows) => rows.sort((a, b) =>
    (a.distanceMiles ?? Infinity) - (b.distanceMiles ?? Infinity) ||
    (Math.abs(a.dateGap ?? Infinity) - Math.abs(b.dateGap ?? Infinity)));
  const sourcedRows = sortForReview(
    verifiedPairs.map((pair) => ({
      evidence: 'Sourced named endpoints',
      className: 'source',
      a: pair.d,
      b: pair.g,
      distanceMiles: pair.distMiles,
      dateGap: pair.inServiceDateGapDays,
      pair,
    })),
  );
  const demoRows = sortForReview(
    demoOpportunities.map((overlap) => ({
      evidence: 'Unverified demo centers',
      className: 'demo',
      a: overlap.d,
      b: overlap.g,
      distanceMiles: overlap.distMiles,
      dateGap: overlap.inServiceDateGapDays,
      overlap,
    })),
  );
  return [...sourcedRows, ...demoRows];
}

function opportunityTable(rows) {
  if (!rows.length) {
    return '<p class="empty-state">No source-linked pair or demo candidate is available in the loaded data.</p>';
  }
  return `<div class="table-scroll"><table class="opportunity-table">
    <thead><tr><th>Pair</th><th>Evidence status</th><th>Next step</th><th>Potential savings</th></tr></thead>
    <tbody>${rows.slice(0, 10).map((row) => `<tr>
      <td>${shown(row.a?.name)} <span class="pair-arrow">↔</span> ${shown(row.b?.name)}</td>
      <td><span class="evidence-tag ${row.className}">${escapeHtml(row.evidence)}</span></td>
      <td>${row.className === 'source' ? 'Confirm project scope and geometry' : 'Verify project and location records'}</td>
      <td><strong>Not estimated</strong><small>Comparable budgets and shared scope are not confirmed</small></td>
    </tr>`).join('')}</tbody>
  </table></div>
  <p class="table-note">Source-linked and demo records are separated. This list is not a priority, readiness, risk, or savings ranking; point proximity is not shared work.</p>`;
}

const sourcedAppendixRows = (pairs) => pairs.length
  ? pairs.map((pair) => `<tr>
      <td>${shown(pair.d?.name)} (${shown(pair.d?.filingProjectId)}) ↔ ${shown(pair.g?.name)} (${shown(pair.g?.filingProjectId)})</td>
      <td>${shown(namedEndpoint(pair.d))}<br>${Number.isFinite(pair.dCenter?.lat) ? `${pair.dCenter.lat}, ${pair.dCenter.lon}` : 'Coordinates unavailable'}<br>${shown(pair.d?.mapEvidence)}</td>
      <td>${shown(namedEndpoint(pair.g))}<br>${Number.isFinite(pair.gCenter?.lat) ? `${pair.gCenter.lat}, ${pair.gCenter.lon}` : 'Coordinates unavailable'}<br>${shown(pair.g?.mapEvidence)}</td>
      <td>${Number.isFinite(pair.distMiles) ? `${pair.distMiles.toFixed(2)} mi` : 'Not available'}</td>
      <td>${shown(formatDate(pair.d?.inServiceDate))} / ${shown(formatDate(pair.g?.inServiceDate))}<br>${Number.isFinite(pair.inServiceDateGapDays) ? `${pair.inServiceDateGapDays} days apart` : 'Gap not available'}</td>
      <td>${sourceLink(pair.d?.sourceUrl, `${pair.d?.sourceDocument || 'Filing'} p. ${pair.d?.sourcePage || '—'}`)}<br>${sourceLink(pair.g?.sourceUrl, `${pair.g?.sourceDocument || 'Filing'} p. ${pair.g?.sourcePage || '—'}`)}</td>
    </tr>`).join('')
  : '<tr><td colspan="6">No sourced named-endpoint pairs are available.</td></tr>';

const demoAppendixRows = (opportunities) => opportunities.length
  ? opportunities.map((row) => `<tr>
      <td>${shown(row.d?.name)} ↔ ${shown(row.g?.name)}</td>
      <td>${shown(row.d?.utilityName)} / ${shown(row.g?.utilityName)}</td>
      <td>${Number.isFinite(row.dCenter?.lat) ? `${row.dCenter.lat}, ${row.dCenter.lon}` : 'Not verified'} / ${Number.isFinite(row.gCenter?.lat) ? `${row.gCenter.lat}, ${row.gCenter.lon}` : 'Not verified'}</td>
      <td>${Number.isFinite(row.distMiles) ? `${row.distMiles.toFixed(2)} mi` : 'Not available'}</td>
      <td>${row.inServiceDateGapDays == null ? 'Not supplied' : `${row.inServiceDateGapDays} days`}</td>
      <td>${shown(row.d?.locationConfidence, 'unverified')} / ${shown(row.g?.locationConfidence, 'unverified')}</td>
    </tr>`).join('')
  : '<tr><td colspan="6">No distance-based demo candidates are available.</td></tr>';

const submittedAppendixRows = (candidates) => candidates.length
  ? candidates.map((candidate) => `<tr>
      <td>${shown(candidate.descName)} ↔ ${shown(candidate.gpcName)}</td>
      <td>${shown(candidate.distanceMiles)} mi</td>
      <td>${candidate.dateGapDays == null ? 'Not supplied' : `${escapeHtml(candidate.dateGapDays)} days`}</td>
      <td>Submitted workbook; not independently confirmed or mapped as a sourced pair.</td>
    </tr>`).join('')
  : '<tr><td colspan="4">No submitted workbook candidates loaded.</td></tr>';

export function renderReportDashboardHtml({
  reportKind = 'executive',
  primaryPair = null,
  verifiedPairs = [],
  demoOpportunities = [],
  submittedCandidates = [],
  facilityCount = null,
  corridorCount = null,
  riskCounts = {},
  stormMode = false,
  interpretation = '',
  interpretationSource = '',
  generatedAt = new Date().toISOString(),
} = {}) {
  const isTechnical = reportKind === 'technical';
  const rows = opportunityRows(verifiedPairs, demoOpportunities);
  const pair = primaryPair || verifiedPairs[0] || null;
  const distance = Number.isFinite(pair?.distMiles) ? `${pair.distMiles.toFixed(2)} mi` : 'Not available';
  const dateGap = Number.isFinite(pair?.inServiceDateGapDays)
    ? `${pair.inServiceDateGapDays} days`
    : 'Not available';
  const recommendations = pair
    ? `Ask ${pair.d?.utilityName || 'the first utility'} and ${pair.g?.utilityName || 'the second utility'} to confirm both named endpoints, current project scope and in-service targets. Compare authoritative route or site geometry before estimating any joint work or customer impact.`
    : 'Start with current utility filings and independently verifiable project endpoints. Treat map-only candidates as discovery leads; do not infer shared routes, costs, outages, or customer impacts.';
  const unsubstantiatedInterpretation = /(?:\$\s?[\d,.]|(?:\d+(?:\.\d+)?\s*%)|(?:\d[\d,]*)\s*(?:customers?|meters?|outages?|households?)\b|\b(?:save|saves|saved|savings|cost(?:s)?|budget(?:s)?|financial|roi|payback|cheaper|cost[- ]benefit|customer(?:s)? (?:impact|exposure)|outage(?:s)? (?:risk|impact)|flood (?:risk|exposure)|storm surge|wind exposure|hurricane probability|schedule acceleration|ferc compliance)\b)/i;
  const safeInterpretation = typeof interpretation === 'string' &&
    interpretation.trim().length > 0 &&
    !unsubstantiatedInterpretation.test(interpretation)
    ? interpretation.trim()
    : '';
  const dateText = Number.isNaN(new Date(generatedAt).getTime())
    ? 'Not provided'
    : new Intl.DateTimeFormat('en-US', {
      year: 'numeric', month: 'short', day: 'numeric',
    }).format(new Date(generatedAt));
  const bandCards = SCENARIO_PROXIMITY_BANDS.map((band) =>
    `<div class="risk-band"><span class="swatch ${band.key}" aria-hidden="true"></span><b>${escapeHtml(band.label)}</b><span>${escapeHtml(band.range)}</span><strong>${formatCount(riskCounts[band.key])}</strong></div>`).join('');

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>GridLock | ${isTechnical ? 'Technical' : 'Executive'} coordination report</title>
<style>
:root{--ink:#172e35;--deep:#183b40;--muted:#617177;--paper:#f4f2ec;--white:#fffefa;--line:#d4ddd7;--coral:#b95f48;--teal:#287669;--cream:#e9eee8}
*{box-sizing:border-box}html{background:#e4e8e2}body{margin:0;color:var(--ink);background:var(--paper);font:14px/1.5 "Avenir Next",Avenir,"Segoe UI",sans-serif}
.sheet{width:min(1120px,100% - 40px);margin:28px auto;padding:36px 42px 30px;background:var(--white);box-shadow:0 16px 52px #153b4018}
.masthead{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:15px;border-bottom:1px solid var(--ink)}.brand{font-size:22px;font-weight:800;letter-spacing:-.06em}.brand-mark{display:inline-grid;place-items:center;width:27px;height:27px;margin-right:8px;border:2px solid var(--coral);color:var(--coral);vertical-align:middle}.mast-meta{text-align:right;color:var(--muted);font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}
.hero{margin-top:20px;padding:27px 30px;background:var(--deep);color:#f6f4eb}.eyebrow,.section-label,.card-kicker{font-size:10px;font-weight:800;letter-spacing:.15em;text-transform:uppercase;color:var(--coral)}.hero .eyebrow{color:#efb39f}.hero h1{max-width:800px;margin:10px 0;font:normal clamp(28px,4vw,39px)/1.1 Georgia,serif;letter-spacing:-.04em}.hero p{max-width:800px;margin:0;color:#d7e2dd;font-size:13px}
.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin:0 0 28px;border-bottom:1px solid var(--line)}.metric{min-width:0;padding:17px 15px 18px 0}.metric+.metric{padding-left:16px;border-left:1px solid var(--line)}.metric-label{display:block;min-height:30px;color:var(--muted);font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.metric strong{display:block;margin-top:4px;font:normal clamp(20px,2.8vw,28px)/1.15 Georgia,serif;overflow-wrap:anywhere}.metric small{display:block;margin-top:6px;color:var(--muted);font-size:10px;line-height:1.4}
.section{margin-top:29px}.section-head{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:12px}.section-head h2{margin:4px 0 0;font:normal 25px/1.15 Georgia,serif;letter-spacing:-.025em}.section-head p{max-width:480px;margin:0;color:var(--muted);font-size:11px}.table-scroll{width:100%;overflow-x:auto;border:1px solid var(--line);background:white}
table{width:100%;border-collapse:collapse;text-align:left;font-size:11px}th{padding:10px 9px;background:var(--deep);color:white;font-size:9px;letter-spacing:.08em;text-transform:uppercase}td{padding:10px 9px;border-bottom:1px solid #e2e7e2;vertical-align:top}tbody tr:nth-child(even){background:#f7f8f3}td small{display:block;margin-top:3px;color:var(--muted);font-size:9px}.pair-arrow{color:var(--coral);font-weight:800}.evidence-tag{display:inline-block;padding:3px 6px;border-radius:3px;font-size:9px;font-weight:800;line-height:1.3}.evidence-tag.source{background:#e4f0ea;color:#1d644f}.evidence-tag.demo{background:#f6ebdc;color:#895526}.table-note,.footnote{margin:9px 0 0;color:var(--muted);font-size:10px;line-height:1.5}.empty-state,.map-empty{padding:16px;border:1px dashed var(--line);color:var(--muted);font-size:12px}
.comparison-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.project-card{padding:17px;border:1px solid var(--line);background:#fbfaf5;overflow-wrap:anywhere}.project-card h3{margin:9px 0 3px;font-size:13px}.project-name{min-height:36px;margin:0 0 11px;font:normal 17px/1.25 Georgia,serif}.project-card dl{margin:0}.project-card dl div{display:grid;grid-template-columns:minmax(105px,.75fr) 1.25fr;gap:8px;padding:7px 0;border-top:1px solid #e2e7e2;font-size:10px}.project-card dt{color:var(--muted)}.project-card dd{margin:0;font-weight:600}.source-action{margin:10px 0 0;font-size:10px;font-weight:800}a{color:#8c4937;text-underline-offset:3px;overflow-wrap:anywhere}
.map-grid{stroke:#cbd8d1;stroke-width:1;stroke-dasharray:2 7}.map-land{fill:#eaf0e9}.endpoint-link{stroke:#a21caf;stroke-width:3;stroke-dasharray:6 7}.endpoint-halo{fill:#f2d8ee}.endpoint-dot{fill:#a21caf;stroke:white;stroke-width:3}.map-label{fill:#20363b;font:700 11px "Segoe UI",sans-serif}.map-coordinate{fill:#627279;font:9px "Segoe UI",sans-serif}.map-distance{fill:#78396f;font:700 10px "Segoe UI",sans-serif}.schematic{margin:0;border:1px solid var(--line);background:#f9faf6}.schematic figcaption{display:flex;justify-content:space-between;gap:10px;padding:11px 13px;border-bottom:1px solid var(--line);font-size:10px;font-weight:800;letter-spacing:.07em;text-transform:uppercase}.schematic figcaption span:last-child{color:var(--muted);font-size:9px}.schematic svg{display:block;width:100%;height:auto;min-height:190px}.schematic>p{margin:0;padding:0 13px 12px;color:var(--muted);font-size:10px}
.recommendation{padding:17px 19px;border-left:3px solid var(--coral);background:#f5f0e7}.recommendation h2{margin:5px 0 7px;font:normal 23px Georgia,serif}.recommendation p{margin:0;color:#46595d;font-size:12px;line-height:1.6}
.ai-interpretation{padding:14px 17px;border-top:1px solid var(--line);background:#f7f8f3}.ai-interpretation p{margin:7px 0;color:#46595d;font-size:12px;line-height:1.6}.ai-interpretation small{color:var(--muted);font-size:10px}
.risk-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.risk-band{display:grid;grid-template-columns:12px 1fr auto;align-items:center;gap:4px 8px;padding:9px;border:1px solid var(--line);border-radius:5px;background:#fbfaf5;font-size:10px}.risk-band .swatch{grid-row:span 2;width:11px;height:11px;border-radius:50%}.swatch.red{background:#b42318}.swatch.orange{background:#d97706}.swatch.yellow{background:#ca8a04}.swatch.green{background:#16805d}.risk-band span:nth-of-type(2){color:var(--muted);font-size:9px}.risk-band strong{grid-column:2/4;font:normal 16px Georgia,serif}.disclaimer{margin-top:10px;padding:10px 12px;background:#f5eee3;color:#72573e;font-size:10px;line-height:1.5}
details.appendix{margin-top:31px;border-top:1px solid var(--ink);border-bottom:1px solid var(--line)}details.appendix>summary{display:flex;align-items:center;justify-content:space-between;gap:15px;min-height:54px;cursor:pointer;font-weight:800;list-style:none}details.appendix>summary::-webkit-details-marker{display:none}details.appendix>summary:after{content:"+";font-size:20px;color:var(--coral)}details.appendix[open]>summary:after{content:"−"}.appendix-content{padding:5px 0 18px}.appendix-content h3{margin:19px 0 8px;font:normal 19px Georgia,serif}.appendix-content p{color:var(--muted);font-size:10px}.appendix-content table{min-width:700px}.appendix-content .table-scroll{margin-bottom:12px}
footer{display:flex;justify-content:space-between;gap:20px;margin-top:25px;padding-top:10px;border-top:1px solid var(--ink);color:var(--muted);font-size:9px;letter-spacing:.06em}
@media(max-width:760px){.sheet{width:100%;margin:0;padding:22px 17px;box-shadow:none}.masthead{align-items:flex-start}.metrics{grid-template-columns:1fr 1fr}.metric:nth-child(3){padding-left:0;border-left:0;border-top:1px solid var(--line)}.metric:nth-child(4){border-top:1px solid var(--line)}.comparison-grid{grid-template-columns:1fr}.section-head{display:block}.section-head p{margin-top:7px}.risk-grid{grid-template-columns:1fr 1fr}.hero{padding:22px}.schematic figcaption{display:block}.schematic figcaption span:last-child{display:block;margin-top:3px}}
@page{size:letter;margin:.5in}
@media print{html,body{background:white}.sheet{width:100%;margin:0;padding:0;box-shadow:none}.hero,.project-card,.recommendation,.risk-band{break-inside:avoid}.table-scroll{overflow:visible;border:0}table{font-size:9px}th,td{padding:6px 5px}.opportunity-table{table-layout:fixed}.appendix-content{display:block!important}details.appendix:not([open])>.appendix-content{display:block!important}details.appendix>summary:after{display:none}a{color:inherit;text-decoration:none}.schematic svg{max-height:260px}.metrics{grid-template-columns:repeat(4,minmax(0,1fr))}.comparison-grid{grid-template-columns:1fr 1fr}footer{margin-top:16px}}
</style>
</head>
<body>
<main class="sheet">
  <header class="masthead"><div class="brand"><span class="brand-mark" aria-hidden="true">G</span>GridLock</div><div class="mast-meta">${isTechnical ? 'Technical detail report' : 'Executive coordination report'}<br>Resilience Impact Analysis · ${stormMode ? 'Scenario on' : 'Scenario off'}</div></header>
  <section class="hero"><div class="eyebrow">UTILITY PLANNING / ${isTechnical ? 'EVIDENCE REVIEW' : 'DECISION BRIEF'}</div><h1>${pair ? 'Coordination opportunities to verify' : 'Planning evidence and data gaps'}</h1><p>Point proximity and sample records support screening questions only. This report does not establish shared construction, engineering risk, customer exposure, outages, or realized savings.</p></section>
  <section class="metrics" aria-label="Evidence summary">
    <div class="metric"><span class="metric-label">Sourced endpoint pairs</span><strong>${formatCount(verifiedPairs.length)}</strong><small>Independently named endpoints; proximity only</small></div>
    <div class="metric"><span class="metric-label">Demo center candidates</span><strong>${formatCount(demoOpportunities.length)}</strong><small>Unverified sample coordinates</small></div>
    <div class="metric"><span class="metric-label">Listed demo facilities</span><strong>${formatCount(facilityCount)}</strong><small>Facility records in the loaded sample</small></div>
    <div class="metric"><span class="metric-label">Customers / outages</span><strong>Not assessed</strong><small>No served-customer or outage-impact data supplied</small></div>
  </section>
  <section class="section">
    <div class="section-head"><div><div class="section-label">01 / REVIEW LIST</div><h2>Coordination pairs for review</h2></div><p>Source-linked pairs and demo candidates are separated. No priority, readiness, risk, or savings ranking is produced.</p></div>
    ${opportunityTable(rows)}
  </section>
  <section class="section">
    <div class="section-head"><div><div class="section-label">02 / PROJECT COMPARISON</div><h2>${pair ? 'Compare the selected named endpoints' : 'No sourced pair available'}</h2></div><p>${pair ? 'One independently identified point represents each project; full routes and construction scope are not established.' : 'Submitted workbook and demo-only records are not promoted to source-verified projects.'}</p></div>
    ${pair ? `<div class="comparison-grid">${comparisonCard(pair.d, 'A')}${comparisonCard(pair.g, 'B')}</div>` : '<p class="empty-state">No source-linked named-endpoint pair is available for project comparison.</p>'}
  </section>
  <section class="section">
    <div class="section-head"><div><div class="section-label">03 / LOCATION CONTEXT</div><h2>Schematic endpoint snapshot</h2></div><p>Source-linked map evidence only; no live map tiles or external assets are embedded in this download.</p></div>
    ${schematicMap(pair)}
  </section>
  <section class="section recommendation"><div class="section-label">04 / RECOMMENDED NEXT STEP</div><h2>Validate before estimating benefits</h2><p>${escapeHtml(recommendations)}</p></section>
  ${!isTechnical && safeInterpretation ? `<section class="section ai-interpretation"><div class="section-label">SUPPLEMENTAL PLANNING NOTE</div><p>${escapeHtml(safeInterpretation)}</p><small>${shown(interpretationSource, 'Evidence-based fallback; confirm against cited records.')}</small></section>` : ''}
  <section class="section">
    <div class="section-head"><div><div class="section-label">05 / RESILIENCE SCREEN</div><h2>Scenario corridor proximity</h2></div><p>${stormMode ? `${formatCount(corridorCount)} of ${formatCount(facilityCount)} listed demo facilities are within 20 km of the simulated corridor.` : 'Scenario is off. Corridor-distance categories describe a deterministic what-if path, not a weather forecast.'}</p></div>
    <div class="risk-grid">${bandCards}</div>
    <div class="disclaimer">Color bands show straight-line distance from a simulated corridor only: red ≤5 km, orange &gt;5–10 km, yellow &gt;10–20 km, green &gt;20 km. They are not measured hazard levels, outage likelihood, customer impact, or dispatch priorities. ${formatCount(submittedCandidates.length)} submitted workbook candidates are kept separate and unverified.</div>
  </section>
  <details class="appendix">
    <summary>View Technical Details</summary>
    <div class="appendix-content">
      <h3>Source-linked named-endpoint pairs (${formatCount(verifiedPairs.length)})</h3>
      <p>A single located endpoint per project establishes point proximity only. It does not establish the full route, electrical connection, construction overlap, or shared scope.</p>
      <div class="table-scroll"><table><thead><tr><th>Project pair</th><th>Endpoint A and evidence</th><th>Endpoint B and evidence</th><th>Distance</th><th>Dates / gap</th><th>Filing links</th></tr></thead><tbody>${sourcedAppendixRows(verifiedPairs)}</tbody></table></div>
      <h3>Demo center candidates (${formatCount(demoOpportunities.length)})</h3>
      <p>These rows use demonstration coordinates and must not be described as source-verified overlaps.</p>
      <div class="table-scroll"><table><thead><tr><th>Demo pair</th><th>Utilities</th><th>Sample centers</th><th>Distance</th><th>Exact date gap</th><th>Location confidence</th></tr></thead><tbody>${demoAppendixRows(demoOpportunities)}</tbody></table></div>
      <h3>Submitted workbook candidates (${formatCount(submittedCandidates.length)})</h3>
      <p>Workbook values are reproduced separately and have not been independently verified against current utility filings or mapped as source-linked pairs.</p>
      <div class="table-scroll"><table><thead><tr><th>Candidate pair</th><th>Workbook distance</th><th>Workbook date gap</th><th>Evidence status</th></tr></thead><tbody>${submittedAppendixRows(submittedCandidates)}</tbody></table></div>
      <h3>Not assessed / not estimated</h3>
      <p>Served customers, customer interruptions, outage probability, measured flood or wind hazard, storm surge, hurricane frequency, electrically connected critical facilities, shared infrastructure, route intersection, contractor availability, project savings and schedule acceleration are not established by the loaded evidence.</p>
      <p>Scenario colors are computed from distance to the deterministic simulated corridor. Facility counts refer to the loaded demo facility records only. Coastal-area screening proxies, where shown in the app, are not measured hazard layers.</p>
    </div>
  </details>
  <footer><span>GRIDLOCK / PLANNING SCREEN · NOT ENGINEERING VALIDATION</span><span>Generated ${escapeHtml(dateText)} · ${distance} · Date gap ${dateGap}</span></footer>
</main>
</body>
</html>`;
}