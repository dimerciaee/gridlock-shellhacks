import { formatDistanceMiles } from './data-utils.js';

export function evidenceNarrative(pair) {
  if (!pair) {
    return 'No source-linked endpoint pair is available. Verify the utility filings and location evidence before recommending a joint review.';
  }
  const gap = Number.isFinite(pair.inServiceDateGapDays)
    ? `${pair.inServiceDateGapDays} days apart`
    : 'not yet comparable';
  return `GridLock identified a coordination screening candidate between ${pair.d.name} and ${pair.g.name}. Their independently located named endpoints are ${formatDistanceMiles(pair.distMiles)} miles apart, and their planned in-service dates are ${gap}. The utilities could compare full project footprints, work scopes, and schedules to see whether staging, permitting, or mobilization can be coordinated. Shared construction work, savings, and schedule gains have not been established.`;
}

export async function getExecutiveNarrative(pair, { fetchImpl = fetch, timeoutMs = 8000 } = {}) {
  const fallback = {
    narrative: evidenceNarrative(pair),
    narrativeSource: pair ? 'Evidence-based template fallback · AI unavailable' : 'Evidence-based draft · no sourced pair',
  };
  if (!pair) return fallback;

  const prompt = [
    'You are drafting one concise (65–85 word) executive paragraph for an electric-utility coordination screening brief.',
    `Projects: ${pair.d.name} and ${pair.g.name}.`,
    `Only one named endpoint per project was independently located. Endpoint separation: ${formatDistanceMiles(pair.distMiles)} miles. Planned in-service dates: ${pair.d.inServiceDate} and ${pair.g.inServiceDate}; gap ${pair.inServiceDateGapDays} days.`,
    'Explain why this warrants a joint review of full routes, schedules and scope, and how coordination might avoid duplicate staging or mobilization.',
    'Do not say full routes overlap, schedules are compatible, project costs are known, utilities have agreed, or savings/schedule gains are established. Do not invent numbers or make FERC compliance claims. One paragraph only.',
  ].join('\n');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl('/api/ai/explain-overlap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
      signal: controller.signal,
    });
    if (!response.ok) return fallback;
    const data = await response.json();
    if (typeof data.explanation !== 'string' || !data.explanation.trim()) return fallback;
    return {
      narrative: data.explanation.trim(),
      narrativeSource: 'AI-assisted draft · verify before circulation',
    };
  } catch {
    return fallback;
  } finally {
    clearTimeout(timeout);
  }
}