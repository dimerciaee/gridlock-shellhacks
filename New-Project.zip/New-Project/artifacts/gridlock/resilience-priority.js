// A transparent planning screen, not an engineering or emergency-dispatch model.
// Maximum possible score: 30 + 10 + 20 + 25 + 15 + 20 = 120.
export const RESILIENCE_MAX = 120;

export const DOCUMENTED_BUDGETS = Object.freeze([
  {
    name: 'Dawson 230kV Sub and Fold-in: Construct and Rebuild',
    aliases: ['Dawson 230kV Substation'],
    filingProjectId: '6859',
    listingNumber: 34,
    amount: 93_500_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 34 (project ID 6859). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Wateree-Killian 230kV: Rebuild',
    aliases: ['Wateree-Killian 230kV Rebuild'],
    filingProjectId: '6808 R',
    listingNumber: 9,
    amount: 48_200_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 9 (project ID 6808 R). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Yemassee– Ritter 230kV #1 & #2: Construct SPDC with B-1272',
    aliases: ['Yemassee-Ritter 230kV #1 & #2'],
    filingProjectId: '6359',
    listingNumber: 21,
    amount: 40_600_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 21 (project ID 6359). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Okatie-Bluffton 115kV: Rebuild',
    aliases: ['Okatie-Bluffton 115kV Rebuild'],
    filingProjectId: '6808 S',
    listingNumber: 10,
    amount: 40_660_000,
    rounded: false,
    citation: 'User-supplied pasted Dominion Energy South Carolina 5 Year Budget, project 10 of 44, Total Estimated Project Cost. Verify against the current filing.',
  },
  {
    name: 'Canadys-Ritter 115KV-Rebld SPDC 230/115KV 1272 (Approx 18 Miles)',
    aliases: ['Canadys-Ritter 115kV Rebuild'],
    filingProjectId: '06076A',
    listingNumber: 20,
    amount: 40_000_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 20 (project ID 06076A). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Riverport Tap: Construct Tap',
    aliases: ['Riverport Tap'],
    filingProjectId: '06367 A - C, H',
    listingNumber: 22,
    amount: 34_900_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 22 (project ID 06367 A - C, H). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Church Creek – Faber Place – Charleston Transmission: Add 230kV Line',
    aliases: ['Church Creek-Faber Place-Charleston Transmission'],
    filingProjectId: '6847 A-B, D-H',
    listingNumber: 39,
    amount: 34_200_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 39 (project ID 6847 A-B, D-H). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Jasper – Okatie 230 kV #2: Construct',
    aliases: ['Jasper-Okatie 230 kV #2 Construct'],
    filingProjectId: '06367 D - G',
    listingNumber: 23,
    amount: 23_787_423,
    rounded: false,
    citation: 'User-supplied pasted Dominion Energy South Carolina 5 Year Budget, project 23 of 44, Total Estimated Project Cost. Verify against the current filing.',
  },
  {
    name: 'Scout 230 kV Sub and Fold-in: Construct',
    aliases: ['Scout 230 kV Substation and Fold-in'],
    filingProjectId: '6853 B-F',
    listingNumber: 33,
    amount: 23_700_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 33 (project ID 6853 B-F). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Cainhoy 115 kV Tap: Construct',
    aliases: ['Cainhoy Tap'],
    filingProjectId: '0147 C, K',
    listingNumber: 37,
    amount: 21_900_000,
    rounded: true,
    citation: 'User-supplied Dominion Energy South Carolina 5 Year Budget snapshot, matched to source inventory listing 37 (project ID 0147 C, K). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Stevens Creek - Hooks 115kV/LR Plumb Branch 46kV Rebuilds',
    aliases: ['Stevens Creek-Hooks Rebuild'],
    filingProjectId: '6809 E',
    listingNumber: 14,
    amount: 11_745_543,
    rounded: false,
    citation: 'User-supplied Dominion Energy South Carolina budget snapshot for the Stevens Creek–Hooks rebuild, matched to source inventory listing 14 (project ID 6809 E). Original budget-page reference was not supplied; verify the project scope against the current filing.',
  },
  {
    name: 'Hooks - Thurmond 115kV Tie: Rebuild',
    aliases: ['Hooks-Thurmond Tie Rebuild'],
    filingProjectId: '6810 A',
    listingNumber: 31,
    amount: 2_200_080,
    rounded: false,
    citation: 'User-supplied Dominion Energy South Carolina budget snapshot for the Hooks–Thurmond tie rebuild, matched to source inventory listing 31 (project ID 6810 A). Original budget-page reference was not supplied; verify against the current filing.',
  },
  {
    name: 'Okatie 230-115kV Substation, Jasper – Yemassee 230kV #1 Fold-in',
    aliases: ['Okatie 230-115kV Substation'],
    filingProjectId: '0139 M,N',
    listingNumber: 3,
    amount: 11_116_933,
    rounded: false,
    citation: 'User-supplied Dominion Energy South Carolina budget snapshot for the Okatie 230–115kV substation, matched to source inventory listing 3 (project ID 0139 M,N). Original budget-page reference was not supplied; verify the project scope against the current filing.',
  },
  {
    name: 'Urquhart – Toolebeck 115kV line: Rebuild',
    aliases: ['Urquhart-Toolebeck Rebuild'],
    filingProjectId: '6852',
    listingNumber: 35,
    amount: 17_520_000,
    rounded: false,
    citation: 'User-supplied Dominion Energy South Carolina budget snapshot, matched to source inventory listing 35 (project ID 6852). Original budget-page reference was not supplied; verify against the current filing.',
  },
]);

export function budgetForProject(project) {
  if (!project) return null;
  const normalize = (value) => String(value)
    .normalize('NFKD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/[^a-z0-9]/gi, '')
    .toLowerCase();
  const projectId = project.filingProjectId || project.projectId;
  if (projectId) {
    return DOCUMENTED_BUDGETS.find((entry) => normalize(projectId) === normalize(entry.filingProjectId)) || null;
  }
  if (typeof project.name !== 'string') return null;
  const normalizedName = normalize(project.name);
  return DOCUMENTED_BUDGETS.find((entry) =>
    [entry.name, ...(entry.aliases || [])].some((name) => normalize(name) === normalizedName)) || null;
}

export function isCoastalPlanningArea(point) {
  if (!point || !Number.isFinite(point.lat) || !Number.isFinite(point.lon)) return null;
  // Broad GA/SC coastal screening region only. Not a FEMA flood zone, storm
  // surge map, hurricane-frequency measurement, or wind-speed model.
  return point.lat >= 30.8 && point.lat <= 33.2 && point.lon >= -81.65 && point.lon <= -79.4;
}

export function calculateResiliencePriority({
  distanceMiles,
  timeGapDays = null,
  budgets = [],
  infrastructureLinked = null,
  nearCriticalSite = null,
  coastalArea = null,
}) {
  const finiteNonnegative = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0;
  const validBudgets = budgets.filter(finiteNonnegative);
  const parts = {
    distanceScore: finiteNonnegative(distanceMiles)
      ? distanceMiles > 25 ? 0 : distanceMiles < 5 ? 30 : distanceMiles < 10 ? 20 : 10
      : null,
    infrastructureScore: typeof infrastructureLinked === 'boolean' ? (infrastructureLinked ? 10 : 0) : null,
    timelineScore: finiteNonnegative(timeGapDays) ? (timeGapDays < 180 ? 20 : 0) : null,
    costScore: validBudgets.some((value) => value > 30_000_000)
      ? 25 : validBudgets.length >= 2 ? 0 : null,
    criticalityScore: typeof nearCriticalSite === 'boolean' ? (nearCriticalSite ? 15 : 0) : null,
    weatherRiskScore: typeof coastalArea === 'boolean' ? (coastalArea ? 20 : 0) : null,
  };
  return {
    parts,
    knownTotal: Object.values(parts).reduce((total, value) => total + (value ?? 0), 0),
    assessed: Object.values(parts).filter((value) => value !== null).length,
    missing: Object.entries(parts).filter(([, value]) => value === null).map(([key]) => key),
    maxPossible: RESILIENCE_MAX,
  };
}