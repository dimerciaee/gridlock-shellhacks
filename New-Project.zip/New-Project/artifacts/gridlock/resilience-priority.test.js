import assert from 'node:assert/strict';
import test from 'node:test';
import {
  budgetForProject, calculateResiliencePriority, DOCUMENTED_BUDGETS,
  isCoastalPlanningArea, RESILIENCE_MAX,
} from './resilience-priority.js';

test('requested score thresholds produce 120 possible points without double-counting', () => {
  const score = calculateResiliencePriority({
    distanceMiles: 4.99, timeGapDays: 179, budgets: [40_660_000],
    infrastructureLinked: true, nearCriticalSite: true, coastalArea: true,
  });
  assert.equal(score.knownTotal, 120);
  assert.equal(score.maxPossible, RESILIENCE_MAX);
  assert.equal(score.assessed, 6);
  assert.deepEqual(score.missing, []);
  assert.equal(calculateResiliencePriority({ distanceMiles: 5, timeGapDays: 180 }).knownTotal, 20);
  assert.equal(calculateResiliencePriority({ distanceMiles: 10, timeGapDays: 180 }).knownTotal, 10);
});

test('unknown budgets or hazard layers do not become zero-point findings', () => {
  const score = calculateResiliencePriority({
    distanceMiles: 3.02, timeGapDays: 183,
    budgets: [23_787_423], coastalArea: true,
  });
  assert.equal(score.knownTotal, 50);
  assert.equal(score.parts.costScore, null);
  assert.equal(score.parts.infrastructureScore, null);
  assert.equal(score.parts.criticalityScore, null);
  assert.deepEqual(score.missing, ['infrastructureScore', 'costScore', 'criticalityScore']);
  assert.equal(calculateResiliencePriority({ distanceMiles: null }).parts.distanceScore, null);
});

test('submitted Dominion budget snapshots match only their exact project IDs or names', () => {
  assert.equal(budgetForProject({ name: 'Okatie-Bluffton 115 kV: Rebuild' })?.amount, 40_660_000);
  assert.equal(budgetForProject({ filingProjectId: '06367 D - G' })?.amount, 23_787_423);
  assert.equal(budgetForProject({ projectId: '6859' })?.amount, 93_500_000);
  assert.equal(budgetForProject({ filingProjectId: '0147 C, K' })?.amount, 21_900_000);
  assert.equal(budgetForProject({ name: 'Hooks-Thurmond Tie Rebuild' })?.amount, 2_200_080);
  assert.equal(budgetForProject({
    filingProjectId: 'UNMATCHED',
    name: 'Okatie-Bluffton 115 kV: Rebuild',
  }), null);
  assert.equal(DOCUMENTED_BUDGETS.length, 14);
  assert.equal(DOCUMENTED_BUDGETS.reduce((sum, entry) => sum + entry.amount, 0), 444_029_979);
  assert.equal(DOCUMENTED_BUDGETS.filter((entry) => entry.rounded).length, 8);
  assert.equal(budgetForProject({ name: 'Other project' }), null);
  assert.equal(isCoastalPlanningArea({ lat: 32.3, lon: -81.1 }), true);
  assert.equal(isCoastalPlanningArea(null), null);
});