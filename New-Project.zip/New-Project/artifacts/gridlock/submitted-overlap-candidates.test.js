import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const candidates = JSON.parse(
  readFileSync(new URL('./public/submitted-overlap-candidates.json', import.meta.url), 'utf8'),
);

test('submitted pairs retain the workbook values without publishing coordinates', () => {
  assert.deepEqual(
    candidates.map(({ id, descId, gpcId, distanceMiles, dateGapDays }) => [
      id, descId, gpcId, distanceMiles, dateGapDays,
    ]),
    [
      ['OVL_1', 'DESC_2', 'GPC_1', 4.09, 3074],
      ['OVL_2', 'DESC_3', 'GPC_2', 5.65, 152],
      ['OVL_3', 'DESC_3', 'GPC_3', 7.55, 517],
      ['OVL_4', 'DESC_1', 'GPC_1', 8.01, 3074],
      ['OVL_5', 'DESC_5', 'GPC_2', 14.34, 365],
      ['OVL_6', 'DESC_5', 'GPC_3', 14.81, 730],
    ],
  );
  assert(candidates.every((candidate) =>
    Object.keys(candidate).every((key) => !/lat|lon|center/i.test(key)),
  ));
});