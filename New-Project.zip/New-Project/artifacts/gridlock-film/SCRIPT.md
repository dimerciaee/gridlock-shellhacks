# GridLock: Ready Before the Storm

## Director’s treatment

- **Promise:** GridLock connects overlapping utility work with nearby critical facilities so teams can coordinate before severe weather. This film shows a simulated storm route and labels the recommendation engine as a local, rules-based demo.
- **Identity:** Use the project's map colors: DESC blue `#2563eb`, GPC green `#15803d`, humanitarian pink `#ec4899`, overlap blue `#2563eb`, storm-priority red `#dc2626`, simulated route purple `#8b5cf6`, and vulnerable-zone orange `#f97316`. Build contrast with ink `#101a2b` and warm map paper `#f6f4ed`. Display: Space Grotesk; supporting copy: DM Sans; data labels: JetBrains Mono. The GridLock name is a typeset wordmark, not a fabricated logo.
- **Hero:** A stylized storm front approaches across a schematic Southeast Georgia map as a simulated route traces beneath it. A brief lightning flash and two-second thunder accent establish urgency; the scene then hands off through a matching node to an illustrated connector between the Jasper Transmission Upgrade (DESC) and Plant McIntosh Expansion (GPC).
- **Motion:** Move the illustrated storm front toward the map center and punctuate it with a localized lightning flash; trace the route and project connector as animated SVG; expand the shared-center ring; carry it into the site halo and use that halo to open the recommendation card. Move an orange rule into the end-card underline, then expand an aperture anchored to the `o` in `GridLock`.
- **Arc:** Ominous, fast hook → clear regional overview → close human-impact detail → deliberate, useful recommendation → quiet, high-contrast brand resolution.
- **Payoff:** The dense map collapses into a readable GridLock lockup and the exact product statement. A visible “LOCAL AI DEMO · RULES-BASED” disclosure keeps the current demo behavior clear.

**Format and runtime:** 4:5 portrait, composed for a 1080 × 1350 canvas with 7% side and 9% top/bottom safe insets. Runtime is 26.00 seconds across five shots. No narration; Shot 01 has one restrained two-second thunder accent mixed into the single composite soundtrack.

**Verified project facts:** Jasper Transmission Upgrade is DESC, 2026–2028; Plant McIntosh Expansion is GPC, 2025–2027. Their mapped points are 32.8 km apart and their scheduled windows overlap. The local demo finds three humanitarian sites within 20 km of either project: Savannah General Hospital, Riverfront Care Center, and Savannah Fire Station #3. Storm-path visuals are explicitly marked as simulated.

**Sound:** An original 96 BPM cinematic instrumental aims for a restrained, heroic rise with warm strings and brass, a steady pulse, and no vocals. One generated two-second thunder rumble follows the opening lightning flash. The soundtrack received a gain-only +28 dB remaster after signal analysis found the source level unusually low. In response to a request to check phone and desktop playback, the listener described the updated track as “smooth”; no separate loudness rating or beat-alignment assessment was provided. No narration or additional sound effects.

## Timeline overview

| Time | Focus | Main motion | Composition | Handoff |
| --- | --- | --- | --- | --- |
| 0.00–4.50 | “BEFORE THE STORM.”, an approaching simulated storm front, and the route | Cloud front advances; lightning flashes as the route traces; a two-second thunder roll follows; the endpoint ring expands in the final 0.75s | Dark, asymmetric type over a narrow schematic map | Purple endpoint matches the incoming overlap ring as the paper map wipes in |
| 4.50–9.75 | Two projects 32.8 km apart | Utility labels and connector resolve; the center ring expands and fades | Bright, stylized coastal map with labels in opposing zones | Center ring aligns with the site halo; the next shot opens through a circular reveal |
| 9.75–15.00 | Three nearby critical facilities | Three markers pulse; one fixed caption changes; the orange zone and halo grow | Dark, schematic site cluster, not a geographic close-up | Pink halo turns orange and opens the recommendation card around the same center |
| 15.00–21.00 | Explainable local recommendation | Priority, metric, and four rules-based guidance rows resolve; card fades as panels open | Pale recommendation card on an ink field | Orange rule moves from the card's lower edge to the end-card underline as paper panels meet |
| 21.00–26.00 | GridLock and its takeaway | Plain-text wordmark resolves; exact statement appears; the “o” ring expands | Warm paper end card, centered and spacious | Blue underline holds through the cut; the expanding ring hands off to the opening's dark field |

## Complete shot script

### Shot 01 / 0.00–4.50s / 4.50s — “BEFORE THE STORM.”

**Purpose:** Establish urgency with a stylized approaching storm while making clear that the route and storm visuals are simulated, not live weather data.

**Exact content and holds:** Show `GRIDLOCK · INFRASTRUCTURE COORDINATION`, `BEFORE`, and `THE STORM.`; the eyebrow and `BEFORE` are present immediately, with `THE STORM.` resolving at 0.42s. At 0.35s, reveal `SIMULATED STORM PATH`. At 0.80s, reveal `SOUTHEAST GEORGIA` in the map area. Keep all labels visible through the outgoing move.

**Composition and artistic idea:** A near-black ink field holds a thin, abstract coastline contour and a sparse, schematic map. A restrained blue-gray vector storm front moves in from frame right across the lower-right map area; one localized white-violet lightning stroke flashes from it without washing out the headline. The headline owns the upper two-thirds, offset slightly left; the violet dashed route crosses the lower third and terminates near 47% frame width, 55% frame height. Its endpoint is the handoff point, not a live weather marker. All weather geometry is illustrative, with no realistic radar styling or live-data implication.

**Timed choreography:** 0.00s: the ink field, eyebrow, headline, and map are present—no blank first frame. At 0.25s the route starts tracing; at 0.35s the simulation label arrives; `THE STORM.` resolves at 0.42s. From 0.35–2.70s, the vector storm front advances from the right. A localized lightning flash strikes at 0.78s with one short after-flash; the two-second thunder rumble begins at 0.92s. At 0.80s the regional locator appears. The route finishes at about 1.80s and its endpoint pulses from 1.20s. The storm settles into a slow drift while the endpoint ring holds, then scales up and blurs from about 3.74s to the cut. The following shot wipes in from the left with its purple overlap ring aligned to this node.

**Transition contract:** The route endpoint sits at the same relative position as Shot 02's overlap ring. Its final expansion and fade overlap the incoming left-to-right map wipe; the incoming ring begins violet and changes to blue. The shot does not use a diagonal panel or a second route-node position.

**Assets and technique:** Programmatic SVG coastline, coordinate grid, dashed route, storm-cloud silhouette, and lightning stroke; one generated thunder effect mixed with the instrumental as a single export-safe track; Space Grotesk display type; no external imagery. `SIMULATED STORM PATH` remains visible, and the route label stays legible inside the safe area.

**Sound:** The original 96 BPM heroic instrumental begins with a restrained pulse. A generated two-second thunder effect begins at 0.92s after the localized lightning flash and remains mixed into the single composite soundtrack; no narration or additional sound effects.

### Shot 02 / 4.50–9.75s / 5.25s — “TWO UTILITIES. ONE WORK ZONE.”

**Purpose:** Show the actual DESC and GPC project relationship and its measurable distance.

**Exact content and holds:** The `SHARED WORK WINDOW · COASTAL GEORGIA` kicker is visible as the map wipes in. Reveal `TWO UTILITIES.` at 4.68s and `ONE WORK ZONE.` at 4.96s. At 5.32s reveal `DESC` beside `Jasper Transmission Upgrade`; at 5.65s reveal `GPC` beside `Plant McIntosh Expansion`. At 6.78s show `32.8 KM APART`. Keep the project names and distance visible through the end.

**Composition and artistic idea:** Switch to a warm-paper, stylized coastal map with thin ink roads and two project markers. The map is an illustration, not a navigational basemap; the project names, overlapping dates, and 32.8 km measurement are project facts. DESC is blue and GPC is green, matching the app legend. The headline owns a narrow top band; project labels sit in opposing map zones. The connecting line and its center ring are the hero.

**Timed choreography:** The purple node appears under the incoming left-to-right wipe and changes to blue. The two project markers arrive at 0.82s and 1.15s; the connector draws from 1.52s; the distance capsule resolves at 2.28s. The headline resolves in two beats at 0.18s and 0.46s. The center ring holds blue through most of the shot, then expands and fades in the final 20% as the site cluster arrives.

**Transition contract:** The center ring aligns with the incoming site halo at approximately 46.5% width and 55% height. Its final scale-through and fade lead into Shot 03's circular aperture; the new halo appears at the same center.

**Assets and technique:** Programmatic SVG map, roads, and connector. The shot does not claim exact map geometry; local project data supplies names, utility categories, overlapping years, and distance. No map tile screenshot is used.

**Sound:** The restrained pulse continues as the distance resolves. Beat alignment is unverified.

### Shot 03 / 9.75–15.00s / 5.25s — “THREE NEARBY CRITICAL SITES.”

**Purpose:** Shift attention from infrastructure to the facilities and communities affected by coordination.

**Exact content and holds:** Show `THREE NEARBY` and `CRITICAL SITES.` above a fixed caption slot. At 10.90s show `SAVANNAH GENERAL HOSPITAL`; at 11.95s replace it with `RIVERFRONT CARE CENTER`; at 13.00s replace it with `SAVANNAH FIRE STATION #3`; at 14.05s replace it with `WITHIN 20 KM OF EITHER PROJECT`. The lower legend reads `HOSPITAL · CARE CENTER · FIRE STATION`. Keep the caption visible through the outgoing move.

**Composition and artistic idea:** Cut from the bright regional map to a dark, schematic site cluster, not a geographic close-up. The matched blue ring becomes a pink halo. Three distinct site markers pulse in the cluster; a large `03` count, headline, fixed changing caption, and lower site-type legend provide context. Orange vulnerable-zone geometry stays behind and distinct from the pink facilities. The display names and 20 km claim come from the local project data; marker positions are illustrative.

**Timed choreography:** The circular aperture opens on the site cluster. The care, fire, and hospital markers pulse at 0.65s, 1.00s, and 1.35s. The hospital caption appears at 1.15s; the care-center caption at 2.20s; the fire-station caption at 3.25s; the radius statement at 4.30s. Captions exit before their replacements enter. The orange vulnerability-zone geometry grows behind the cluster. The halo expands and changes from pink to orange through the end of the shot.

**Transition contract:** The orange halo at approximately 46.5% width and 55% height becomes the aperture for Shot 04's pale recommendation card. The same center and color carry into the card reveal.

**Assets and technique:** Procedural facility markers, deterministic pulse timing, and restrained orange vulnerability-zone geometry. Marker positions are illustrative, not plotted from exact facility coordinates. Use pink for humanitarian sites and orange for vulnerable-zone/priority accents.

**Sound:** The same instrumental bed continues without added SFX.

### Shot 04 / 15.00–21.00s / 6.00s — “A RECOMMENDATION YOU CAN EXPLAIN.”

**Purpose:** Demonstrate the current local rules-based result without implying an external AI request or live storm forecast.

**Exact content and holds:** Reveal `HIGH COORDINATION PRIORITY` at 15.55s and `32.8 KM · 3 SITES` at 15.75s. Stagger these concise excerpts from the current deterministic local explanation: `Share timelines and cross-utility contacts.` at 16.35s; `Work windows overlap: confirm crew sequencing.` at 17.05s; `Verify site contacts, access, and backup power.` at 17.75s; `Storm Mode inactive; align response contacts.` at 18.45s. At 19.15s show `LOCAL AI DEMO · RULES-BASED`; at 19.65s add `STORM MODE · SIMULATION`. The card copy remains legible until its outgoing fade and paper-panel reveal.

**Composition and artistic idea:** A pale recommendation card settles over the ink field, framed by an orange border and occupying 84% of the frame width and 79% of its height. Its circle-reveal center matches the site halo. The priority headline, measured distance/site count, and four short guidance rows come from the local demo's deterministic rules; the disclosures sit below them. A dashed purple simulated route remains behind the card.

**Timed choreography:** 0.00–0.55s: the orange halo opens into the pale card; its perspective settles. 0.55–1.10s: the priority title clips on; the metric resolves at 0.75s. From 1.35s, the four local-rule guidance rows appear at 0.70s intervals. The simulated route continues behind the card. At 4.15s and 4.65s, the local-demo and Storm Mode disclosures arrive. At 5.15s the card copy fades as two paper panels expand from the sides. An orange rule rises from the card's lower edge and changes to blue, reaching the end-card underline position at 6.00s.

**Transition contract:** One orange rule moves from the card's lower edge to the end-card underline position while changing to blue. The paper panels meet at the cut; Shot 05 holds the blue rule at the same position.

**Assets and technique:** Card, typography, metric, and route are procedural vector/UI artwork. The guidance is a concise rendering of the existing local rules: project distance, overlapping years, nearby site count, and the inactive Storm Mode state.

**Sound:** The 96 BPM instrumental continues. No lift or beat synchronization is claimed. The updated track was described as “smooth” by the listener.

### Shot 05 / 21.00–26.00s / 5.00s — “GRIDLOCK.”

**Purpose:** End with the product name, the user's exact product statement, and a clear local-demo disclosure.

**Exact content and holds:** From 21.00s, show the plain-text wordmark `GridLock` centered. At 21.15s show `PROTECTING COMMUNITIES BEFORE THE STORM` above it. From 22.05s, show this exact sentence, with line breaks only: `GridLock AI analyzes overlap distance,` / `storm risk, and humanitarian impact to` / `generate coordination` / `recommendations.` At 23.45s show `LOCAL AI DEMO · RULES-BASED`. Keep the full end-card copy legible until the loop aperture begins at 25.15s.

**Composition and artistic idea:** Palette inverts to warm paper and ink. The matched blue underline holds below a large, centered `GridLock` typeset wordmark. The exact statement is left-aligned inside a centered, narrow column below the wordmark; the local-demo disclosure is small but high-contrast. Compared with the map and card shots, this is a clean, quiet full-frame brand field.

**Timed choreography:** 0.00–0.55s: the paper panels finish opening; the underline holds while the wordmark scales into its final size. At 0.15s the eyebrow resolves above the mark. At 1.05s the exact product sentence appears in four readable lines, not letter-by-letter. At 2.45s the local-demo disclosure arrives below it. All copy holds sharply for reading. From 4.15s, the dark ring aperture expands over the warm paper through the cut; Shot 01 resumes on the ink field and begins tracing the violet route.

**Transition contract:** A dark circular aperture expands over the end card and hands off to Shot 01's ink field. The route trace begins after the boundary; the audio track loops at its 26.04-second end, slightly longer than the 26.00-second scene sequence.

**Assets and technique:** Space Grotesk typeset wordmark only; no invented icon or claim of an official logo. CSS/SVG masks, one procedural rule, and the palette inversion. Keep all copy inside the 4:5 safe area.

**Sound:** The instrumental continues to the loop boundary. The listener described the updated playback as “smooth”; chord resolution and device-specific loudness were not separately assessed.

## Pre-code variety and pacing review

- The five compositions alternate dark type, bright schematic map, dark site cluster, pale recommendation card on ink, and warm-paper end card.
- Each shot has a distinct subject or transition movement after its opening; the first, second, fourth, and fifth shots include active late-shot handoff motion.
- Project facts and recommendation details reflect the current local demo; the storm route and rules-based recommendation are disclosed as simulation/demo behavior.
- Handoffs use aligned rings, a circular reveal, or the moving orange-to-blue rule with paper panels. Scene 03 continues its halo animation through the cut.
- Visuals are procedural because the subject is a map-and-coordination tool, not a physical product. No generated photography, voiceover, sound effects, navigation, or interactive product controls are planned.