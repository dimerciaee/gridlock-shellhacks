import { motion } from 'framer-motion';
import { SceneFrame } from './SceneFrame';

const EASE = [0.16, 1, 0.3, 1] as const;

export function Scene1() {
  return (
    <motion.section
      className="video-scene scene-approach"
      initial={false}
      exit={{
        clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
        scale: 1.04,
        opacity: 0.85,
      }}
      transition={{ duration: 0.55, ease: EASE }}
      aria-label="Before the storm: simulated storm path"
    >
      <SceneFrame>
        <svg
          className="s1-map"
          viewBox="0 0 1000 1000"
          preserveAspectRatio="xMidYMid slice"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="coast-glow" x1="0" x2="1">
              <stop offset="0" stopColor="#2563eb" stopOpacity="0.03" />
              <stop offset="1" stopColor="#2563eb" stopOpacity="0.28" />
            </linearGradient>
          </defs>
          <path
            d="M-30 580 C120 530 165 420 292 442 C397 460 415 574 535 557 C649 541 669 433 787 424 C883 417 927 482 1034 445 L1034 1040 L-30 1040 Z"
            fill="url(#coast-glow)"
          />
          <path
            d="M20 190 C170 240 212 110 352 156 S546 237 685 168 S878 128 1015 192"
            fill="none"
            stroke="rgb(246 244 237 / 13%)"
            strokeWidth="2"
          />
          <path
            d="M-20 350 C112 393 223 285 350 332 S548 399 660 330 S879 291 1014 350"
            fill="none"
            stroke="rgb(246 244 237 / 11%)"
            strokeWidth="2"
          />
          <path
            d="M-10 750 C135 682 224 753 352 699 S562 663 683 725 S875 780 1015 688"
            fill="none"
            stroke="rgb(246 244 237 / 12%)"
            strokeWidth="2"
          />
          <motion.path
            d="M25 708 C176 647 251 673 355 566 C392 527 416 457 413 373"
            fill="none"
            stroke="#8b5cf6"
            strokeWidth="8"
            strokeDasharray="16 18"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0.65 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ pathLength: { duration: 1.55, delay: 0.25, ease: 'easeInOut' }, opacity: { duration: 0.35 } }}
          />
          <motion.circle
            cx="413"
            cy="373"
            r="15"
            fill="#f6f4ed"
            initial={{ scale: 0.7, opacity: 0.65 }}
            animate={{ scale: [0.7, 1.3, 1], opacity: [0.65, 1, 1] }}
            transition={{ duration: 0.8, delay: 1.2, ease: EASE }}
          />
          <circle cx="413" cy="373" r="31" fill="none" stroke="#8b5cf6" strokeWidth="3" opacity="0.65" />
        </svg>
        <motion.div
          className="s1-endpoint-ring"
          initial={{ scale: 0.55, opacity: 0 }}
          animate={{
            scale: [0.55, 1, 1, 3.5],
            opacity: [0, 0.78, 0.78, 0],
            filter: ['blur(0px)', 'blur(0px)', 'blur(1px)', 'blur(10px)'],
          }}
          transition={{
            duration: 4.5,
            times: [0, 0.3, 0.83, 1],
            ease: EASE,
          }}
          aria-hidden="true"
        />

        <div className="s1-kicker">GRIDLOCK · INFRASTRUCTURE COORDINATION</div>

        <div className="s1-headline">
          <motion.div
            className="s1-before"
            initial={{ scale: 0.96, x: -12 }}
            animate={{ scale: 1, x: 0 }}
            transition={{ type: 'spring', stiffness: 280, damping: 26 }}
          >
            BEFORE
          </motion.div>
          <motion.div
            className="s1-storm"
            initial={{ y: 20, opacity: 0.75 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.42, duration: 0.48, ease: EASE }}
          >
            THE STORM.
          </motion.div>
        </div>

        <motion.div
          className="s1-route-label mono-label"
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.35, duration: 0.35, ease: EASE }}
        >
          <span className="route-label-dot" />
          SIMULATED STORM PATH
        </motion.div>
        <motion.div
          className="mono-label"
          style={{ position: 'absolute', right: '8%', bottom: '12%', color: 'rgb(246 244 237 / 56%)' }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.35 }}
        >
          SOUTHEAST GEORGIA
        </motion.div>
      </SceneFrame>
    </motion.section>
  );
}