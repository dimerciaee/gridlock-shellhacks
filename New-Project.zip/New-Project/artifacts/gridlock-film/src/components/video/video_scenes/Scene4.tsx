import { useState } from 'react';
import { motion } from 'framer-motion';
import { SceneLayout, useSceneTimer } from '@/lib/video';
import { SceneFrame } from './SceneFrame';

const EASE = [0.16, 1, 0.3, 1] as const;
const ROWS = [
  'Share timelines and cross-utility contacts.',
  'Work windows overlap: confirm crew sequencing.',
  'Verify site contacts, access, and backup power.',
  'Storm Mode inactive; align response contacts.',
];

export function Scene4() {
  const [copyFaded, setCopyFaded] = useState(false);
  useSceneTimer([{ time: 5150, callback: () => setCopyFaded(true) }]);

  return (
    <motion.section
      className="video-scene scene-recommendation"
      initial={{ clipPath: 'circle(0% at 46.5% 55%)' }}
      animate={{ clipPath: 'circle(150% at 46.5% 55%)' }}
      exit={{ clipPath: 'inset(0 50% 0 50%)', opacity: 0.96 }}
      transition={{ duration: 0.64, ease: EASE }}
      aria-label="Rules-based local coordination recommendation"
    >
      <SceneFrame>
        <svg className="s4-back-route" viewBox="0 0 1000 1000" aria-hidden="true">
          <motion.path
            d="M30 760 C188 692 300 736 422 556 S662 329 970 207"
            fill="none"
            stroke="#8b5cf6"
            strokeWidth="8"
            strokeDasharray="15 24"
            strokeLinecap="round"
            animate={{ strokeDashoffset: [0, -78] }}
            transition={{ duration: 5.5, ease: 'linear', repeat: Infinity }}
          />
          <circle cx="422" cy="556" r="56" fill="none" stroke="#f97316" strokeWidth="5" />
        </svg>

        <motion.div
          className="s4-card"
          initial={{ scale: 0.88, rotateX: 10, y: 26, opacity: 0.82 }}
          animate={{ scale: 1, rotateX: 0, y: 0, opacity: 1 }}
          transition={{ duration: 0.82, delay: 0.1, ease: EASE }}
        >
          <motion.div
            className="s4-card-content"
            animate={{ opacity: copyFaded ? 0 : 1 }}
            transition={{ duration: 0.32, ease: EASE }}
          >
            <div className="s4-kicker">GRIDLOCK COORDINATION NOTE</div>
            <motion.h1
              className="s4-title"
              initial={{ clipPath: 'inset(0 100% 0 0)' }}
              animate={{ clipPath: 'inset(0 0 0 0)' }}
              transition={{ duration: 0.48, delay: 0.55, ease: EASE }}
            >
              HIGH COORDINATION PRIORITY
            </motion.h1>
            <motion.div
              className="s4-metric"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.75, duration: 0.32, ease: EASE }}
            >
              <span>32.8 KM</span>
              <span>·</span>
              <span>3 SITES</span>
            </motion.div>
            <SceneLayout
              layout="stack"
              className="s4-rows"
              style={{
                height: 'auto',
                gap: '1vmin',
                justifyContent: 'space-evenly',
              }}
            >
              {ROWS.map((row, index) => (
                <motion.div
                  className="s4-row"
                  key={row}
                  initial={{ x: -18, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.34, delay: 1.35 + index * 0.7, ease: EASE }}
                >
                  <span className="s4-row-mark" />
                  <span>{row}</span>
                </motion.div>
              ))}
            </SceneLayout>
            <div className="s4-disclosures">
              <motion.span
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 4.15, duration: 0.28 }}
              >
                LOCAL AI DEMO · RULES-BASED
              </motion.span>
              <motion.strong
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 4.65, duration: 0.28 }}
              >
                STORM MODE · SIMULATION
              </motion.strong>
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          className="s4-end-panel s4-end-panel-left"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 5.08, duration: 0.92, ease: EASE }}
          aria-hidden="true"
        />
        <motion.div
          className="s4-end-panel s4-end-panel-right"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 5.08, duration: 0.92, ease: EASE }}
          aria-hidden="true"
        />
        <motion.div
          className="s4-transition-rule"
          initial={{ top: '89%', scaleX: 0, opacity: 0, backgroundColor: '#f97316' }}
          animate={{
            top: ['89%', '43%'],
            scaleX: 1,
            opacity: 1,
            backgroundColor: ['#f97316', '#2563eb'],
          }}
          transition={{ delay: 5.3, duration: 0.7, ease: EASE }}
          aria-hidden="true"
        />
      </SceneFrame>
    </motion.section>
  );
}