import { motion } from 'framer-motion';
import { SceneFrame } from './SceneFrame';

const EASE = [0.16, 1, 0.3, 1] as const;

export function Scene2() {
  return (
    <motion.section
      className="video-scene scene-overlap"
      initial={{ clipPath: 'inset(0 100% 0 0)' }}
      animate={{ clipPath: 'inset(0 0 0 0)' }}
      exit={{ clipPath: 'circle(0% at 50% 49%)', scale: 1.08, opacity: 0.92 }}
      transition={{ duration: 0.62, ease: EASE }}
      aria-label="DESC and GPC utility project overlap"
    >
      <SceneFrame>
        <div className="s2-kicker">SHARED WORK WINDOW · COASTAL GEORGIA</div>
        <div className="s2-heading">
          <motion.span
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.18, duration: 0.38, ease: EASE }}
          >
            TWO UTILITIES.
          </motion.span>
          <motion.span
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.46, duration: 0.38, ease: EASE }}
          >
            ONE WORK ZONE.
          </motion.span>
        </div>

        <div className="s2-mapframe">
          <svg
            className="s2-map-svg"
            viewBox="0 0 1000 1000"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <path
              className="map-coast"
              d="M41 0 C112 56 116 145 193 189 C257 226 247 306 329 345 C388 374 393 472 463 514 C531 555 529 638 612 690 C675 730 700 819 757 861 C822 910 851 951 868 1000 L1010 1000 L1010 0 Z"
            />
            <path className="map-water" d="M38 50 C114 126 96 194 196 250 C264 288 256 358 353 400 S437 536 529 579 S638 700 700 736 S812 878 900 932" />
            <path className="map-road" d="M40 210 C216 260 340 192 493 236 S748 312 964 245" />
            <path className="map-road" d="M69 804 C248 718 390 750 533 653 S769 586 974 646" />
            <path className="map-road" d="M222 35 C251 208 327 362 450 498 S607 757 624 974" />
            <path className="map-road" d="M844 80 C741 243 729 394 818 542 S916 758 892 970" />
            <path
              d="M650 181 C536 285 401 493 270 671"
              fill="none"
              stroke="#2563eb"
              strokeWidth="9"
              strokeLinecap="round"
              strokeDasharray="1 20"
              pathLength="1"
              opacity="0.75"
            />
            <motion.path
              d="M650 181 C536 285 401 493 270 671"
              fill="none"
              stroke="#2563eb"
              strokeWidth="6"
              strokeLinecap="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.9, delay: 1.52, ease: 'easeInOut' }}
            />
            <motion.circle
              cx="460"
              cy="426"
              r="75"
              fill="none"
              stroke="#8b5cf6"
              strokeWidth="4"
              initial={{ scale: 0.82, opacity: 0.72 }}
              animate={{
                scale: [0.82, 1, 1.05, 1, 3.5],
                opacity: [0.72, 0.78, 0.5, 0.5, 0],
                stroke: ['#8b5cf6', '#8b5cf6', '#2563eb', '#2563eb', '#ec4899'],
              }}
              transition={{
                duration: 5.25,
                times: [0, 0.2, 0.4, 0.8, 1],
                ease: EASE,
              }}
            />
          </svg>

          <motion.div
            className="s2-marker s2-marker-jasper"
            initial={{ scale: 0.76, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.82, duration: 0.42, ease: EASE }}
          >
            <span className="marker-dot" />
            <span className="s2-marker-copy">
              Jasper Transmission Upgrade
              <small>DESC · 2026–2028</small>
            </span>
          </motion.div>

          <motion.div
            className="s2-marker s2-marker-mcintosh"
            initial={{ scale: 0.76, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 1.15, duration: 0.42, ease: EASE }}
          >
            <span className="marker-dot" />
            <span className="s2-marker-copy">
              Plant McIntosh Expansion
              <small>GPC · 2025–2027</small>
            </span>
          </motion.div>

          <motion.div
            className="s2-distance"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 2.28, type: 'spring', stiffness: 330, damping: 24 }}
          >
            32.8 KM APART
          </motion.div>
        </div>
      </SceneFrame>
    </motion.section>
  );
}