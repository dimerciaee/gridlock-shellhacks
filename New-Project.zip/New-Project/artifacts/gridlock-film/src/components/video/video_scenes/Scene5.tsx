import { motion } from 'framer-motion';
import { SceneFrame } from './SceneFrame';

const EASE = [0.16, 1, 0.3, 1] as const;

export function Scene5() {
  return (
    <motion.section
      className="video-scene scene-end"
      initial={false}
      exit={{ opacity: 1 }}
      aria-label="GridLock product statement"
    >
      <SceneFrame>
        <motion.div
          className="s5-kicker"
          initial={{ y: -8, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.15, duration: 0.32, ease: EASE }}
        >
          PROTECTING COMMUNITIES BEFORE THE STORM
        </motion.div>
        <motion.div
          className="s5-wordmark"
          initial={{ scale: 0.92, letterSpacing: '-0.12em' }}
          animate={{ scale: 1, letterSpacing: '-0.08em' }}
          transition={{ duration: 0.58, ease: EASE }}
        >
          GridL
          <span className="word-o">
            o
            <span className="s5-loop-origin" aria-hidden="true">
              <motion.span
                className="s5-loop-aperture"
                initial={{ scale: 0.08, opacity: 0 }}
                animate={{ scale: [0.08, 1, 11], opacity: [0, 1, 1] }}
                transition={{
                  delay: 4.15,
                  duration: 0.85,
                  times: [0, 0.14, 1],
                  ease: 'linear',
                }}
              />
            </span>
          </span>
          ck
        </motion.div>
        <motion.div
          className="s5-rule"
          initial={{ scaleX: 1 }}
          animate={{ scaleX: 1 }}
          aria-hidden="true"
        />
        <motion.p
          className="s5-statement"
          initial={{ y: 14, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.05, duration: 0.4, ease: EASE }}
        >
          GridLock AI analyzes overlap distance,
          <br />
          storm risk, and humanitarian impact to
          <br />
          generate coordination
          <br />
          recommendations.
        </motion.p>
        <motion.div
          className="s5-disclosure"
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 2.45, duration: 0.32, ease: EASE }}
        >
          LOCAL AI DEMO · RULES-BASED
        </motion.div>
      </SceneFrame>
    </motion.section>
  );
}