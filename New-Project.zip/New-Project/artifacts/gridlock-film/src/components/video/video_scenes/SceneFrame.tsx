import type { PropsWithChildren } from 'react';
import { SafeFrame } from '@/lib/video';

export function SceneFrame({ children }: PropsWithChildren) {
  return (
    <SafeFrame className="scene-safe-frame">
      <div className="scene-stage">{children}</div>
    </SafeFrame>
  );
}