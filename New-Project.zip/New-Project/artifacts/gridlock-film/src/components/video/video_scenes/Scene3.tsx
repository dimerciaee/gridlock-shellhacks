import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useSceneTimer } from '@/lib/video';
import { SceneFrame } from './SceneFrame';

const EASE = [0.16, 1, 0.3, 1] as const;
const SITE_CAPTIONS = [
  'SAVANNAH GENERAL HOSPITAL',
  'RIVERFRONT CARE CENTER',
  'SAVANNAH FIRE STATION #3',
  'WITHIN 20 KM OF EITHER PROJECT',
];

export function Scene3() {
  const [captionIndex, setCaptionIndex] = useState(-1);

  useSceneTimer([
    { time: 1150, callback: () => setCaptionIndex(0) },
    { time: 2200, callback: () => setCaptionIndex(1) },
    { time: 3250, callback: () => setCaptionIndex(2) },
    { time: 4300, callback: () => setCaptionIndex(3) },
  ]);

  return (
    <motion.section
      className="video-scene scene-sites"
      initial={{ clipPath: 'circle(0% at 46.5% 55%)' }}
      animate={{ clipPath: 'circle(140% at 46.5% 55%)' }}
      exit={{ clipPath: 'inset(0 100% 0 0)', scale: 1.035 }}
      transition={{ duration: 0.64, ease: EASE }}
      aria-label="Three nearby humanitarian sites"
    >
      <SceneFrame>
        <div className="s3-kicker">PEOPLE FIRST · SITE CONTEXT</div>
        <div className="s3-number" aria-hidden="true">03</div>
        <div className="s3-title">
          <span>THREE NEARBY</span>
          <strong>CRITICAL SITES.</strong>
        </div>

        <div className="s3-cluster" aria-hidden="true">
          <motion.div
            className="s3-vulnerable-zone"
            initial={{ scale: 0.7, opacity: 0.2 }}
            animate={{ scale: [0.7, 1, 1.05], opacity: [0.2, 0.7, 0.58] }}
            transition={{ duration: 3.8, delay: 1.1, ease: 'easeOut' }}
          />
          <motion.div
            className="s3-halo"
            initial={{ scale: 0.65, opacity: 0.45 }}
            animate={{
              scale: [0.65, 1, 1, 1.16],
              opacity: [0.45, 1, 0.9, 0.8],
              borderColor: ['#ec4899', '#ec4899', '#ec4899', '#f97316'],
            }}
            transition={{ duration: 5.15, times: [0, 0.18, 0.8, 1], ease: EASE }}
          />
          <motion.div
            className="s3-site s3-care"
            initial={{ scale: 0.5, opacity: 0.2 }}
            animate={{ scale: [0.5, 1.08, 1], opacity: [0.2, 1, 1] }}
            transition={{ duration: 0.55, delay: 0.65, ease: EASE }}
          >
            C
          </motion.div>
          <motion.div
            className="s3-site s3-fire"
            initial={{ scale: 0.5, opacity: 0.2 }}
            animate={{ scale: [0.5, 1.08, 1], opacity: [0.2, 1, 1] }}
            transition={{ duration: 0.55, delay: 1, ease: EASE }}
          >
            3
          </motion.div>
          <motion.div
            className="s3-site s3-hospital"
            initial={{ scale: 0.5, opacity: 0.2 }}
            animate={{ scale: [0.5, 1.08, 1], opacity: [0.2, 1, 1] }}
            transition={{ duration: 0.55, delay: 1.35, ease: EASE }}
          >
            +
          </motion.div>
        </div>

        <div className="s3-caption" aria-live="polite">
          <AnimatePresence mode="wait" initial={false}>
            {captionIndex >= 0 && (
              <motion.span
                key={captionIndex}
                initial={{ opacity: 0, y: 10, filter: 'blur(5px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -8, filter: 'blur(4px)' }}
                transition={{ duration: 0.24, ease: EASE }}
              >
                {SITE_CAPTIONS[captionIndex]}
              </motion.span>
            )}
          </AnimatePresence>
        </div>
        <div className="s3-radius">HOSPITAL · CARE CENTER · FIRE STATION</div>
      </SceneFrame>
    </motion.section>
  );
}